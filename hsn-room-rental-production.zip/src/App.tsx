import React, { useState, useRef, useEffect } from 'react';
import { Printer, Download, Plus, Trash2, Home, User, Users, Phone, CreditCard, Calendar, Zap, Droplets, Wifi, Info, Loader2, Search, Database, RefreshCw, Edit, LogOut, BarChart3 } from 'lucide-react';
import { motion } from 'motion/react';
import { toPng } from 'html-to-image';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Line, ComposedChart } from 'recharts';

interface InvoiceItem {
  id: string;
  description: string;
  oldMonthNo: string;
  newMonthNo: string;
  quantity: number;
  unitPrice: number;
  unit: string;
  currency: 'USD' | 'KHR';
}

interface InvoiceData {
  landlordName: string;
  landlordAddress: string;
  landlordPhone: string;
  tenantName: string;
  roomNo: string;
  tenantPhone: string;
  tenantIdNo: string;
  checkInDate: string;
  logoUrl: string | null;
  qrUrl: string | null;
  items: InvoiceItem[];
  rules: string[];
  totalUsd: number;
}

interface SavedTenant {
  tenantName: string;
  roomNo: string;
  tenantPhone: string;
  tenantIdNo: string;
  checkInDate: string;
  roomPrice: number;
  wifiPrice: number;
  elecOld: string;
  waterOld: string;
  isPaid?: boolean;
  deposit?: number;
}

interface InvoiceHistoryRecord {
  id: string;
  tenantName: string;
  roomNo: string;
  paymentDate: string; // YYYY-MM-DD
  roomPrice: number;
  wifiPrice: number;
  elecPrice: number;
  waterPrice: number;
  otherPrice: number;
  totalUsd: number;
  elecUsage: number;
  waterUsage: number;
  status: 'PAID' | 'PENDING';
}

// Pre-seeded income records matching our master tenant database
const initialHistory: InvoiceHistoryRecord[] = [
  // --- MONTH 1 / 2026 ---
  { id: 'h-1-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-01-25", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 3.13, waterPrice: 0.50, otherPrice: 0, totalUsd: 98.63, elecUsage: 3, waterUsage: 1, status: 'PAID' },
  { id: 'h-1-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-01-02", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 13.50, waterPrice: 5.50, otherPrice: 0, totalUsd: 104.00, elecUsage: 36, waterUsage: 11, status: 'PAID' },
  { id: 'h-1-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-01-02", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 8.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 89.25, elecUsage: 22, waterUsage: 2, status: 'PAID' },
  { id: 'h-1-12', tenantName: "ឌុច ពីទូ", roomNo: "12", paymentDate: "2026-01-26", roomPrice: 85.00, wifiPrice: 5.00, elecPrice: 14.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 105.25, elecUsage: 38, waterUsage: 2, status: 'PAID' },
  { id: 'h-1-13', tenantName: "ម៉េង ចាន់ហួរ", roomNo: "13", paymentDate: "2026-01-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 0.00, waterPrice: 0.00, otherPrice: 0, totalUsd: 80.00, elecUsage: 0, waterUsage: 0, status: 'PAID' },
  { id: 'h-1-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-01-02", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 3.75, waterPrice: 1.00, otherPrice: 0, totalUsd: 74.75, elecUsage: 10, waterUsage: 2, status: 'PAID' },
  { id: 'h-1-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-01-10", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 10.13, waterPrice: 1.50, otherPrice: 0, totalUsd: 81.63, elecUsage: 27, waterUsage: 3, status: 'PAID' },
  { id: 'h-1-16', tenantName: "ថែ ធារិទ្ធ", roomNo: "16", paymentDate: "2026-01-04", roomPrice: 75.00, wifiPrice: 5.00, elecPrice: 3.38, waterPrice: 1.00, otherPrice: 0, totalUsd: 84.38, elecUsage: 9, waterUsage: 2, status: 'PAID' },

  // --- MONTH 2 / 2026 ---
  { id: 'h-2-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-02-25", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 3.38, waterPrice: 2.50, otherPrice: 0, totalUsd: 100.88, elecUsage: 9, waterUsage: 5, status: 'PAID' },
  { id: 'h-2-8', tenantName: "ហឹុន ប៊ុនឈួយ", roomNo: "8", paymentDate: "2026-02-18", roomPrice: 100.00, wifiPrice: 5.00, elecPrice: -3.62, waterPrice: 0.50, otherPrice: 0, totalUsd: 101.88, elecUsage: 13, waterUsage: 1, status: 'PAID' },
  { id: 'h-2-9', tenantName: "អេន ដាំ", roomNo: "9", paymentDate: "2026-02-05", roomPrice: 0.00, wifiPrice: 0.00, elecPrice: 13.88, waterPrice: 26.12, otherPrice: 0, totalUsd: 40.00, elecUsage: 37, waterUsage: 6, status: 'PAID' },
  { id: 'h-2-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-02-02", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 15.00, waterPrice: 4.50, otherPrice: 0, totalUsd: 104.50, elecUsage: 40, waterUsage: 9, status: 'PAID' },
  { id: 'h-2-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-02-02", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 7.13, waterPrice: 1.00, otherPrice: 0, totalUsd: 88.13, elecUsage: 19, waterUsage: 2, status: 'PAID' },
  { id: 'h-2-12', tenantName: "ឌុច ពីទូ", roomNo: "12", paymentDate: "2026-02-26", roomPrice: 85.00, wifiPrice: 5.00, elecPrice: 14.63, waterPrice: 1.00, otherPrice: 0, totalUsd: 105.63, elecUsage: 39, waterUsage: 2, status: 'PAID' },
  { id: 'h-2-13', tenantName: "ម៉េង ចាន់ហួរ", roomNo: "13", paymentDate: "2026-02-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 7.50, waterPrice: 1.00, otherPrice: 0, totalUsd: 88.50, elecUsage: 20, waterUsage: 2, status: 'PAID' },
  { id: 'h-2-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-02-02", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 7.88, waterPrice: 1.00, otherPrice: 0, totalUsd: 78.88, elecUsage: 21, waterUsage: 2, status: 'PAID' },
  { id: 'h-2-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-02-10", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 6.75, waterPrice: 1.50, otherPrice: 0, totalUsd: 78.25, elecUsage: 18, waterUsage: 3, status: 'PAID' },
  { id: 'h-2-16', tenantName: "ថែ ធារិទ្ធ", roomNo: "16", paymentDate: "2026-02-04", roomPrice: 75.00, wifiPrice: 5.00, elecPrice: 1.88, waterPrice: 2.00, otherPrice: 0, totalUsd: 83.88, elecUsage: 5, waterUsage: 4, status: 'PAID' },

  // --- MONTH 3 / 2026 ---
  { id: 'h-3-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-03-25", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 0.75, waterPrice: 2.50, otherPrice: 0, totalUsd: 98.25, elecUsage: 2, waterUsage: 5, status: 'PAID' },
  { id: 'h-3-8', tenantName: "ហឹុន ប៊ุนឈួយ", roomNo: "8", paymentDate: "2026-03-18", roomPrice: 0.00, wifiPrice: 5.00, elecPrice: 0.38, waterPrice: 0.00, otherPrice: 0, totalUsd: 5.38, elecUsage: 1, waterUsage: 0, status: 'PAID' },
  { id: 'h-3-9', tenantName: "អេន ដាំ", roomNo: "9", paymentDate: "2026-03-05", roomPrice: 0.00, wifiPrice: 0.00, elecPrice: 15.00, waterPrice: 25.00, otherPrice: 0, totalUsd: 40.00, elecUsage: 37, waterUsage: 6, status: 'PAID' },
  { id: 'h-3-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-03-02", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 11.63, waterPrice: 7.50, otherPrice: 0, totalUsd: 104.13, elecUsage: 31, waterUsage: 15, status: 'PAID' },
  { id: 'h-3-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-03-02", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 8.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 89.25, elecUsage: 22, waterUsage: 2, status: 'PAID' },
  { id: 'h-3-12', tenantName: "ឌុច ពីទូ", roomNo: "12", paymentDate: "2026-03-26", roomPrice: 85.00, wifiPrice: 5.00, elecPrice: 12.00, waterPrice: 1.00, otherPrice: 0, totalUsd: 103.00, elecUsage: 32, waterUsage: 2, status: 'PAID' },
  { id: 'h-3-13', tenantName: "ម៉េង ចាន់ហួរ", roomNo: "13", paymentDate: "2026-03-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 8.63, waterPrice: 1.00, otherPrice: 0, totalUsd: 89.63, elecUsage: 23, waterUsage: 1, status: 'PAID' },
  { id: 'h-3-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-03-02", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 7.50, waterPrice: 2.00, otherPrice: 0, totalUsd: 79.50, elecUsage: 20, waterUsage: 2, status: 'PAID' },
  { id: 'h-3-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-03-10", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 5.63, waterPrice: 1.00, otherPrice: 0, totalUsd: 76.63, elecUsage: 15, waterUsage: 2, status: 'PAID' },
  { id: 'h-3-16', tenantName: "ថែ ធារិទ្ធ", roomNo: "16", paymentDate: "2026-03-04", roomPrice: 75.00, wifiPrice: 5.00, elecPrice: 4.13, waterPrice: 0.50, otherPrice: 0, totalUsd: 84.63, elecUsage: 11, waterUsage: 1, status: 'PAID' },

  // --- MONTH 4 / 2026 ---
  { id: 'h-4-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-04-25", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 0.38, waterPrice: 2.00, otherPrice: 0, totalUsd: 97.38, elecUsage: 1, waterUsage: 4, status: 'PAID' },
  { id: 'h-4-9', tenantName: "អេន ដាំ", roomNo: "9", paymentDate: "2026-04-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 9.75, waterPrice: 2.00, otherPrice: 0, totalUsd: 91.75, elecUsage: 26, waterUsage: 4, status: 'PAID' },
  { id: 'h-4-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-04-02", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 13.50, waterPrice: 2.50, otherPrice: 0, totalUsd: 101.00, elecUsage: 36, waterUsage: 5, status: 'PAID' },
  { id: 'h-4-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-04-02", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 10.88, waterPrice: 1.00, otherPrice: 0, totalUsd: 91.88, elecUsage: 29, waterUsage: 2, status: 'PAID' },
  { id: 'h-4-12', tenantName: "ឌុច ពីទូ", roomNo: "12", paymentDate: "2026-04-26", roomPrice: 85.00, wifiPrice: 5.00, elecPrice: 14.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 105.25, elecUsage: 38, waterUsage: 2, status: 'PAID' },
  { id: 'h-4-13', tenantName: "ម៉េង ចាន់ហួរ", roomNo: "13", paymentDate: "2026-04-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 8.63, waterPrice: 1.50, otherPrice: 0, totalUsd: 90.13, elecUsage: 23, waterUsage: 3, status: 'PAID' },
  { id: 'h-4-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-04-02", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 7.13, waterPrice: 1.00, otherPrice: 0, totalUsd: 78.13, elecUsage: 19, waterUsage: 2, status: 'PAID' },
  { id: 'h-4-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-04-10", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 5.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 76.25, elecUsage: 14, waterUsage: 2, status: 'PAID' },
  { id: 'h-4-16', tenantName: "ថែ ធារិទ្ធ", roomNo: "16", paymentDate: "2026-04-04", roomPrice: 75.00, wifiPrice: 5.00, elecPrice: 6.00, waterPrice: 0.50, otherPrice: 0, totalUsd: 86.50, elecUsage: 16, waterUsage: 1, status: 'PAID' },

  // --- MONTH 5 / 2026 ---
  { id: 'h-5-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-05-25", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 0.38, waterPrice: 2.00, otherPrice: 0, totalUsd: 97.38, elecUsage: 1, waterUsage: 4, status: 'PAID' },
  { id: 'h-5-9', tenantName: "អេន ដាំ", roomNo: "9", paymentDate: "2026-05-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 6.75, waterPrice: 2.00, otherPrice: 0, totalUsd: 88.75, elecUsage: 18, waterUsage: 4, status: 'PAID' },
  { id: 'h-5-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-05-02", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 13.50, waterPrice: 2.50, otherPrice: 0, totalUsd: 101.00, elecUsage: 36, waterUsage: 6, status: 'PAID' },
  { id: 'h-5-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-05-02", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 10.88, waterPrice: 1.00, otherPrice: 0, totalUsd: 91.88, elecUsage: 17, waterUsage: 2, status: 'PAID' },
  { id: 'h-5-12', tenantName: "ឌុច ពីទូ", roomNo: "12", paymentDate: "2026-05-26", roomPrice: 85.00, wifiPrice: 5.00, elecPrice: 14.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 105.25, elecUsage: 46, waterUsage: 2, status: 'PAID' },
  { id: 'h-5-13', tenantName: "ម៉េង ចាន់ហួរ", roomNo: "13", paymentDate: "2026-05-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 8.63, waterPrice: 1.50, otherPrice: 0, totalUsd: 90.13, elecUsage: 19, waterUsage: 1, status: 'PAID' },
  { id: 'h-5-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-05-02", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 7.13, waterPrice: 1.00, otherPrice: 0, totalUsd: 78.13, elecUsage: 14, waterUsage: 2, status: 'PAID' },
  { id: 'h-5-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-05-10", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 5.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 76.25, elecUsage: 15, waterUsage: 2, status: 'PAID' },
  { id: 'h-5-16', tenantName: "ថែ ធារិទ្ធ", roomNo: "16", paymentDate: "2026-05-04", roomPrice: 75.00, wifiPrice: 5.00, elecPrice: 6.00, waterPrice: 0.50, otherPrice: 0, totalUsd: 86.50, elecUsage: 20, waterUsage: 3, status: 'PAID' },

  // --- MONTH 6 / 2026 ---
  { id: 'h-6-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-06-25", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 1.13, waterPrice: 0.50, otherPrice: 0, totalUsd: 96.63, elecUsage: 3, waterUsage: 4, status: 'PAID' },
  { id: 'h-6-8', tenantName: "ថែ ធារិទ្ធ", roomNo: "8", paymentDate: "2026-06-18", roomPrice: 100.00, wifiPrice: 0.00, elecPrice: 12.38, waterPrice: 2.00, otherPrice: 0, totalUsd: 114.38, elecUsage: 33, waterUsage: 4, status: 'PAID' },
  { id: 'h-6-9', tenantName: "អេន ដាំ", roomNo: "9", paymentDate: "2026-06-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 7.50, waterPrice: 2.50, otherPrice: 0, totalUsd: 90.00, elecUsage: 20, waterUsage: 5, status: 'PAID' },
  { id: 'h-6-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-06-02", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 14.63, waterPrice: -1.00, otherPrice: 0, totalUsd: 98.63, elecUsage: 39, waterUsage: 8, status: 'PAID' },
  { id: 'h-6-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-06-02", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 11.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 92.25, elecUsage: 30, waterUsage: 2, status: 'PAID' },
  { id: 'h-6-12', tenantName: "ឌុច ពីទូ", roomNo: "12", paymentDate: "2026-06-26", roomPrice: 85.00, wifiPrice: 5.00, elecPrice: 14.50, waterPrice: 1.00, otherPrice: 0, totalUsd: 105.50, elecUsage: 52, waterUsage: 2, status: 'PAID' },
  { id: 'h-6-13', tenantName: "ម៉េង ចាន់ហួរ", roomNo: "13", paymentDate: "2026-06-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 10.13, waterPrice: 1.50, otherPrice: 0, totalUsd: 91.63, elecUsage: 27, waterUsage: 3, status: 'PAID' },
  { id: 'h-6-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-06-02", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 5.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 76.25, elecUsage: 14, waterUsage: 2, status: 'PAID' },
  { id: 'h-6-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-06-10", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 5.25, waterPrice: 1.00, otherPrice: 0, totalUsd: 76.25, elecUsage: 27, waterUsage: 6, status: 'PAID' },
  { id: 'h-6-16', tenantName: "គាត ប៊ុនថន", roomNo: "16", paymentDate: "2026-06-04", roomPrice: 75.00, wifiPrice: 5.00, elecPrice: 3.25, waterPrice: 0.50, otherPrice: 0, totalUsd: 83.75, elecUsage: 22, waterUsage: 1, status: 'PAID' },

  // --- MONTH 7 / 2026 ---
  { id: 'h-7-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-07-25", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 0.38, waterPrice: 2.50, otherPrice: 0, totalUsd: 97.88, elecUsage: 1, waterUsage: 5, status: 'PAID' },
  { id: 'h-7-8', tenantName: "ថែ ធារិទ្ធ", roomNo: "8", paymentDate: "2026-07-18", roomPrice: 100.00, wifiPrice: 0.00, elecPrice: 8.25, waterPrice: 1.50, otherPrice: 0, totalUsd: 109.75, elecUsage: 22, waterUsage: 3, status: 'PAID' },
  { id: 'h-7-9', tenantName: "អេន ដាំ", roomNo: "9", paymentDate: "2026-07-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 7.50, waterPrice: 2.50, otherPrice: 0, totalUsd: 90.00, elecUsage: 20, waterUsage: 5, status: 'PAID' },
  { id: 'h-7-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-07-02", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 13.50, waterPrice: 5.00, otherPrice: 0, totalUsd: 103.50, elecUsage: 36, waterUsage: 10, status: 'PAID' },
  { id: 'h-7-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-07-02", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 11.63, waterPrice: 1.50, otherPrice: 0, totalUsd: 93.13, elecUsage: 31, waterUsage: 3, status: 'PAID' },
  { id: 'h-7-12', tenantName: "ឌុច ពីទូ", roomNo: "12", paymentDate: "2026-07-26", roomPrice: 85.00, wifiPrice: 5.00, elecPrice: 16.50, waterPrice: 1.50, otherPrice: 0, totalUsd: 108.00, elecUsage: 44, waterUsage: 3, status: 'PAID' },
  { id: 'h-7-13', tenantName: "ម៉េង ចាន់ហួរ", roomNo: "13", paymentDate: "2026-07-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 11.63, waterPrice: 1.50, otherPrice: 0, totalUsd: 93.13, elecUsage: 31, waterUsage: 3, status: 'PAID' },
  { id: 'h-7-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-07-02", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 9.38, waterPrice: 1.00, otherPrice: 0, totalUsd: 80.38, elecUsage: 25, waterUsage: 2, status: 'PAID' },
  { id: 'h-7-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-07-10", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 2.63, waterPrice: 0.50, otherPrice: 0, totalUsd: 73.13, elecUsage: 7, waterUsage: 1, status: 'PAID' },
  { id: 'h-7-16', tenantName: "គាត ប៊ุนថน", roomNo: "16", paymentDate: "2026-07-04", roomPrice: 75.00, wifiPrice: 5.00, elecPrice: 7.13, waterPrice: 1.00, otherPrice: 0, totalUsd: 88.13, elecUsage: 19, waterUsage: 2, status: 'PAID' },

  // --- MONTH 8 / 2026 ---
  { id: 'h-8-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-08-25", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 1.13, waterPrice: 2.50, otherPrice: 0, totalUsd: 98.63, elecUsage: 3, waterUsage: 5, status: 'PAID' },
  { id: 'h-8-8', tenantName: "ថែ ធារិទ្ធ", roomNo: "8", paymentDate: "2026-08-18", roomPrice: 100.00, wifiPrice: 0.00, elecPrice: 8.63, waterPrice: 1.00, otherPrice: 0, totalUsd: 109.63, elecUsage: 23, waterUsage: 2, status: 'PAID' },
  { id: 'h-8-9', tenantName: "អេន ដាំ", roomNo: "9", paymentDate: "2026-08-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 10.50, waterPrice: 2.50, otherPrice: 0, totalUsd: 93.00, elecUsage: 28, waterUsage: 5, status: 'PAID' },
  { id: 'h-8-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-08-02", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 14.25, waterPrice: 6.50, otherPrice: 0, totalUsd: 105.75, elecUsage: 38, waterUsage: 13, status: 'PAID' },
  { id: 'h-8-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-08-02", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 10.13, waterPrice: 1.00, otherPrice: 0, totalUsd: 91.13, elecUsage: 27, waterUsage: 2, status: 'PAID' },
  { id: 'h-8-13', tenantName: "ម៉េង ចាន់ហួរ", roomNo: "13", paymentDate: "2026-08-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 4.50, waterPrice: 0.50, otherPrice: 0, totalUsd: 85.00, elecUsage: 12, waterUsage: 1, status: 'PAID' },
  { id: 'h-8-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-08-02", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 4.50, waterPrice: 1.00, otherPrice: 0, totalUsd: 75.50, elecUsage: 12, waterUsage: 2, status: 'PAID' },
  { id: 'h-8-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-08-10", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 1.88, waterPrice: 0.50, otherPrice: 0, totalUsd: 72.38, elecUsage: 5, waterUsage: 1, status: 'PAID' },
  { id: 'h-8-16', tenantName: "គាត ប៊ุนថন", roomNo: "16", paymentDate: "2026-08-04", roomPrice: 75.00, wifiPrice: 5.00, elecPrice: 4.88, waterPrice: 1.00, otherPrice: 0, totalUsd: 85.88, elecUsage: 13, waterUsage: 2, status: 'PAID' },

  // --- MONTH 9 / 2026 ---
  { id: 'h-9-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-09-25", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 3.00, waterPrice: 3.00, otherPrice: 0, totalUsd: 101.00, elecUsage: 8, waterUsage: 6, status: 'PAID' },
  { id: 'h-9-8', tenantName: "ថែ ធារិទ្ធ", roomNo: "8", paymentDate: "2026-09-04", roomPrice: 100.00, wifiPrice: 0.00, elecPrice: 7.88, waterPrice: 1.00, otherPrice: 0, totalUsd: 108.88, elecUsage: 21, waterUsage: 2, status: 'PAID' },
  { id: 'h-9-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-09-02", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 11.63, waterPrice: 7.00, otherPrice: 0, totalUsd: 103.63, elecUsage: 31, waterUsage: 14, status: 'PAID' },
  { id: 'h-9-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-09-02", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 10.13, waterPrice: 1.50, otherPrice: 0, totalUsd: 91.63, elecUsage: 27, waterUsage: 3, status: 'PAID' },
  { id: 'h-9-13', tenantName: "ម៉េង ចាន់ហួរ", roomNo: "13", paymentDate: "2026-09-05", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 2.63, waterPrice: 0.50, otherPrice: 0, totalUsd: 83.13, elecUsage: 7, waterUsage: 1, status: 'PAID' },
  { id: 'h-9-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-09-02", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 15.75, waterPrice: 3.75, otherPrice: 0, totalUsd: 89.50, elecUsage: 42, waterUsage: 1, status: 'PAID' },
  { id: 'h-9-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-09-10", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 1.88, waterPrice: 0.87, otherPrice: 0, totalUsd: 72.75, elecUsage: 0, waterUsage: 0, status: 'PAID' },

  // --- MONTH 10 / 2026 ---
  { id: 'h-10-5', tenantName: "ឌិន ចាន់នី", roomNo: "5", paymentDate: "2026-10-01", roomPrice: 90.00, wifiPrice: 0.00, elecPrice: 9.00, waterPrice: 2.00, otherPrice: 0, totalUsd: 101.00, elecUsage: 24, waterUsage: 5, status: 'PAID' },
  { id: 'h-10-6', tenantName: "កែម ស៊ីណែ", roomNo: "6", paymentDate: "2026-10-01", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 2.63, waterPrice: 2.00, otherPrice: 0, totalUsd: 99.63, elecUsage: 7, waterUsage: 4, status: 'PAID' },
  { id: 'h-10-8', tenantName: "ឌាស ហ៊ឹង", roomNo: "8", paymentDate: "2026-10-01", roomPrice: 90.00, wifiPrice: 5.00, elecPrice: 1.13, waterPrice: 0.50, otherPrice: 0, totalUsd: 57.63, elecUsage: 3, waterUsage: 1, status: 'PAID' },
  { id: 'h-10-10', tenantName: "គូ គង់មី", roomNo: "10", paymentDate: "2026-10-01", roomPrice: 80.00, wifiPrice: 5.00, elecPrice: 16.50, waterPrice: 13.00, otherPrice: -85.00, totalUsd: 29.50, elecUsage: 44, waterUsage: 26, status: 'PAID' },
  { id: 'h-10-11', tenantName: "សាន ហៃ", roomNo: "11", paymentDate: "2026-10-01", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 10.13, waterPrice: 1.00, otherPrice: 0, totalUsd: 91.13, elecUsage: 27, waterUsage: 2, status: 'PAID' },
  { id: 'h-10-12', tenantName: "កា រីតា", roomNo: "12", paymentDate: "2026-10-01", roomPrice: 85.00, wifiPrice: 0.00, elecPrice: 3.00, waterPrice: 1.50, otherPrice: 1.00, totalUsd: 89.50, elecUsage: 8, waterUsage: 3, status: 'PAID' },
  { id: 'h-10-13', tenantName: "នាយ ម៉េងយូ", roomNo: "13", paymentDate: "2026-10-01", roomPrice: 80.00, wifiPrice: 0.00, elecPrice: 0.00, waterPrice: 1.50, otherPrice: 0, totalUsd: 81.50, elecUsage: 0, waterUsage: 0, status: 'PAID' },
  { id: 'h-10-14', tenantName: "លុត ឡោត", roomNo: "14", paymentDate: "2026-10-01", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 11.63, waterPrice: 2.00, otherPrice: 0, totalUsd: 83.63, elecUsage: 31, waterUsage: 4, status: 'PAID' },
  { id: 'h-10-15', tenantName: "តាំង លីហៀង", roomNo: "15", paymentDate: "2026-10-01", roomPrice: 70.00, wifiPrice: 0.00, elecPrice: 1.88, waterPrice: 0.50, otherPrice: 0, totalUsd: 72.38, elecUsage: 5, waterUsage: 1, status: 'PAID' },
  { id: 'h-10-16', tenantName: "ថែ ធារិទ្ធ", roomNo: "16", paymentDate: "2026-10-01", roomPrice: 75.00, wifiPrice: 0.00, elecPrice: 11.25, waterPrice: 2.00, otherPrice: 20.63, totalUsd: 108.88, elecUsage: 30, waterUsage: 4, status: 'PAID' }
];

// Preloaded customer database exactly matching October 2026 master list
const initialSavedTenants: SavedTenant[] = [
  {
    tenantName: "ឌិន ចាន់នី",
    roomNo: "5",
    tenantIdNo: "240225426",
    tenantPhone: "0889662648",
    checkInDate: "2026-09-18",
    roomPrice: 90.00,
    wifiPrice: 0.00,
    elecOld: "1360",
    waterOld: "16",
    isPaid: false,
    deposit: 90.00
  },
  {
    tenantName: "កែម ស៊ីណែ",
    roomNo: "6",
    tenantIdNo: "180724334 (01)",
    tenantPhone: "095 431 778",
    checkInDate: "2025-09-25",
    roomPrice: 90.00,
    wifiPrice: 5.00,
    elecOld: "1250",
    waterOld: "101",
    isPaid: false,
    deposit: 90.00
  },
  {
    tenantName: "ឌាស ហ៊ឹង",
    roomNo: "8",
    tenantIdNo: "240225428",
    tenantPhone: "0889662648",
    checkInDate: "2026-09-18",
    roomPrice: 90.00,
    wifiPrice: 5.00,
    elecOld: "2624",
    waterOld: "53",
    isPaid: false,
    deposit: 90.00
  },
  {
    tenantName: "គូ គង់មី",
    roomNo: "10",
    tenantIdNo: "110526299 (01)",
    tenantPhone: "0968 793 531",
    checkInDate: "2025-09-02",
    roomPrice: 80.00,
    wifiPrice: 5.00,
    elecOld: "2082",
    waterOld: "172",
    isPaid: false,
    deposit: 80.00
  },
  {
    tenantName: "សាន ហៃ",
    roomNo: "11",
    tenantIdNo: "150638261 (01)",
    tenantPhone: "015 971 799",
    checkInDate: "2025-09-02",
    roomPrice: 80.00,
    wifiPrice: 0.00,
    elecOld: "1408",
    waterOld: "26",
    isPaid: false,
    deposit: 80.00
  },
  {
    tenantName: "កា រីតា",
    roomNo: "12",
    tenantIdNo: "250451234",
    tenantPhone: "0974906220",
    checkInDate: "2026-09-26",
    roomPrice: 85.00,
    wifiPrice: 0.00,
    elecOld: "1688",
    waterOld: "46",
    isPaid: false,
    deposit: 85.00
  },
  {
    tenantName: "នាយ ម៉េងយូ",
    roomNo: "13",
    tenantIdNo: "0151044919",
    tenantPhone: "718401269",
    checkInDate: "2026-10-03",
    roomPrice: 80.00,
    wifiPrice: 0.00,
    elecOld: "970",
    waterOld: "31",
    isPaid: false,
    deposit: 80.00
  },
  {
    tenantName: "លុត ឡោត",
    roomNo: "14",
    tenantIdNo: "101 423 550",
    tenantPhone: "0965 039 369",
    checkInDate: "2025-09-02",
    roomPrice: 70.00,
    wifiPrice: 0.00,
    elecOld: "1665",
    waterOld: "38",
    isPaid: false,
    deposit: 70.00
  },
  {
    tenantName: "តាំង លីហៀង",
    roomNo: "15",
    tenantIdNo: "",
    tenantPhone: "081982611",
    checkInDate: "2026-06-10",
    roomPrice: 70.00,
    wifiPrice: 0.00,
    elecOld: "1726",
    waterOld: "29",
    isPaid: false,
    deposit: 70.00
  },
  {
    tenantName: "ថែ ធារិទ្ធ",
    roomNo: "16",
    tenantIdNo: "011 445 024",
    tenantPhone: "0975 630 828",
    checkInDate: "2025-09-04",
    roomPrice: 75.00,
    wifiPrice: 0.00,
    elecOld: "1478",
    waterOld: "27",
    isPaid: false,
    deposit: 75.00
  }
];

const initialData: InvoiceData = {
  landlordName: "សាង សុវណ្ណារតនៈ",
  landlordAddress: "ភូមិបឹងកងកង ២ ខណ្ឌបឹងកងកង រាជធានី ភ្នំពេញ",
  landlordPhone: "070 536 926",
  tenantName: "គូ គង់មី",
  roomNo: "10",
  tenantPhone: "0968 793 531",
  tenantIdNo: "110526299 (01)",
  checkInDate: "2025-09-02",
  logoUrl: null,
  qrUrl: null,
  items: [
    { id: '1', description: 'តម្លៃបន្ទប់ (Room Price)', oldMonthNo: '', newMonthNo: '', quantity: 1, unitPrice: 80.00, unit: '', currency: 'USD' },
    { id: '2', description: 'វ៉ាយហ្វាយ (Wi-Fi)', oldMonthNo: '', newMonthNo: '', quantity: 1, unitPrice: 5.00, unit: '', currency: 'USD' },
    { id: '3', description: 'អគ្គិសនី (Electricity)', oldMonthNo: '2082', newMonthNo: '', quantity: 0, unitPrice: 1500, unit: 'KWH', currency: 'KHR' },
    { id: '4', description: 'ទឹក (Water)', oldMonthNo: '172', newMonthNo: '', quantity: 0, unitPrice: 2000, unit: 'M³', currency: 'KHR' },
  ],
  rules: [
    "អ្នកជួលត្រូវថែរក្សាបន្ទប់របស់ខ្លួនឯង។",
    "រាល់ការធ្វើឱ្យខូចខាតសម្ភារៈរបស់ផ្ទះជួល អ្នកជួលត្រូវទទួលខុសត្រូវ។",
    "អ្នកជួលមិនមានសិទ្ធិកែប្រែបន្ទប់ដូចជាវាយជញ្ជាំង គំនូរ និងការធ្វើឱ្យខូចជញ្ជាំង។",
    "ហាមដាច់ខាត និងប្រើប្រាស់គ្រឿងញៀន។",
    "ហាមបង្កសំឡេងរំខាន គ្មានសណ្តាប់ធ្នាប់។",
    "សូមរក្សាភាពស្ងប់ស្ងាត់ ប្រសិនបើអ្នកជួលបង្កការរំខានដល់អ្នកជិត នោះម្ចាស់ផ្ទះមានសិទ្ធិបញ្ឈប់ការជួលមុនថ្ងៃកំណត់បាន។",
  ],
  totalUsd: 85.00
};

// Web Audio API Synthesized UI Sound Feedbacks
const playAudioFeedback = (type: 'success' | 'click' | 'delete') => {
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    
    if (type === 'success') {
      const now = ctx.currentTime;
      // Ascending premium electronic bell chime
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now); // D5
      gain1.gain.setValueAtTime(0.12, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.18);

      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880.00, now + 0.08); // A5
      gain2.gain.setValueAtTime(0.12, now + 0.08);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.08);
      osc2.stop(now + 0.3);
      
    } else if (type === 'click') {
      const now = ctx.currentTime;
      // Elegant, soft digital tactile tick
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1400, now);
      osc.frequency.exponentialRampToValueAtTime(600, now + 0.03);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.03);
      
    } else if (type === 'delete') {
      const now = ctx.currentTime;
      // Satisfying soft descending swoosh
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.linearRampToValueAtTime(150, now + 0.18);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.18);
    }
  } catch (e) {
    console.warn('Audio feedback failed:', e);
  }
};

export default function App() {
  // Load draft from localStorage, auto-healing any stale local draft missing the critical Water row
  const [data, setData] = useState<InvoiceData>(() => {
    try {
      const savedDraft = localStorage.getItem('invoice_draft');
      if (savedDraft) {
        const parsed = JSON.parse(savedDraft);
        
        // Auto-heal logic: ensure Water and Electricity rows are guaranteed to exist in active items
        const hasElec = parsed.items?.some((item: any) => item.description.includes('អគ្គិសនី') || item.description.includes('Electricity'));
        const hasWater = parsed.items?.some((item: any) => item.description.includes('ទឹក') || item.description.includes('Water'));
        
        if (parsed.items && (!hasElec || !hasWater)) {
          parsed.items = initialData.items;
        }
        if (parsed.landlordName === "សាង សុវណ្ណា") {
          parsed.landlordName = "សាង សុវណ្ណារតនៈ";
        }
        return { ...initialData, ...parsed };
      }
    } catch (e) {
      console.error('Failed to load invoice draft:', e);
    }
    return initialData;
  });

  // Load saved tenants from localStorage
  const [savedTenants, setSavedTenants] = useState<SavedTenant[]>(() => {
    try {
      const stored = localStorage.getItem('savedTenants');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {}
    localStorage.setItem('savedTenants', JSON.stringify(initialSavedTenants));
    return initialSavedTenants;
  });

  // Selector dropdown states
  const [showNameDropdown, setShowNameDropdown] = useState(false);
  const [showRoomDropdown, setShowRoomDropdown] = useState(false);
  const [showPhoneDropdown, setShowPhoneDropdown] = useState(false);

  // Add / Edit Tenant states
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingTenantName, setEditingTenantName] = useState<string | null>(null);
  const [newTenant, setNewTenant] = useState<SavedTenant>({
    tenantName: '',
    roomNo: '',
    tenantPhone: '',
    tenantIdNo: '',
    checkInDate: new Date().toISOString().split('T')[0],
    roomPrice: 80,
    wifiPrice: 0,
    elecOld: '',
    waterOld: '',
    deposit: 0
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [isDownloading, setIsDownloading] = useState(false);

  // Login & Session States
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return sessionStorage.getItem('isLoggedIn') === 'true';
  });
  const [loginUsername, setLoginUsername] = useState<string>('admin');
  const [loginPassword, setLoginPassword] = useState<string>('123456');
  const [rememberMe, setRememberMe] = useState<boolean>(true);
  const [showPassword, setShowPassword] = useState<boolean>(false);

  // Admin Dashboard and History States
  const [activeTab, setActiveTab] = useState<'invoice' | 'tenants' | 'manualForm' | 'reports' | 'summaryChecker'>('invoice');
  const [adminSearchQuery, setAdminSearchQuery] = useState('');
  const [history, setHistory] = useState<InvoiceHistoryRecord[]>(() => {
    try {
      const stored = localStorage.getItem('invoice_history');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {}
    localStorage.setItem('invoice_history', JSON.stringify(initialHistory));
    return initialHistory;
  });

  const [showManualPayForm, setShowManualPayForm] = useState(false);
  const [manualPay, setManualPay] = useState({
    tenantName: '',
    roomNo: '',
    paymentDate: new Date().toISOString().split('T')[0],
    roomPrice: 80,
    wifiPrice: 0,
    elecPrice: 0,
    waterPrice: 0,
    otherPrice: 0,
    totalUsd: 80
  });

  // Admin stats calculations and filtering
  const [selectedMonth, setSelectedMonth] = useState<string>('all'); // 'all', '01', '02', ..., '12'
  const [activeSlipTab, setActiveSlipTab] = useState<'sovanna' | 'pheak' | 'landlord' | 'yearly'>('sovanna');
  
  const sovannaSlipRef = useRef<HTMLDivElement>(null);
  const pheakSlipRef = useRef<HTMLDivElement>(null);
  const landlordSlipRef = useRef<HTMLDivElement>(null);
  const yearlySlipRef = useRef<HTMLDivElement>(null);
  const customerSummaryInvoiceRef = useRef<HTMLDivElement>(null);
  const [isEditModeActive, setIsEditModeActive] = useState<boolean>(false); // whether manual override edit mode is on
  const [selectedYearlyTenant, setSelectedYearlyTenant] = useState<string>('10');
  const [yearlyViewTab, setYearlyViewTab] = useState<'individual' | 'matrix'>('individual');
  const [statementDate, setStatementDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // New Customer-Centric Monthly Input States (Add, Edit, Delete, Totals)
  const [inputRoomNo, setInputRoomNo] = useState<string>('10');
  const [inputTenantName, setInputTenantName] = useState<string>('គូ គង់មី');
  const [inputMonth, setInputMonth] = useState<string>('10');
  const [inputPaymentDate, setInputPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [inputRoomPrice, setInputRoomPrice] = useState<number>(80);
  const [inputWifiPrice, setInputWifiPrice] = useState<number>(5);
  const [inputElecPrice, setInputElecPrice] = useState<number>(0);
  const [inputWaterPrice, setInputWaterPrice] = useState<number>(0);
  const [inputOtherPrice, setInputOtherPrice] = useState<number>(0);
  const [inputElecUsage, setInputElecUsage] = useState<number>(0);
  const [inputWaterUsage, setInputWaterUsage] = useState<number>(0);
  const [inputStatus, setInputStatus] = useState<'PAID' | 'PENDING'>('PAID');
  const [editingRecordId, setEditingRecordId] = useState<string | null>(null);
  
  // Dedicated Manual Input Form States (as requested by user)
  const [formMonth, setFormMonth] = useState<string>('10');
  const [formRooms, setFormRooms] = useState<number>(0);
  const [formTotalUsd, setFormTotalUsd] = useState<number>(0);
  const [formDeposit, setFormDeposit] = useState<number>(0);
  const [formElectricity, setFormElectricity] = useState<number>(0);
  const [formWater, setFormWater] = useState<number>(0);
  const [formWifi, setFormWifi] = useState<number>(0);

  const [customMonthlyData, setCustomMonthlyData] = useState<Record<string, { roomsCount: number; totalUsd: number; deposit: number; electricityRevenue: number; waterRevenue: number; wifiRevenue?: number; useCustom: boolean }>>(() => {
    try {
      const stored = localStorage.getItem('custom_monthly_data');
      if (stored) return JSON.parse(stored);
    } catch {}
    return {};
  });

  // Save manual inputs to localStorage
  const saveCustomMonthData = (monthStr: string, field: 'roomsCount' | 'totalUsd' | 'deposit' | 'electricityRevenue' | 'waterRevenue' | 'wifiRevenue' | 'useCustom', value: any) => {
    setCustomMonthlyData(prev => {
      const existing = prev[monthStr] || { roomsCount: 0, totalUsd: 0, deposit: 0, electricityRevenue: 0, waterRevenue: 0, wifiRevenue: 0, useCustom: false };
      const updated = {
        ...prev,
        [monthStr]: {
          ...existing,
          [field]: value
        }
      };
      localStorage.setItem('custom_monthly_data', JSON.stringify(updated));
      return updated;
    });
  };

  // Filter history records based on selected month
  const getFilteredHistory = () => {
    if (selectedMonth === 'all') return history;
    return history.filter(h => h.paymentDate.startsWith(`2026-${selectedMonth}`));
  };

  const filteredHistory = getFilteredHistory();

  // Monthly stats helper for rendering the comprehensive comparison table and calculating metrics
  const getMonthlyStats = (monthIndex: number) => {
    const monthStr = monthIndex.toString().padStart(2, '0');
    const monthPrefix = `2026-${monthStr}`;
    const monthlyRecords = history.filter(h => h.paymentDate.startsWith(monthPrefix));
    
    // Auto-calculated system values (saved automatically)
    const autoRoomsCount = monthlyRecords.length;
    const autoRoomRevenue = monthlyRecords.reduce((sum, r) => sum + r.roomPrice, 0);
    const autoTotalUsd = monthlyRecords.reduce((sum, r) => sum + r.totalUsd, 0);
    const autoElectricityRevenue = monthlyRecords.reduce((sum, r) => sum + r.elecPrice, 0);
    const autoWaterRevenue = monthlyRecords.reduce((sum, r) => sum + r.waterPrice, 0);
    const autoWifiRevenue = monthlyRecords.reduce((sum, r) => sum + r.wifiPrice, 0);
    
    // Auto deposit: sum of deposits of active tenants rented in this month
    const autoDeposit = savedTenants.filter(t => t.roomNo && monthlyRecords.some(r => r.roomNo === t.roomNo)).reduce((sum, t) => sum + (t.deposit || 0), 0);
    
    // Custom manual override values
    const custom = customMonthlyData[monthStr] || { roomsCount: 0, totalUsd: 0, deposit: 0, electricityRevenue: 0, waterRevenue: 0, wifiRevenue: 0, useCustom: false };
    
    const useManual = custom.useCustom;
    const roomsCount = useManual ? (custom.roomsCount || 0) : autoRoomsCount;
    const enteredUsd = useManual ? (custom.totalUsd || 0) : autoTotalUsd;
    const deposit = useManual ? (custom.deposit || 0) : autoDeposit;
    const electricityRevenue = useManual ? (custom.electricityRevenue || 0) : autoElectricityRevenue;
    const waterRevenue = useManual ? (custom.waterRevenue || 0) : autoWaterRevenue;
    const wifiRevenue = useManual ? (custom.wifiRevenue || 0) : autoWifiRevenue;
    
    // Room Revenue (Total room revenue)
    // For manual entry, the entered totalUsd represents pure Room Rent, so room revenue is exactly enteredUsd
    // For auto system entry, room revenue is the sum of room rents from automatic history records
    const roomRevenue = useManual
      ? enteredUsd
      : monthlyRecords.reduce((sum, r) => sum + r.roomPrice, 0);

    // Total USD collected including room rents and utilities
    const totalUsd = useManual
      ? (roomRevenue + electricityRevenue + waterRevenue + wifiRevenue)
      : autoTotalUsd;
    
    // NEW FORMULA:
    // 1. Sovanna gets 20% of Room Revenue + 100% of Electricity + 100% of Water + 100% of Wifi
    const sovannaSalary = (roomRevenue * 0.20) + electricityRevenue + waterRevenue + wifiRevenue;
    
    // 2. Pheak gets $15 per room rented for months 1-9, and $10 per room starting from month 10 (October)
    const pheakRate = monthIndex >= 10 ? 10 : 15;
    const pheakSalary = roomsCount * pheakRate;
    
    // 3. Landlord gets the rest of the Room Revenue after paying Sovanna (20%) and Pheak ($15/room)
    const landlordNet = roomRevenue - (roomRevenue * 0.20) - pheakSalary;
    
    return {
      monthStr,
      autoRoomsCount,
      autoRoomRevenue,
      autoTotalUsd,
      autoElectricityRevenue,
      autoWaterRevenue,
      autoWifiRevenue,
      autoDeposit,
      
      customRoomsCount: custom.roomsCount || 0,
      customTotalUsd: custom.totalUsd || 0,
      customDeposit: custom.deposit || 0,
      customElectricityRevenue: custom.electricityRevenue || 0,
      customWaterRevenue: custom.waterRevenue || 0,
      customWifiRevenue: custom.wifiRevenue || 0,
      
      useCustom: custom.useCustom,
      
      roomsCount,
      totalUsd,
      deposit,
      electricityRevenue,
      waterRevenue,
      wifiRevenue,
      roomRevenue,
      sovannaSalary,
      pheakSalary,
      landlordNet
    };
  };

  // Selected Month dynamic metrics
  const getSelectedMonthMetrics = () => {
    if (selectedMonth === 'all') {
      let roomsCount = 0;
      let totalUsd = 0;
      let roomRevenueSum = 0;
      let utilPriceSum = 0;
      let otherPriceSum = 0;
      
      for (let m = 1; m <= 12; m++) {
        const stats = getMonthlyStats(m);
        roomsCount += stats.roomsCount;
        totalUsd += stats.totalUsd;
        roomRevenueSum += stats.roomRevenue;
        
        // Accumulate utils and other from history or proportional
        const monthPrefix = `2026-${m.toString().padStart(2, '0')}`;
        const monthlyRecords = history.filter(h => h.paymentDate.startsWith(monthPrefix));
        utilPriceSum += monthlyRecords.reduce((sum, r) => sum + r.elecPrice + r.waterPrice, 0);
        otherPriceSum += monthlyRecords.reduce((sum, r) => sum + r.wifiPrice + r.otherPrice, 0);
      }
      
      return {
        totalIncome: totalUsd,
        totalRoomRevenue: roomRevenueSum,
        totalUtilRevenue: utilPriceSum,
        totalWifiRevenue: history.reduce((acc, curr) => acc + curr.wifiPrice, 0),
        totalOtherRevenue: history.reduce((acc, curr) => acc + curr.otherPrice, 0),
        totalRoomsRented: roomsCount
      };
    } else {
      const stats = getMonthlyStats(parseInt(selectedMonth));
      const monthPrefix = `2026-${selectedMonth}`;
      const monthlyRecords = history.filter(h => h.paymentDate.startsWith(monthPrefix));
      const totalUtil = monthlyRecords.reduce((sum, r) => sum + r.elecPrice + r.waterPrice, 0);
      const totalWifi = monthlyRecords.reduce((sum, r) => sum + r.wifiPrice, 0);
      const totalOther = monthlyRecords.reduce((sum, r) => sum + r.otherPrice, 0);
      
      return {
        totalIncome: stats.totalUsd,
        totalRoomRevenue: stats.roomRevenue,
        totalUtilRevenue: totalUtil,
        totalWifiRevenue: totalWifi,
        totalOtherRevenue: totalOther,
        totalRoomsRented: stats.roomsCount
      };
    }
  };

  const {
    totalIncome,
    totalRoomRevenue,
    totalUtilRevenue,
    totalWifiRevenue,
    totalOtherRevenue,
    totalRoomsRented
  } = getSelectedMonthMetrics();

  // Yearly absolute totals (for cumulative sums)
  const yearlyTotalIncome = [1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).totalUsd, 0);
  const yearlyTotalRoomRevenue = [1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).roomRevenue, 0);
  const yearlyTotalUtilRevenue = history.reduce((acc, curr) => acc + curr.elecPrice + curr.waterPrice, 0);
  const yearlyTotalWifiRevenue = history.reduce((acc, curr) => acc + curr.wifiPrice, 0);
  const yearlyTotalOtherRevenue = history.reduce((acc, curr) => acc + curr.otherPrice, 0);

  // Dynamic Salaries for Selected Month (NEW FORMULA)
  const isAllMonths = selectedMonth === 'all';
  
  const sovannaSalaryFiltered = isAllMonths
    ? [1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).sovannaSalary, 0)
    : getMonthlyStats(parseInt(selectedMonth)).sovannaSalary;

  const pheakSalaryFiltered = isAllMonths
    ? [1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).pheakSalary, 0)
    : getMonthlyStats(parseInt(selectedMonth)).pheakSalary;

  const landlordNetFiltered = isAllMonths
    ? [1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).landlordNet, 0)
    : getMonthlyStats(parseInt(selectedMonth)).landlordNet;

  const utilsAndWifiFiltered = isAllMonths
    ? [1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => {
        const stats = getMonthlyStats(m);
        return sum + stats.electricityRevenue + stats.waterRevenue + stats.wifiRevenue;
      }, 0)
    : (() => {
        const stats = getMonthlyStats(parseInt(selectedMonth));
        return stats.electricityRevenue + stats.waterRevenue + stats.wifiRevenue;
      })();

  const handleManualPayChange = (field: string, value: number) => {
    setManualPay(prev => {
      const updated = { ...prev, [field]: value };
      updated.totalUsd = Number(updated.roomPrice) + Number(updated.wifiPrice) + Number(updated.elecPrice) + Number(updated.waterPrice) + Number(updated.otherPrice);
      return updated;
    });
  };

  // Generate monthly revenue comparison chart data for the current year
  const getMonthlyChartData = () => {
    const currentYear = new Date().getFullYear().toString(); // e.g. "2026"
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    
    return monthNames.map((name, index) => {
      const monthStr = (index + 1).toString().padStart(2, '0'); // "01", "02", ...
      const monthPrefix = `${currentYear}-${monthStr}`; // "2026-01"
      
      const records = history.filter(h => h.paymentDate.startsWith(monthPrefix));
      
      const room = records.reduce((sum, r) => sum + r.roomPrice, 0);
      const utils = records.reduce((sum, r) => sum + r.elecPrice + r.waterPrice, 0);
      const other = records.reduce((sum, r) => sum + r.wifiPrice + r.otherPrice, 0);
      const total = records.reduce((sum, r) => sum + r.totalUsd, 0);
      
      return {
        name,
        "Room Rent": Number(room.toFixed(2)),
        "Utilities": Number(utils.toFixed(2)),
        "Wifi & Other": Number(other.toFixed(2)),
        "Total Revenue": Number(total.toFixed(2))
      };
    });
  };

  const monthlyChartData = getMonthlyChartData();

  const invoiceRef = useRef<HTMLDivElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const qrInputRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  // Pre-populate form inputs when selecting a month to edit (Electricity and Water are displayed in Riel KHR: 1$ = 4000៛)
  useEffect(() => {
    const stats = getMonthlyStats(parseInt(formMonth));
    setFormRooms(stats.useCustom ? stats.customRoomsCount : stats.autoRoomsCount);
    setFormTotalUsd(stats.useCustom ? stats.customTotalUsd : stats.autoTotalUsd);
    setFormDeposit(stats.useCustom ? stats.customDeposit : stats.autoDeposit);
    setFormElectricity(Math.round((stats.useCustom ? stats.customElectricityRevenue : stats.autoElectricityRevenue) * 4000));
    setFormWater(Math.round((stats.useCustom ? stats.customWaterRevenue : stats.autoWaterRevenue) * 4000));
    setFormWifi(stats.useCustom ? stats.customWifiRevenue : stats.autoWifiRevenue);
  }, [formMonth, customMonthlyData]);

  // Sync draft to localStorage on change
  useEffect(() => {
    localStorage.setItem('invoice_draft', JSON.stringify(data));
  }, [data]);

  // Automatically calculate electricity and water prices whenever usage numbers are entered (1 KWH = 1500៛, 1 M³ = 2000៛)
  useEffect(() => {
    const elecRiel = Number(inputElecUsage) * 1500;
    setInputElecPrice(elecRiel / 4000);
  }, [inputElecUsage]);

  useEffect(() => {
    const waterRiel = Number(inputWaterUsage) * 2000;
    setInputWaterPrice(waterRiel / 4000);
  }, [inputWaterUsage]);

  // Debounced Auto-save of Tenant information into Saved Tenant directory to capture live edits
  useEffect(() => {
    const timer = setTimeout(() => {
      const name = data.tenantName?.trim();
      if (!name) return;

      const roomItem = data.items.find(item => item.description.includes('តម្លៃបន្ទប់') || item.description.includes('Room Price'));
      const wifiItem = data.items.find(item => item.description.includes('វ៉ាយហ្វាយ') || item.description.includes('Wi-Fi'));
      const elecItem = data.items.find(item => item.description.includes('អគ្គិសនី') || item.description.includes('Electricity'));
      const waterItem = data.items.find(item => item.description.includes('ទឹក') || item.description.includes('Water'));

      setSavedTenants(prev => {
        const existingIdx = prev.findIndex(t => t.tenantName.trim().toLowerCase() === name.toLowerCase());
        let updatedList = [...prev];
        
        const existingRecord = existingIdx > -1 ? prev[existingIdx] : null;

        const newRecord: SavedTenant = {
          tenantName: name,
          roomNo: data.roomNo || existingRecord?.roomNo || '',
          tenantPhone: data.tenantPhone || existingRecord?.tenantPhone || '',
          tenantIdNo: data.tenantIdNo || existingRecord?.tenantIdNo || '',
          checkInDate: data.checkInDate || existingRecord?.checkInDate || '',
          roomPrice: roomItem ? roomItem.unitPrice : (existingRecord?.roomPrice ?? 80),
          wifiPrice: wifiItem ? wifiItem.unitPrice : (existingRecord?.wifiPrice ?? 0),
          elecOld: elecItem ? elecItem.oldMonthNo : (existingRecord?.elecOld ?? ''),
          waterOld: waterItem ? waterItem.oldMonthNo : (existingRecord?.waterOld ?? ''),
        };

        if (existingIdx > -1) {
          updatedList[existingIdx] = {
            ...updatedList[existingIdx],
            ...newRecord,
          };
        } else {
          updatedList.push(newRecord);
        }
        localStorage.setItem('savedTenants', JSON.stringify(updatedList));
        return updatedList;
      });
    }, 1000);

    return () => clearTimeout(timer);
  }, [data.tenantName, data.roomNo, data.tenantPhone, data.tenantIdNo, data.checkInDate, data.items]);

  const calculateTotal = (items: InvoiceItem[]) => {
    return items.reduce((acc, item) => {
      const amount = item.quantity * item.unitPrice;
      return acc + (item.currency === 'KHR' ? amount / 4000 : amount);
    }, 0);
  };

  const handleReset = () => {
    playAudioFeedback('delete');
    setData({
      ...initialData,
      tenantName: "",
      roomNo: "",
      tenantPhone: "",
      tenantIdNo: "",
      checkInDate: new Date().toISOString().split('T')[0],
      items: initialData.items.map(item => {
        const isUtility = item.description.includes('អគ្គិសនី') || 
                          item.description.includes('Electricity') || 
                          item.description.includes('ទឹក') || 
                          item.description.includes('Water');
        return {
          ...item,
          oldMonthNo: "",
          newMonthNo: "",
          quantity: isUtility ? 0 : 1
        };
      }),
      totalUsd: 0
    });
  };

  const addItem = (type: 'normal' | 'electricity' | 'water') => {
    let newItem: InvoiceItem;
    
    if (type === 'electricity') {
      newItem = {
        id: 'elec-' + Math.random().toString(36).substr(2, 9),
        description: 'អគ្គិសនី (Electricity)',
        oldMonthNo: '',
        newMonthNo: '',
        quantity: 0,
        unitPrice: 1500,
        unit: 'KWH',
        currency: 'KHR'
      };
    } else if (type === 'water') {
      newItem = {
        id: 'water-' + Math.random().toString(36).substr(2, 9),
        description: 'ទឹក (Water)',
        oldMonthNo: '',
        newMonthNo: '',
        quantity: 0,
        unitPrice: 2000,
        unit: 'M³',
        currency: 'KHR'
      };
    } else {
      newItem = {
        id: Math.random().toString(36).substr(2, 9),
        description: 'New Item (សេវាកម្មថ្មី / New Service)',
        oldMonthNo: '',
        newMonthNo: '',
        quantity: 1,
        unitPrice: 0,
        unit: '',
        currency: 'USD'
      };
    }
    
    setData(prev => {
      const updatedItems = [...prev.items, newItem];
      return {
        ...prev,
        items: updatedItems,
        totalUsd: calculateTotal(updatedItems)
      };
    });
  };

  const removeItem = (id: string) => {
    const newItems = data.items.filter(item => item.id !== id);
    setData({ ...data, items: newItems, totalUsd: calculateTotal(newItems) });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'logo' | 'qr') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setData(prev => ({
          ...prev,
          [type === 'logo' ? 'logoUrl' : 'qrUrl']: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const updateItem = (id: string, field: keyof InvoiceItem, value: any) => {
    const newItems = data.items.map(item => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        
        // Auto-calculate quantity for utilities (Electricity/Water)
        if (field === 'oldMonthNo' || field === 'newMonthNo') {
          const old = parseFloat(updatedItem.oldMonthNo) || 0;
          const newVal = parseFloat(updatedItem.newMonthNo) || 0;
          if (newVal >= old) {
            updatedItem.quantity = newVal - old;
          } else {
            updatedItem.quantity = 0;
          }
        }
        
        return updatedItem;
      }
      return item;
    });
    
    setData({ ...data, items: newItems, totalUsd: calculateTotal(newItems) });
  };

  // Select a tenant and load their master information, pricing, and old meter readings
  const handleSelectTenant = (tenant: SavedTenant) => {
    playAudioFeedback('click');
    setData(prev => {
      const updatedItems = prev.items.map(item => {
        if (item.description.includes('តម្លៃបន្ទប់') || item.description.includes('Room Price')) {
          return { ...item, unitPrice: tenant.roomPrice, quantity: 1 };
        }
        if (item.description.includes('វ៉ាយហ្វាយ') || item.description.includes('Wi-Fi')) {
          return { ...item, unitPrice: tenant.wifiPrice, quantity: 1 };
        }
        if (item.description.includes('អគ្គិសនី') || item.description.includes('Electricity')) {
          return { ...item, oldMonthNo: tenant.elecOld, newMonthNo: '', quantity: 0 };
        }
        if (item.description.includes('ទឹក') || item.description.includes('Water')) {
          return { ...item, oldMonthNo: tenant.waterOld, newMonthNo: '', quantity: 0 };
        }
        return item;
      });

      return {
        ...prev,
        tenantName: tenant.tenantName,
        roomNo: tenant.roomNo,
        tenantPhone: tenant.tenantPhone,
        tenantIdNo: tenant.tenantIdNo,
        checkInDate: tenant.checkInDate,
        items: updatedItems,
        totalUsd: calculateTotal(updatedItems)
      };
    });
    
    // Auto-populate Total Summary Checker inputs for seamless navigation
    setInputRoomNo(tenant.roomNo);
    setInputTenantName(tenant.tenantName);
  };

  const handleDeleteTenant = (nameToDelete: string) => {
    playAudioFeedback('delete');
    setSavedTenants(prev => {
      const updatedList = prev.filter(t => t.tenantName !== nameToDelete);
      localStorage.setItem('savedTenants', JSON.stringify(updatedList));
      return updatedList;
    });
  };

  // Start editing tenant details in the sidebar form
  const handleStartEditTenant = (tenant: SavedTenant) => {
    setNewTenant(tenant);
    setEditingTenantName(tenant.tenantName);
    setShowAddForm(true);
    
    // Smooth scroll to the form if on mobile
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 100);
  };

  // Handle Add/Edit Form submission
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTenant.tenantName.trim() || !newTenant.roomNo.trim()) {
      alert("សូមបញ្ចូលឈ្មោះអ្នកជួល និងលេខបន្ទប់! / Please enter Tenant Name and Room Number!");
      return;
    }

    setSavedTenants(prev => {
      let updatedList = [...prev];
      
      if (editingTenantName) {
        // Edit Mode: Replace the original record (matched by original name) with edited values
        const idx = updatedList.findIndex(t => t.tenantName.toLowerCase() === editingTenantName.toLowerCase());
        if (idx > -1) {
          updatedList[idx] = newTenant;
        } else {
          updatedList.push(newTenant);
        }
      } else {
        // Add Mode: Check duplicate safety
        const exists = updatedList.some(t => t.tenantName.toLowerCase() === newTenant.tenantName.toLowerCase() || t.roomNo === newTenant.roomNo);
        if (exists) {
          if (!confirm(`អ្នកជួល ឬលេខបន្ទប់នេះមានរួចហើយនៅក្នុងបញ្ជី។ តើអ្នកចង់សរសេរជាន់លើព័ត៌មានដែរឬទេ? / This tenant or room number already exists in the list. Do you want to overwrite the information?`)) {
            return prev;
          }
        }
        updatedList = updatedList.filter(t => t.tenantName.toLowerCase() !== newTenant.tenantName.toLowerCase() && t.roomNo !== newTenant.roomNo);
        updatedList.push(newTenant);
      }
      
      localStorage.setItem('savedTenants', JSON.stringify(updatedList));
      return updatedList;
    });

    // If the edited tenant is currently active on the invoice, update the invoice view instantly!
    if (editingTenantName && data.tenantName.toLowerCase() === editingTenantName.toLowerCase()) {
      handleSelectTenant(newTenant);
    }

    playAudioFeedback('success');
    alert(editingTenantName ? `បានធ្វើបច្ចុប្បន្នភាពព័ត៌មានបន្ទប់ ${newTenant.roomNo} ដោយជោគជ័យ! / Updated room ${newTenant.roomNo} info successfully!` : `បានបន្ថែមបន្ទប់ថ្មី ${newTenant.roomNo} ដោយជោគជ័យ! / Added new room ${newTenant.roomNo} successfully!`);
    
    // Close and reset form
    setShowAddForm(false);
    setEditingTenantName(null);
    setNewTenant({
      tenantName: '',
      roomNo: '',
      tenantPhone: '',
      tenantIdNo: '',
      checkInDate: new Date().toISOString().split('T')[0],
      roomPrice: 80,
      wifiPrice: 0,
      elecOld: '',
      waterOld: '',
      deposit: 0
    });
  };

  const handleCancelForm = () => {
    setShowAddForm(false);
    setEditingTenantName(null);
    setNewTenant({
      tenantName: '',
      roomNo: '',
      tenantPhone: '',
      tenantIdNo: '',
      checkInDate: new Date().toISOString().split('T')[0],
      roomPrice: 80,
      wifiPrice: 0,
      elecOld: '',
      waterOld: '',
      deposit: 0
    });
  };

  const handleLogout = () => {
    playAudioFeedback('click');
    setIsLoggedIn(false);
    sessionStorage.removeItem('isLoggedIn');
  };

  // Cycle utility readings silent helper: update current new meter readings as starting old readings for next month
  const handleCycleReadingsSilent = () => {
    const elecItem = data.items.find(item => item.description.includes('អគ្គិសនី') || item.description.includes('Electricity'));
    const waterItem = data.items.find(item => item.description.includes('ទឹក') || item.description.includes('Water'));
    
    if (!elecItem || !waterItem) return;
    
    const newElec = elecItem.newMonthNo?.trim();
    const newWater = waterItem.newMonthNo?.trim();
    
    const name = data.tenantName?.trim();
    if (!name) return;
    
    setSavedTenants(prev => {
      const updated = prev.map(tenant => {
        if (tenant.tenantName.toLowerCase() === name.toLowerCase()) {
          return {
            ...tenant,
            elecOld: newElec || tenant.elecOld,
            waterOld: newWater || tenant.waterOld
          };
        }
        return tenant;
      });
      localStorage.setItem('savedTenants', JSON.stringify(updated));
      return updated;
    });

    setData(prev => {
      const cycledItems = prev.items.map(item => {
        if (item.description.includes('អគ្គិសនី') || item.description.includes('Electricity')) {
          return { ...item, oldMonthNo: newElec || item.oldMonthNo, newMonthNo: '', quantity: 0 };
        }
        if (item.description.includes('ទឹក') || item.description.includes('Water')) {
          return { ...item, oldMonthNo: newWater || item.oldMonthNo, newMonthNo: '', quantity: 0 };
        }
        return item;
      });
      return {
        ...prev,
        items: cycledItems,
        totalUsd: calculateTotal(cycledItems)
      };
    });
  };

  // Cycle utility readings (manual triggers with feedback)
  const handleCycleReadings = () => {
    const elecItem = data.items.find(item => item.description.includes('អគ្គិសនី') || item.description.includes('Electricity'));
    const waterItem = data.items.find(item => item.description.includes('ទឹក') || item.description.includes('Water'));
    
    if (!elecItem || !waterItem) return;
    
    const newElec = elecItem.newMonthNo?.trim();
    const newWater = waterItem.newMonthNo?.trim();
    
    if (!newElec && !newWater) {
      alert("សូមបញ្ចូលលេខវ៉ាត់ថ្មី (ភ្លើង/ទឹក) មុនពេលបិទលេខ! / Please enter new meter readings (Electricity/Water) before cycles!");
      return;
    }
    
    const name = data.tenantName?.trim();
    if (!name) {
      alert("វិក្កយបត្របច្ចុប្បន្នមិនទាន់មានឈ្មោះអ្នកជួលទេ! / Current invoice has no tenant name!");
      return;
    }
    
    handleCycleReadingsSilent();
    playAudioFeedback('success');
    alert(`ការបិទលេខបានជោគជ័យសម្រាប់បន្ទប់ P.${data.roomNo}! លេខវ៉ាត់ថ្មីត្រូវបានកំណត់ជាលេខវ៉ាត់ចាស់សម្រាប់ខែក្រោយ។ / Meter cycles succeeded for room P.${data.roomNo}! New readings set as old readings for next month.`);
  };

  const handlePrint = () => {
    playAudioFeedback('click');
    const elecItem = data.items.find(item => item.description.includes('អគ្គិសនី') || item.description.includes('Electricity'));
    const waterItem = data.items.find(item => item.description.includes('ទឹក') || item.description.includes('Water'));
    const newElec = elecItem?.newMonthNo?.trim();
    const newWater = waterItem?.newMonthNo?.trim();

    if (newElec || newWater) {
      if (confirm(`អ្នកបានបញ្ចូលលេខវ៉ាត់ថ្មី (ភ្លើង: ${newElec || '—'}, ទឹក: ${newWater || '—'})។ តើអ្នកចង់បិទលេខដោយស្វ័យប្រវត្ត ដើម្បីកំណត់លេខទាំងនេះជាលេខវ៉ាត់ចាស់សម្រាប់ខែក្រោយដែរឬទេ? / You entered new readings (Electricity: ${newElec || '—'}, Water: ${newWater || '—'}). Do you want to automatically CYCLE READINGS to set them as OLD READINGS for next month's invoice?`)) {
        handleCycleReadingsSilent();
      }
    }
    window.print();
  };

  const handleDownloadImage = async () => {
    if (!invoiceRef.current) return;
    
    const elecItem = data.items.find(item => item.description.includes('អគ្គិសនី') || item.description.includes('Electricity'));
    const waterItem = data.items.find(item => item.description.includes('ទឹក') || item.description.includes('Water'));
    const newElec = elecItem?.newMonthNo?.trim();
    const newWater = waterItem?.newMonthNo?.trim();

    if (newElec || newWater) {
      if (confirm(`អ្នកបានបញ្ចូលលេខវ៉ាត់ថ្មី (ភ្លើង: ${newElec || '—'}, ទឹក: ${newWater || '—'})។ តើអ្នកចង់បិទលេខដោយស្វ័យប្រវត្ត ដើម្បីកំណត់លេខទាំងនេះជាលេខវ៉ាត់ចាស់សម្រាប់ខែក្រោយដែរឬទេ? / You entered new readings (Electricity: ${newElec || '—'}, Water: ${newWater || '—'}). Do you want to automatically CYCLE READINGS to set them as OLD READINGS for next month's invoice?`)) {
        handleCycleReadingsSilent();
      }
    }

    playAudioFeedback('click');
    setIsDownloading(true);
    try {
      const dataUrl = await toPng(invoiceRef.current, {
        pixelRatio: 4,
        cacheBust: true,
        style: {
          margin: '0',
          borderRadius: '0',
          boxShadow: 'none',
        }
      });
      
      const link = document.createElement('a');
      link.download = `Invoice-${data.tenantName || 'Room'}-${data.roomNo || 'Rent'}.png`;
      link.href = dataUrl;
      link.click();
      playAudioFeedback('success');
    } catch (err) {
      console.error('Download failed:', err);
      alert('Failed to download image. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadSlip = async (ref: React.RefObject<HTMLDivElement | null>, filename: string) => {
    if (!ref.current) return;
    playAudioFeedback('click');
    setIsDownloading(true);
    try {
      const dataUrl = await toPng(ref.current, {
        pixelRatio: 4,
        cacheBust: true,
        style: {
          margin: '0',
          borderRadius: '0',
          boxShadow: 'none',
        }
      });
      const link = document.createElement('a');
      link.download = `${filename}.png`;
      link.href = dataUrl;
      link.click();
      playAudioFeedback('success');
    } catch (err) {
      console.error('Download slip failed:', err);
      alert('មិនអាចទាញយកឯកសាររូបភាពកម្រិត 4K បានទេ។ សូមព្យាយាមម្តងទៀត! / Failed to export 4K image. Please try again!');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleTopDownload = () => {
    playAudioFeedback('click');
    if (activeTab === 'invoice') {
      handleDownloadImage();
    } else if (activeTab === 'summaryChecker') {
      const filename = `Invoice-Total-Room-${inputRoomNo}-${inputTenantName.trim().replace(/\s+/g, '-')}`;
      handleDownloadSlip(customerSummaryInvoiceRef, filename);
    } else if (activeTab === 'reports') {
      if (selectedMonth === 'all') {
        alert("សូមជ្រើសរើសខែជាក់លាក់ណាមួយដើម្បីទាញយកប័ណ្ណទូទាត់! / Please select a specific month from the reports table to download its 4K PNG report!");
        return;
      }
      const mIndex = parseInt(selectedMonth);
      const filename = activeSlipTab === 'yearly'
        ? `Bao-Cao-Thu-Nhap-Ca-Nam-2026`
        : `Payslip-Thang-${mIndex}-${activeSlipTab === 'sovanna' ? 'Sovanna' : activeSlipTab === 'pheak' ? 'Pheak' : 'Landlord'}`;
      const ref = activeSlipTab === 'sovanna'
        ? sovannaSlipRef
        : activeSlipTab === 'pheak'
          ? pheakSlipRef
          : activeSlipTab === 'landlord'
            ? landlordSlipRef
            : yearlySlipRef;
      handleDownloadSlip(ref, filename);
    } else {
      // For tenants or manualForm, auto navigate to the invoice view and trigger download
      setActiveTab('invoice');
      setTimeout(() => {
        handleDownloadImage();
      }, 300);
    }
  };

  // Save current active invoice into history ledger as paid
  const handleMarkAsPaid = () => {
    if (!data.tenantName.trim() || !data.roomNo.trim()) {
      alert("សូមបញ្ចូល ឬជ្រើសរើសឈ្មោះអ្នកជួល និងលេខបន្ទប់ជាមុនសិន! / Please enter or select Tenant Name and Room Number first!");
      return;
    }

    // Auto-set monthly check-off status to true for this tenant
    setSavedTenants(prev => {
      const updated = prev.map(t => {
        if (t.roomNo === data.roomNo) {
          return { ...t, isPaid: true };
        }
        return t;
      });
      localStorage.setItem('savedTenants', JSON.stringify(updated));
      return updated;
    });

    const roomItem = data.items.find(item => item.description.includes('តម្លៃបន្ទប់') || item.description.includes('Room Price'));
    const wifiItem = data.items.find(item => item.description.includes('វ៉ាយហ្វាយ') || item.description.includes('Wi-Fi'));
    const elecItem = data.items.find(item => item.description.includes('អគ្គិសនី') || item.description.includes('Electricity'));
    const waterItem = data.items.find(item => item.description.includes('ទឹក') || item.description.includes('Water'));
    const otherItems = data.items.filter(item => 
      !item.description.includes('តម្លៃបន្ទប់') && !item.description.includes('Room Price') &&
      !item.description.includes('វ៉ាយហ្វាយ') && !item.description.includes('Wi-Fi') &&
      !item.description.includes('អគ្គិសនី') && !item.description.includes('Electricity') &&
      !item.description.includes('ទឹក') && !item.description.includes('Water')
    );

    const roomPrice = roomItem ? roomItem.unitPrice : 0;
    const wifiPrice = wifiItem ? wifiItem.unitPrice : 0;
    
    const getPriceInUsd = (item: InvoiceItem | undefined) => {
      if (!item) return 0;
      const amt = item.quantity * item.unitPrice;
      return item.currency === 'KHR' ? amt / 4000 : amt;
    };

    const elecPrice = getPriceInUsd(elecItem);
    const waterPrice = getPriceInUsd(waterItem);
    const otherPrice = otherItems.reduce((acc, item) => acc + getPriceInUsd(item), 0);

    const newRecord: InvoiceHistoryRecord = {
      id: 'h-' + Date.now(),
      tenantName: data.tenantName,
      roomNo: data.roomNo,
      paymentDate: new Date().toISOString().split('T')[0],
      roomPrice,
      wifiPrice,
      elecPrice,
      waterPrice,
      otherPrice,
      totalUsd: data.totalUsd,
      elecUsage: elecItem ? (parseFloat(elecItem.newMonthNo) - parseFloat(elecItem.oldMonthNo) || 0) : 0,
      waterUsage: waterItem ? (parseFloat(waterItem.newMonthNo) - parseFloat(waterItem.oldMonthNo) || 0) : 0,
      status: 'PAID'
    };

    setHistory(prev => {
      const updated = [newRecord, ...prev];
      localStorage.setItem('invoice_history', JSON.stringify(updated));
      return updated;
    });

    playAudioFeedback('success');

    // Check if utilities have new values and offer cycling
    const hasNewElec = elecItem?.newMonthNo?.trim();
    const hasNewWater = waterItem?.newMonthNo?.trim();
    if (hasNewElec || hasNewWater) {
      if (confirm(`បានកត់ត្រាការបង់ប្រាក់ដោយជោគជ័យសម្រាប់បន្ទប់ P.${data.roomNo} ជាមួយនឹងទឹកប្រាក់សរុប $${data.totalUsd.toFixed(2)}!\n\nតើអ្នកចង់បិទលេខវ៉ាត់អគ្គិសនី/ទឹកស្អាតនេះជាលេខចាស់សម្រាប់ខែក្រោយដោយស្វ័យប្រវត្តដែរឬទេ? / Payment recorded successfully for room P.${data.roomNo} with total $${data.totalUsd.toFixed(2)}!\n\nDo you want to automatically CYCLE READINGS to set these as old readings for next month?`)) {
        handleCycleReadingsSilent();
      }
    } else {
      alert(`បានកត់ត្រាការបង់ប្រាក់ដោយជោគជ័យសម្រាប់បន្ទប់ P.${data.roomNo} ជាមួយនឹងទឹកប្រាក់សរុប $${data.totalUsd.toFixed(2)}! / Payment recorded successfully for room P.${data.roomNo} with total $${data.totalUsd.toFixed(2)}!`);
    }
  };

  // Submit manual payment transaction
  const handleManualPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualPay.tenantName.trim() || !manualPay.roomNo.trim()) {
      alert("សូមជ្រើសរើស ឬបញ្ចូលឈ្មោះអ្នកជួល និងលេខបន្ទប់! / Please select or enter Tenant Name and Room Number!");
      return;
    }

    const newRecord: InvoiceHistoryRecord = {
      id: 'h-' + Date.now(),
      tenantName: manualPay.tenantName,
      roomNo: manualPay.roomNo,
      paymentDate: manualPay.paymentDate,
      roomPrice: Number(manualPay.roomPrice) || 0,
      wifiPrice: Number(manualPay.wifiPrice) || 0,
      elecPrice: Number(manualPay.elecPrice) || 0,
      waterPrice: Number(manualPay.waterPrice) || 0,
      otherPrice: Number(manualPay.otherPrice) || 0,
      totalUsd: Number(manualPay.totalUsd) || 0,
      elecUsage: 0,
      waterUsage: 0,
      status: 'PAID'
    };

    setHistory(prev => {
      const updated = [newRecord, ...prev];
      localStorage.setItem('invoice_history', JSON.stringify(updated));
      return updated;
    });

    playAudioFeedback('success');

    alert(`បានកត់ត្រាការទូទាត់ដោយដៃសម្រាប់បន្ទប់ P.${manualPay.roomNo} ដោយជោគជ័យ! / Manual payment recorded successfully for room P.${manualPay.roomNo}!`);
    
    // Reset manual payment form
    setManualPay({
      tenantName: '',
      roomNo: '',
      paymentDate: new Date().toISOString().split('T')[0],
      roomPrice: 80,
      wifiPrice: 0,
      elecPrice: 0,
      waterPrice: 0,
      otherPrice: 0,
      totalUsd: 80
    });
    setShowManualPayForm(false);
  };

  // Submit manual monthly stats override form
  const handleSaveManualForm = (e: React.FormEvent) => {
    e.preventDefault();
    const monthStr = formMonth.padStart(2, '0');
    
    setCustomMonthlyData(prev => {
      const updated = {
        ...prev,
        [monthStr]: {
          roomsCount: Number(formRooms),
          totalUsd: Number(formTotalUsd),
          deposit: Number(formDeposit),
          electricityRevenue: Number(formElectricity) / 4000, // Converts inputted Riel back to USD
          waterRevenue: Number(formWater) / 4000, // Converts inputted Riel back to USD
          wifiRevenue: Number(formWifi),
          useCustom: true
        }
      };
      localStorage.setItem('custom_monthly_data', JSON.stringify(updated));
      return updated;
    });
    playAudioFeedback('success');
    alert(`ទិន្នន័យខែ ${parseInt(formMonth)} ត្រូវបានរក្សាទុកដោយជោគជ័យ! / Month ${parseInt(formMonth)} data saved successfully!`);
  };

  // Submit customer monthly input form (Add or Edit)
  const handleSaveCustomerMonthlyInput = (e: React.FormEvent) => {
    e.preventDefault();
    const formattedMonth = inputMonth.padStart(2, '0');
    const currentYear = new Date().getFullYear();
    
    // Set a default date for the payment month if not selected
    let paymentDate = inputPaymentDate;
    if (!paymentDate.includes(`-${formattedMonth}-`)) {
      paymentDate = `${currentYear}-${formattedMonth}-05`;
    }

    const calculatedTotal = Number(inputRoomPrice) + Number(inputWifiPrice) + Number(inputElecPrice) + Number(inputWaterPrice) + Number(inputOtherPrice);

    if (editingRecordId) {
      // Edit mode: update existing record in history
      setHistory(prev => {
        const updated = prev.map(rec => {
          if (rec.id === editingRecordId) {
            return {
              ...rec,
              roomNo: inputRoomNo,
              tenantName: inputTenantName,
              paymentDate: paymentDate,
              roomPrice: Number(inputRoomPrice),
              wifiPrice: Number(inputWifiPrice),
              elecPrice: Number(inputElecPrice),
              waterPrice: Number(inputWaterPrice),
              otherPrice: Number(inputOtherPrice),
              elecUsage: Number(inputElecUsage),
              waterUsage: Number(inputWaterUsage),
              totalUsd: calculatedTotal,
              status: inputStatus
            };
          }
          return rec;
        });
        localStorage.setItem('invoice_history', JSON.stringify(updated));
        return updated;
      });
      alert(`កែសម្រួលទិន្នន័យបានជោគជ័យ! / Updated room ${inputRoomNo} records successfully!`);
      playAudioFeedback('success');
      setEditingRecordId(null);
    } else {
      // Add mode: create new record
      const newRecord: InvoiceHistoryRecord = {
        id: `h-manual-${Date.now()}`,
        roomNo: inputRoomNo,
        tenantName: inputTenantName,
        paymentDate: paymentDate,
        roomPrice: Number(inputRoomPrice),
        wifiPrice: Number(inputWifiPrice),
        elecPrice: Number(inputElecPrice),
        waterPrice: Number(inputWaterPrice),
        otherPrice: Number(inputOtherPrice),
        elecUsage: Number(inputElecUsage),
        waterUsage: Number(inputWaterUsage),
        totalUsd: calculatedTotal,
        status: inputStatus
      };
      setHistory(prev => {
        const updated = [newRecord, ...prev];
        localStorage.setItem('invoice_history', JSON.stringify(updated));
        return updated;
      });
      alert(`បានកត់ត្រាទិន្នន័យថ្មីដោយជោគជ័យ! / Recorded new readings for room ${inputRoomNo} successfully!`);
      playAudioFeedback('success');
    }

    // Reset temporary fields
    setInputElecPrice(0);
    setInputWaterPrice(0);
    setInputOtherPrice(0);
    setInputElecUsage(0);
    setInputWaterUsage(0);
    setEditingRecordId(null);
  };

  // Populate form with record values for editing
  const handleLoadCustomerRecordForEdit = (rec: InvoiceHistoryRecord) => {
    setEditingRecordId(rec.id);
    setInputRoomNo(rec.roomNo);
    setInputTenantName(rec.tenantName);
    setInputRoomPrice(rec.roomPrice);
    setInputWifiPrice(rec.wifiPrice);
    setInputElecPrice(rec.elecPrice);
    setInputWaterPrice(rec.waterPrice);
    setInputOtherPrice(rec.otherPrice);
    setInputElecUsage(rec.elecUsage);
    setInputWaterUsage(rec.waterUsage);
    setInputStatus(rec.status);
    setInputPaymentDate(rec.paymentDate);
    
    const parts = rec.paymentDate.split('-');
    if (parts.length >= 2) {
      setInputMonth(parts[1]);
    }
    // Scroll form into view
    const inputHeader = document.getElementById('input-form-title');
    if (inputHeader) {
      inputHeader.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Delete transaction record from ledger
  const handleDeleteHistory = (id: string) => {
    setHistory(prev => {
      const updated = prev.filter(item => item.id !== id);
      localStorage.setItem('invoice_history', JSON.stringify(updated));
      return updated;
    });
    playAudioFeedback('delete');
  };

  // Toggle guest paid status for current month/cycle
  const handleTogglePaidStatus = (roomNo: string) => {
    setSavedTenants(prev => {
      const updated = prev.map(t => {
        if (t.roomNo === roomNo) {
          return { ...t, isPaid: !t.isPaid };
        }
        return t;
      });
      localStorage.setItem('savedTenants', JSON.stringify(updated));
      return updated;
    });
    playAudioFeedback('success');
  };

  // Sort and filter saved tenants
  const sortedSavedTenants = [...savedTenants].sort((a, b) => {
    const roomA = parseInt(a.roomNo) || 0;
    const roomB = parseInt(b.roomNo) || 0;
    return roomA - roomB;
  });

  const filteredSavedTenantsForSidebar = sortedSavedTenants.filter(tenant => 
    tenant.tenantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tenant.roomNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tenant.tenantPhone.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!isLoggedIn) {
    const handleLoginSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      playAudioFeedback('success');
      setIsLoggedIn(true);
      sessionStorage.setItem('isLoggedIn', 'true');
    };

    return (
      <div className="min-h-screen w-full bg-gradient-to-b from-[#091b16] via-[#102d24] to-[#040907] flex flex-col items-center justify-between p-4 sm:p-6 lg:p-8 font-sans relative overflow-x-hidden select-none">
        
        {/* Soft Warm Bokeh & Light Flares representing lighted property exterior */}
        <div className="absolute top-[10%] left-[20%] w-[350px] h-[350px] bg-amber-500/10 rounded-full blur-[120px] pointer-events-none"></div>
        <div className="absolute bottom-[20%] right-[10%] w-[400px] h-[400px] bg-emerald-500/15 rounded-full blur-[140px] pointer-events-none"></div>
        <div className="absolute top-[40%] right-[20%] w-[250px] h-[250px] bg-teal-500/10 rounded-full blur-[100px] pointer-events-none"></div>
        <div className="absolute bottom-[5%] left-[5%] w-[300px] h-[300px] bg-yellow-500/10 rounded-full blur-[120px] pointer-events-none"></div>

        {/* TOP LEFT LEAVES OVERLAY */}
        <div className="absolute top-0 left-0 w-48 h-48 opacity-25 pointer-events-none text-emerald-300">
          <svg className="w-full h-full" viewBox="0 0 100 100" fill="currentColor">
            <path d="M0,0 Q30,10 40,40 Q10,30 0,0" />
            <path d="M10,0 Q40,15 45,50 Q15,35 10,0" />
            <path d="M0,10 Q20,35 50,40 Q35,20 0,10" />
            <path d="M5,25 Q30,55 60,50 Q45,30 5,25" />
          </svg>
        </div>

        {/* TOP RIGHT LEAVES OVERLAY */}
        <div className="absolute top-0 right-0 w-56 h-56 opacity-25 pointer-events-none text-emerald-400">
          <svg className="w-full h-full transform scale-x-[-1]" viewBox="0 0 100 100" fill="currentColor">
            <path d="M0,0 Q35,15 45,45 Q15,35 0,0" />
            <path d="M15,5 Q45,25 50,60 Q20,45 15,5" />
            <path d="M5,30 Q35,65 65,55 Q45,35 5,30" />
          </svg>
        </div>

        {/* Header Section */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full max-w-lg flex flex-col items-center text-center mt-6 z-10"
        >
          {/* Green Circular Logo with White border - HSN Heng Samnang */}
          <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full border-[3px] border-white/90 bg-gradient-to-b from-[#11442B] to-[#0f3b21] flex flex-col items-center justify-center shadow-2xl relative select-none hover:scale-105 active:scale-95 transition-all duration-300">
            <div className="flex flex-col items-center text-center">
              {/* White house icon */}
              <svg className="w-9 h-9 sm:w-11 sm:h-11 text-white filter drop-shadow-sm mb-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                <polyline points="9 22 9 12 15 12 15 22" />
              </svg>
              {/* Bold Spaced Lettermark */}
              <span className="text-xl sm:text-2xl font-black text-white tracking-[0.25em] pl-1 font-sans leading-none">HSN</span>
              {/* Tiny elegant subtitle */}
              <span className="text-[7px] sm:text-[8px] text-white/90 uppercase tracking-[0.22em] leading-none mt-1.5 font-extrabold font-sans">Heng Samnang</span>
            </div>
          </div>

          {/* Slogan Title */}
          <h1 className="text-2xl sm:text-3xl font-bold text-white mt-5 font-moul leading-normal tracking-wide drop-shadow-md">
            ប្រព័ន្ធគ្រប់គ្រងបន្ទប់ជួល
          </h1>
          <p className="text-xs sm:text-sm font-extrabold text-emerald-400 tracking-[0.15em] uppercase font-sans mt-0.5 drop-shadow-sm">
            Room Rental Management System
          </p>

          {/* Decorative Divider */}
          <div className="flex items-center justify-center gap-3 w-40 my-3 opacity-80">
            <div className="h-[1px] bg-gradient-to-r from-transparent to-white/60 flex-1"></div>
            <span className="text-white text-xs">🏠</span>
            <div className="h-[1px] bg-gradient-to-l from-transparent to-white/60 flex-1"></div>
          </div>

          <p className="text-[10px] sm:text-xs text-stone-300 font-sans tracking-wide px-4 max-w-sm drop-shadow-sm">
            សាងសង់គ្រប់មានប្រសិទ្ធភាព • ងាយស្រួល • ទំនុកចិត្ត
          </p>
        </motion.div>

        {/* Central White Login Card */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="w-full max-w-md bg-white/95 backdrop-blur-md rounded-[2.2rem] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.5)] p-7 sm:p-9 border border-white/50 flex flex-col gap-5 my-8 z-10 hover:shadow-emerald-500/5 transition-all duration-300"
        >
          {/* Card Title */}
          <div className="text-center">
            <h2 className="text-xl sm:text-2xl font-black text-[#11442B] font-moul leading-normal">ចូលប្រព័ន្ធ</h2>
            <p className="text-xs font-bold text-[#198754] uppercase tracking-wider font-sans mt-0.5">Login to System</p>
          </div>

          <form onSubmit={handleLoginSubmit} className="flex flex-col gap-4 font-sans text-stone-700">
            {/* Username Input Field */}
            <div className="space-y-1">
              <div className="relative flex items-center">
                <span className="absolute left-4 text-stone-400">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
                  </svg>
                </span>
                <input 
                  type="text"
                  required
                  placeholder="ឈ្មោះអ្នកប្រើប្រាស់ / Username"
                  className="w-full pl-12 pr-4 py-3.5 bg-stone-50 border border-stone-200 rounded-2xl outline-none focus:border-emerald-500 focus:bg-white text-stone-800 text-sm font-semibold transition-all shadow-inner placeholder:text-stone-400 font-sans"
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                />
              </div>
            </div>

            {/* Password Input Field with toggling visibility eye */}
            <div className="space-y-1">
              <div className="relative flex items-center">
                <span className="absolute left-4 text-stone-400">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
                  </svg>
                </span>
                <input 
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="ពាក្យសម្ងាត់ / Password"
                  className="w-full pl-12 pr-12 py-3.5 bg-stone-50 border border-stone-200 rounded-2xl outline-none focus:border-emerald-500 focus:bg-white text-stone-800 text-sm font-semibold transition-all shadow-inner placeholder:text-stone-400 font-sans"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => { playAudioFeedback('click'); setShowPassword(!showPassword); }}
                  className="absolute right-4 text-stone-400 hover:text-stone-600 transition-colors cursor-pointer"
                >
                  {showPassword ? (
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88" />
                    </svg>
                  ) : (
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  )}
                </button>
              </div>
            </div>

            {/* Checkbox Remember Me & Forgot Password link row */}
            <div className="flex justify-between items-center text-xs font-sans mt-1">
              <label className="flex items-center gap-2 cursor-pointer text-stone-500 font-bold select-none hover:text-stone-700">
                <input 
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => { playAudioFeedback('click'); setRememberMe(e.target.checked); }}
                  className="rounded border-stone-300 text-emerald-600 focus:ring-emerald-500 h-4.5 w-4.5 cursor-pointer accent-emerald-600"
                />
                <span>ចងចាំខ្ញុំ <span className="text-[10px] font-medium text-stone-400">/ Remember me</span></span>
              </label>

              <button
                type="button"
                onClick={() => {
                  playAudioFeedback('click');
                  alert("សូមទាក់ទងមកកាន់ម្ចាស់ផ្ទះដើម្បីកំណត់ពាក្យសម្ងាត់របស់អ្នកឡើងវិញ! / Please contact the Landlord to reset your login password!");
                }}
                className="text-emerald-700 hover:text-emerald-800 hover:underline font-bold transition-all text-right cursor-pointer"
              >
                ភ្លេចពាក្យសម្ងាត់?
                <span className="block text-[9px] font-medium text-stone-400">Forgot password?</span>
              </button>
            </div>

            {/* Main green Submit Button */}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-[#11442B] to-[#198754] hover:from-[#0d331b] hover:to-[#135d33] hover:scale-[1.03] active:scale-[0.97] text-white font-extrabold text-sm py-4 px-6 rounded-2xl shadow-md hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider font-sans mt-2"
            >
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
              </svg>
              <span>ចូលប្រព័ន្ធ <span className="text-xs font-semibold normal-case opacity-90">/ Login</span></span>
            </button>
          </form>

          {/* OR divider */}
          <div className="flex items-center gap-3 w-full opacity-60 my-1">
            <div className="h-[1px] bg-stone-300 flex-grow"></div>
            <span className="text-[10px] font-bold text-stone-400 font-sans">ឬ / OR</span>
            <div className="h-[1px] bg-stone-300 flex-grow"></div>
          </div>

          {/* Social login buttons row */}
          <div className="grid grid-cols-2 gap-3.5 font-sans">
            {/* Google Login button */}
            <button
              type="button"
              onClick={() => {
                playAudioFeedback('success');
                setIsLoggedIn(true);
                sessionStorage.setItem('isLoggedIn', 'true');
              }}
              className="flex items-center justify-center gap-2 border border-stone-200 hover:bg-stone-50 hover:scale-[1.03] active:scale-[0.97] transition-all bg-white py-3 px-3 rounded-xl shadow-sm text-stone-600 font-extrabold text-[10px] cursor-pointer"
            >
              {/* Google colorful logo */}
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path fill="#EA4335" d="M12.24 10.285V14.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.859-3.578-7.859-8s3.529-8 7.859-8c2.46 0 3.927 1.019 4.87 1.91l3.238-3.11c-2.074-1.93-4.756-3.11-8.108-3.11C5.352.09.02 5.422.02 12.09s5.332 12 12.001 12c6.96 0 11.59-4.89 11.59-11.79 0-.79-.08-1.4-.26-2.015H12.24z" />
              </svg>
              <div className="text-left leading-none">
                <span className="block font-bold">ចូលជាមួយ Google</span>
                <span className="text-[8px] text-stone-400 font-medium">Login with Google</span>
              </div>
            </button>

            {/* Facebook Login button */}
            <button
              type="button"
              onClick={() => {
                playAudioFeedback('success');
                setIsLoggedIn(true);
                sessionStorage.setItem('isLoggedIn', 'true');
              }}
              className="flex items-center justify-center gap-2 border border-stone-200 hover:bg-stone-50 hover:scale-[1.03] active:scale-[0.97] transition-all bg-white py-3 px-3 rounded-xl shadow-sm text-stone-600 font-extrabold text-[10px] cursor-pointer"
            >
              {/* Facebook blue logo */}
              <svg className="w-4 h-4 shrink-0 text-[#1877F2]" fill="currentColor" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              <div className="text-left leading-none">
                <span className="block font-bold">ចូលជាមួយ Facebook</span>
                <span className="text-[8px] text-stone-400 font-medium">Login with Facebook</span>
              </div>
            </button>
          </div>
        </motion.div>

        {/* Footer Section with building silhouettes layout */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.9 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="w-full max-w-lg flex flex-col items-center text-center pb-4 z-10"
        >
          {/* Detailed Town Silhouette Graphic */}
          <div className="w-full flex items-end justify-center h-12 opacity-35 text-emerald-400 mb-2 pointer-events-none select-none">
            <svg className="w-64 h-full" viewBox="0 0 200 40" fill="currentColor">
              <path d="M10,40 V30 H15 V25 H25 V35 H30 V40 Z M35,40 V15 H45 V20 H50 V30 H55 V40 Z M60,40 V35 H65 V32 H70 V40 Z M75,40 V5 H85 V12 H90 V25 H95 V40 Z M100,40 V20 H105 V40 Z M110,40 V15 H120 V25 H125 V40 Z M130,40 V30 H140 V40 Z M145,40 V8 H155 V15 H160 V40 Z M165,40 V25 H175 V40 Z M180,40 V35 H190 V40 Z" />
              {/* Floating cute trees */}
              <circle cx="28" cy="35" r="4" />
              <circle cx="58" cy="36" r="3" />
              <circle cx="107" cy="36" r="3" />
              <circle cx="162" cy="35" r="4" />
              <circle cx="178" cy="36" r="3" />
            </svg>
          </div>

          <p className="text-[10px] sm:text-xs font-semibold text-emerald-100 tracking-wide font-sans">
            គ្រប់គ្រងការជួលបន្ទប់ • សន្សំពេលវេលា • បង្កើនប្រាក់ចំណេញបន្ថែម
          </p>
          <p className="text-[8px] sm:text-[9px] text-stone-400 tracking-wider font-sans mt-0.5 uppercase">
            Manage Rooms • Save Time • Increase Profit
          </p>
        </motion.div>

        {/* BOTTOM LEFT LEAVES OVERLAY */}
        <div className="absolute bottom-0 left-0 w-52 h-52 opacity-20 pointer-events-none text-emerald-400 transform scale-y-[-1]">
          <svg className="w-full h-full" viewBox="0 0 100 100" fill="currentColor">
            <path d="M0,0 Q35,15 45,45 Q15,35 0,0" />
            <path d="M15,5 Q45,25 50,60 Q20,45 15,5" />
            <path d="M5,30 Q35,65 65,55 Q45,35 5,30" />
          </svg>
        </div>

        {/* BOTTOM RIGHT LEAVES OVERLAY */}
        <div className="absolute bottom-0 right-0 w-48 h-48 opacity-20 pointer-events-none text-emerald-300 transform scale-[-1]">
          <svg className="w-full h-full" viewBox="0 0 100 100" fill="currentColor">
            <path d="M0,0 Q30,10 40,40 Q10,30 0,0" />
            <path d="M10,0 Q40,15 45,50 Q15,35 10,0" />
            <path d="M0,10 Q20,35 50,40 Q35,20 0,10" />
            <path d="M5,25 Q30,55 60,50 Q45,30 5,25" />
          </svg>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#04170E] via-[#092B1B] to-[#020F09] py-8 px-4 sm:px-6 lg:px-8 font-sans relative overflow-hidden text-stone-100">
      
      {/* Subtle Blurry House Backdrop Motif in Dark Green (Request #8) - Hidden on print */}
      <div className="absolute inset-0 z-0 pointer-events-none select-none overflow-hidden print:hidden">
        {/* Large central blurred house outline */}
        <svg 
          className="absolute -right-24 top-20 w-[950px] h-[950px] text-emerald-400/4 blur-[6px] transform rotate-[-6deg]"
          viewBox="0 0 100 100"
          fill="none"
          stroke="currentColor"
          strokeWidth="0.3"
        >
          {/* Detailed architectural modern house SVG skeleton */}
          <path d="M10 90 L10 50 L50 20 L90 50 L90 90 Z" />
          <path d="M50 20 L50 90" />
          <path d="M10 50 L90 50" />
          <rect x="25" y="60" width="12" height="20" />
          <rect x="63" y="60" width="12" height="20" />
          <rect x="25" y="32" width="12" height="12" />
          <rect x="63" y="32" width="12" height="12" />
          <circle cx="50" cy="12" r="4" />
          <path d="M40 90 L60 90" strokeWidth="1" />
        </svg>
        
        {/* Second smaller blurred house outline on the left bottom */}
        <svg 
          className="absolute -left-48 bottom-10 w-[750px] h-[750px] text-emerald-500/3 blur-[10px] transform rotate-[15deg]"
          viewBox="0 0 100 100"
          fill="none"
          stroke="currentColor"
          strokeWidth="0.4"
        >
          <path d="M15 85 L15 45 L50 15 L85 45 L85 85 Z" strokeDasharray="2,2" />
          <rect x="40" y="55" width="20" height="30" />
          <rect x="25" y="55" width="10" height="15" />
          <rect x="65" y="55" width="10" height="15" />
          <line x1="5" y1="85" x2="95" y2="85" />
        </svg>
      </div>
      
      {/* Absolute Transparent Background Click-Away Catcher for Select Dropdowns */}
      {(showNameDropdown || showRoomDropdown || showPhoneDropdown) && (
        <div 
          className="fixed inset-0 z-40 bg-transparent print:hidden"
          onClick={() => {
            setShowNameDropdown(false);
            setShowRoomDropdown(false);
            setShowPhoneDropdown(false);
          }}
        />
      )}

      {/* Top Header & Controls - Hidden on print */}
      <div className="max-w-7xl mx-auto mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 print:hidden border-b border-emerald-800/40 pb-4">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <Home className="w-6 h-6 text-emerald-400" />
          Room Rent Manager
        </h1>
        <div className="flex flex-wrap gap-3">
          <button 
            onClick={handleReset}
            className="flex items-center gap-2 bg-white border border-stone-200 px-4 py-2 rounded-lg shadow-sm hover:bg-stone-50 hover:scale-[1.04] active:scale-[0.96] cursor-pointer transition-all duration-200 text-stone-700 font-medium text-sm hover:shadow-sm"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
            សម្អាត (Clear Fields)
          </button>
          <button 
            onClick={handleTopDownload}
            disabled={isDownloading}
            className="flex items-center gap-2 bg-white border border-stone-200 px-4 py-2 rounded-lg shadow-sm hover:bg-stone-50 hover:scale-[1.04] active:scale-[0.96] cursor-pointer transition-all duration-200 text-stone-700 font-medium text-sm disabled:opacity-50 hover:shadow-sm"
          >
            {isDownloading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Download className="w-4 h-4 text-sky-600" />
            )}
            ទាញយក (Download)
          </button>
          <button 
            onClick={handlePrint}
            className="flex items-center gap-2 bg-emerald-600 px-4 py-2 rounded-lg shadow-sm hover:bg-emerald-700 hover:scale-[1.04] active:scale-[0.96] cursor-pointer transition-all duration-200 text-white font-medium text-sm hover:shadow-md"
          >
            <Printer className="w-4 h-4" />
            បោះពុម្ព (Print)
          </button>
          <button 
            onClick={handleMarkAsPaid}
            className="flex items-center gap-2 bg-indigo-600 px-4 py-2 rounded-lg shadow-sm hover:bg-indigo-700 hover:scale-[1.04] active:scale-[0.96] cursor-pointer transition-all duration-200 text-white font-medium text-sm hover:shadow-md"
            title="Mark current invoice as Paid and save to ledger"
          >
            <CreditCard className="w-4 h-4" />
            បង់ប្រាក់ (Mark Paid)
          </button>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 bg-white border border-stone-200 px-4 py-2 rounded-lg shadow-sm hover:bg-stone-50 hover:text-red-600 hover:border-red-200 hover:scale-[1.04] active:scale-[0.96] cursor-pointer transition-all duration-200 text-stone-700 font-medium text-sm hover:shadow-sm"
          >
            <LogOut className="w-4 h-4 text-red-500" />
            ចាកចេញ (Logout)
          </button>
        </div>
      </div>

      {/* Dynamic Tab Switcher - Buttons for related sections - Hidden on print */}
      <div className="max-w-7xl mx-auto mb-8 grid grid-cols-2 lg:grid-cols-5 gap-4 print:hidden">
        <button
          type="button"
          onClick={() => { playAudioFeedback('click'); setActiveTab('invoice'); }}
          className={`p-4 rounded-xl border text-left transition-all flex items-start gap-3 shadow-sm hover:scale-[1.03] active:scale-[0.97] cursor-pointer ${
            activeTab === 'invoice'
              ? 'bg-emerald-600 border-emerald-600 text-white shadow-emerald-600/10 hover:shadow-emerald-600/20'
              : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50 hover:shadow-md'
          }`}
        >
          <div className={`p-2 rounded-lg ${activeTab === 'invoice' ? 'bg-emerald-500/30 text-white' : 'bg-emerald-50 text-emerald-600'}`}>
            <CreditCard className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-xs uppercase tracking-wider">១. វិក្កយបត្រ (Invoice)</h3>
            <p className={`text-[10px] mt-0.5 ${activeTab === 'invoice' ? 'text-emerald-100' : 'text-stone-500'}`}>
              Rent Invoices & Meter Cycles
            </p>
          </div>
        </button>

        <button
          type="button"
          onClick={() => { playAudioFeedback('click'); setActiveTab('tenants'); }}
          className={`p-4 rounded-xl border text-left transition-all flex items-start gap-3 shadow-sm hover:scale-[1.03] active:scale-[0.97] cursor-pointer ${
            activeTab === 'tenants'
              ? 'bg-blue-600 border-blue-600 text-white shadow-blue-600/10 hover:shadow-blue-600/20'
              : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50 hover:shadow-md'
          }`}
        >
          <div className={`p-2 rounded-lg ${activeTab === 'tenants' ? 'bg-blue-500/30 text-white' : 'bg-blue-50 text-blue-600'}`}>
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-xs uppercase tracking-wider">២. ភ្ញៀវស្នាក់នៅ (Tenants)</h3>
            <p className={`text-[10px] mt-0.5 ${activeTab === 'tenants' ? 'text-blue-100' : 'text-stone-500'}`}>
              Manage Rooms & Tenant Directory
            </p>
          </div>
        </button>

        <button
          type="button"
          onClick={() => { playAudioFeedback('click'); setActiveTab('manualForm'); }}
          className={`p-4 rounded-xl border text-left transition-all flex items-start gap-3 shadow-sm hover:scale-[1.03] active:scale-[0.97] cursor-pointer ${
            activeTab === 'manualForm'
              ? 'bg-amber-600 border-amber-600 text-white shadow-amber-600/10 hover:shadow-amber-600/20'
              : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50 hover:shadow-md'
          }`}
        >
          <div className={`p-2 rounded-lg ${activeTab === 'manualForm' ? 'bg-amber-500/30 text-white' : 'bg-amber-50 text-amber-600'}`}>
            <Edit className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-xs uppercase tracking-wider">៣. បញ្ចូលទិន្នន័យ (Inputs)</h3>
            <p className={`text-[10px] mt-0.5 ${activeTab === 'manualForm' ? 'text-amber-100' : 'text-stone-500'}`}>
              Manual Monthly Utility Inputs
            </p>
          </div>
        </button>

        <button
          type="button"
          onClick={() => { playAudioFeedback('click'); setActiveTab('reports'); }}
          className={`p-4 rounded-xl border text-left transition-all flex items-start gap-3 shadow-sm hover:scale-[1.03] active:scale-[0.97] cursor-pointer ${
            activeTab === 'reports'
              ? 'bg-violet-600 border-violet-600 text-white shadow-violet-600/10 hover:shadow-violet-600/20'
              : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50 hover:shadow-md'
          }`}
        >
          <div className={`p-2 rounded-lg ${activeTab === 'reports' ? 'bg-violet-500/30 text-white' : 'bg-violet-50 text-violet-600'}`}>
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-xs uppercase tracking-wider">៤. របាយការណ៍ (Reports)</h3>
            <p className={`text-[10px] mt-0.5 ${activeTab === 'reports' ? 'text-violet-100' : 'text-stone-500'}`}>
              Revenue Analytics & Staff Slips
            </p>
          </div>
        </button>

        <button
          type="button"
          onClick={() => { playAudioFeedback('click'); setActiveTab('summaryChecker'); }}
          className={`p-4 rounded-xl border text-left transition-all flex items-start gap-3 shadow-sm hover:scale-[1.03] active:scale-[0.97] cursor-pointer ${
            activeTab === 'summaryChecker'
              ? 'bg-sky-600 border-sky-600 text-white shadow-sky-600/10 hover:shadow-sky-600/20'
              : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50 hover:shadow-md'
          }`}
        >
          <div className={`p-2 rounded-lg ${activeTab === 'summaryChecker' ? 'bg-sky-500/30 text-white' : 'bg-sky-50 text-sky-600'}`}>
            <Search className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-xs uppercase tracking-wider">៥. សរុបរបស់ភ្ញៀវ (Checker)</h3>
            <p className={`text-[10px] mt-0.5 ${activeTab === 'summaryChecker' ? 'text-sky-100' : 'text-stone-500'}`}>
              Total Summary Checker & 4K Invoice
            </p>
          </div>
        </button>
      </div>

      {/* Main Grid Layout */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
        
        {/* Left Column: Invoice Area / Admin Dashboard */}
        <div className="lg:col-span-8 xl:col-span-9 w-full">
          {/* 🖥️ កញ្ចក់អេក្រង់បង្ហាញព័ត៌មាន (AUXILIARY CORE DISPLAY SCREEN) */}
          <div className="border-[8px] border-stone-800 rounded-3xl bg-stone-900 p-2 shadow-2xl relative overflow-hidden ring-1 ring-stone-950">
            {/* Screen top status bezel */}
            <div className="flex items-center justify-between px-4 py-2 bg-stone-950 text-stone-400 font-mono select-none rounded-t-xl mb-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="tracking-wider uppercase font-sans text-[10px] text-emerald-400 font-black">កញ្ចក់អេក្រង់បង្ហាញព័ត៌មាន (AUX CORE DISPLAY SCREEN)</span>
              </div>
              <div className="font-sans text-[10px] text-stone-500 font-bold">
                បង្ហាញមាតិកាចម្បង (Active Feed): {activeTab === 'invoice' ? '១. វិក្កយបត្រ (Invoice)' : activeTab === 'tenants' ? '២. ភ្ញៀវស្នាក់នៅ (Tenants)' : activeTab === 'manualForm' ? '៣. បញ្ចូលទិន្នន័យ (Inputs)' : activeTab === 'reports' ? '៤. របាយការណ៍ (Reports)' : '៥. ពិនិត្យផលបូកសរុបរបស់ភ្ញៀវ (Total Summary Checker)'}
              </div>
            </div>
            
            {/* Screen Inner Display Frame */}
            <div className="bg-stone-100 rounded-2xl overflow-hidden p-0.5">
              {activeTab === 'invoice' && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            ref={invoiceRef}
            className="w-full bg-white shadow-2xl rounded-sm overflow-hidden print:shadow-none print:m-0"
            id="invoice-content"
          >
            <div className="p-10 border-t-[12px] border-emerald-600 text-blue-900">
              
              {/* Landlord Info Header */}
              <div className="flex justify-between items-start mb-10">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-blue-900 text-sm font-medium">ម្ចាស់ផ្ទះ៖</span>
                    <input 
                      className="font-moul text-xl text-blue-900 border-b border-transparent hover:border-stone-200 focus:border-emerald-500 outline-none transition-all"
                      value={data.landlordName}
                      onChange={(e) => setData({...data, landlordName: e.target.value})}
                    />
                  </div>
                  <div className="flex items-start gap-2 text-blue-900 text-sm">
                    <Home className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <textarea 
                      className="w-full bg-transparent border-b border-transparent hover:border-stone-200 focus:border-emerald-500 outline-none resize-none h-12"
                      value={data.landlordAddress}
                      onChange={(e) => setData({...data, landlordAddress: e.target.value})}
                    />
                  </div>
                  <div className="flex items-center gap-2 text-blue-900 text-sm">
                    <Phone className="w-4 h-4 flex-shrink-0" />
                    <input 
                      className="bg-transparent border-b border-transparent hover:border-stone-200 focus:border-emerald-500 outline-none"
                      value={data.landlordPhone}
                      onChange={(e) => setData({...data, landlordPhone: e.target.value})}
                    />
                  </div>
                </div>

                <div className="text-center">
                  <h2 className="text-blue-900 font-moul text-xl tracking-tight mb-1">វិក្កយបត្រថ្លៃជួលបន្ទប់</h2>
                  <div className="h-1 bg-blue-900 w-full mb-1"></div>
                  <p className="text-blue-900 font-bold text-lg">INVOICE FOR RENT ROOM</p>
                </div>

                <div className="flex flex-col items-center">
                  <input 
                    type="file" 
                    ref={logoInputRef} 
                    className="hidden" 
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, 'logo')}
                  />
                  <div 
                    onClick={() => logoInputRef.current?.click()}
                    className={`w-24 h-24 flex items-center justify-center cursor-pointer transition-all overflow-hidden group relative ${
                      data.logoUrl 
                        ? 'bg-transparent border-0' 
                        : 'bg-stone-100 border-2 border-dashed border-stone-300 rounded-2xl shadow-sm mb-2'
                    }`}
                  >
                    {data.logoUrl ? (
                      <img src={data.logoUrl} alt="Logo" className="w-full h-full object-cover" />
                    ) : (
                      <div className="flex flex-col items-center gap-1">
                        <Plus className="w-6 h-6" />
                        <span>Logo</span>
                      </div>
                    )}
                    <div className={`absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity ${isDownloading ? 'hidden' : 'print:hidden'}`}>
                      Change
                    </div>
                  </div>
                  <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest"></p>
                </div>
              </div>

              {/* Tenant Info Grid with quick selector buttons for Name, Room, Phone */}
              <div className="grid grid-cols-2 gap-x-12 gap-y-4 mb-10 text-sm relative z-50">
                <div className="space-y-3">
                  
                  {/* Select Tenant by NAME */}
                  <div className="flex items-center gap-2 relative">
                    <span className="whitespace-nowrap text-blue-900 font-medium">ឈ្មោះអ្នកជួលបន្ទប់ (Name):</span>
                    <div className="flex-1 relative flex items-center">
                      <input 
                        className="w-full font-moul text-blue-900 outline-none pb-0.5 border-b border-stone-200/50 focus:border-emerald-500 focus:border-b-2 transition-all"
                        value={data.tenantName}
                        onChange={(e) => setData({...data, tenantName: e.target.value})}
                        placeholder="វាយបញ្ចូល ឬជ្រើសរើសឈ្មោះ... / Enter or select name..."
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setShowNameDropdown(!showNameDropdown);
                          setShowRoomDropdown(false);
                          setShowPhoneDropdown(false);
                        }}
                        className={`ml-1 p-1 rounded transition-all ${isDownloading ? 'hidden' : 'print:hidden'} ${showNameDropdown ? 'text-emerald-600 bg-emerald-50' : 'text-stone-400 hover:text-emerald-600'}`}
                        title="ជ្រើសរើសតាមឈ្មោះ / Select by Name"
                      >
                        <User className="w-4 h-4" />
                      </button>
                      
                      {showNameDropdown && (
                        <div className={`absolute left-0 right-0 top-full mt-1 bg-white border border-stone-200 rounded-md shadow-xl z-[60] max-h-48 overflow-y-auto divide-y divide-stone-100 ${isDownloading ? 'hidden' : 'print:hidden'}`}>
                          {sortedSavedTenants.map((tenant) => (
                            <button
                              key={tenant.tenantName}
                              type="button"
                              onClick={() => {
                                handleSelectTenant(tenant);
                                setShowNameDropdown(false);
                              }}
                              className="w-full text-left px-3 py-2.5 hover:bg-stone-50 transition-colors text-xs flex justify-between items-center"
                            >
                              <span className="font-moul text-blue-900 text-[11px]">{tenant.tenantName}</span>
                              <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-100 px-1.5 py-0.5 rounded font-bold font-sans">
                                P.{tenant.roomNo}
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Select Tenant by ROOM */}
                  <div className="flex items-center gap-2 relative">
                    <span className="whitespace-nowrap text-blue-900 font-medium">លេខបន្ទប់ (Room No):</span>
                    <div className="flex-1 relative flex items-center">
                      <input 
                        className="w-full font-bold text-blue-900 outline-none pb-0.5 border-b border-stone-200/50 focus:border-emerald-500 focus:border-b-2 transition-all"
                        value={data.roomNo}
                        onChange={(e) => setData({...data, roomNo: e.target.value})}
                        placeholder="ជ្រើសរើសលេខបន្ទប់... / Select room..."
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setShowRoomDropdown(!showRoomDropdown);
                          setShowNameDropdown(false);
                          setShowPhoneDropdown(false);
                        }}
                        className={`ml-1 p-1 rounded transition-all ${isDownloading ? 'hidden' : 'print:hidden'} ${showRoomDropdown ? 'text-emerald-600 bg-emerald-50' : 'text-stone-400 hover:text-emerald-600'}`}
                        title="ជ្រើសរើសតាមលេខបន្ទប់ / Select by Room"
                      >
                        <Home className="w-4 h-4" />
                      </button>
                      
                      {showRoomDropdown && (
                        <div className={`absolute left-0 right-0 top-full mt-1 bg-white border border-stone-200 rounded-md shadow-xl z-[60] max-h-48 overflow-y-auto divide-y divide-stone-100 font-sans ${isDownloading ? 'hidden' : 'print:hidden'}`}>
                          {sortedSavedTenants.map((tenant) => (
                            <button
                              key={tenant.roomNo}
                              type="button"
                              onClick={() => {
                                handleSelectTenant(tenant);
                                setShowRoomDropdown(false);
                              }}
                              className="w-full text-left px-3 py-2.5 hover:bg-stone-50 transition-colors text-xs flex justify-between items-center"
                            >
                              <span className="font-bold text-stone-800">បន្ទប់ (Room) {tenant.roomNo}</span>
                              <span className="text-[10px] font-moul text-blue-900">{tenant.tenantName}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Select Tenant by PHONE */}
                  <div className="flex items-center gap-2 relative">
                    <span className="whitespace-nowrap text-blue-900 font-medium">លេខទូរស័ព្ទ (Phone):</span>
                    <div className="flex-1 relative flex items-center">
                      <input 
                        className="w-full font-bold text-blue-900 outline-none pb-0.5 border-b border-stone-200/50 focus:border-emerald-500 focus:border-b-2 transition-all"
                        value={data.tenantPhone}
                        onChange={(e) => setData({...data, tenantPhone: e.target.value})}
                        placeholder="ជ្រើសរើសលេខទូរស័ព្ទ... / Select phone..."
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setShowPhoneDropdown(!showPhoneDropdown);
                          setShowNameDropdown(false);
                          setShowRoomDropdown(false);
                        }}
                        className={`ml-1 p-1 rounded transition-all ${isDownloading ? 'hidden' : 'print:hidden'} ${showPhoneDropdown ? 'text-emerald-600 bg-emerald-50' : 'text-stone-400 hover:text-emerald-600'}`}
                        title="ជ្រើសរើសតាមលេខទូរស័ព្ទ / Select by Phone"
                      >
                        <Phone className="w-4 h-4" />
                      </button>
                      
                      {showPhoneDropdown && (
                        <div className={`absolute left-0 right-0 top-full mt-1 bg-white border border-stone-200 rounded-md shadow-xl z-[60] max-h-48 overflow-y-auto divide-y divide-stone-100 font-sans ${isDownloading ? 'hidden' : 'print:hidden'}`}>
                          {sortedSavedTenants.map((tenant) => (
                            <button
                              key={tenant.tenantPhone}
                              type="button"
                              onClick={() => {
                                handleSelectTenant(tenant);
                                setShowPhoneDropdown(false);
                              }}
                              className="w-full text-left px-3 py-2.5 hover:bg-stone-50 transition-colors text-xs flex justify-between items-center"
                            >
                              <span className="font-bold text-stone-800">{tenant.tenantPhone || 'មិនទាន់បញ្ចូលទេ / Not specified'}</span>
                              <span className="text-[10px] text-stone-500 font-moul">{tenant.tenantName} (P.{tenant.roomNo})</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                </div>

                <div className="space-y-3">
                  <div className="flex items-end gap-2">
                    <span className="whitespace-nowrap text-blue-900">អត្តសញ្ញាណប័ណ្ណ (ID No):</span>
                    <input 
                      className="flex-1 font-bold text-blue-900 outline-none pb-0.5 border-b border-stone-200/50 focus:border-emerald-500 focus:border-b-2 transition-all"
                      value={data.tenantIdNo}
                      onChange={(e) => setData({...data, tenantIdNo: e.target.value})}
                      placeholder="..."
                    />
                  </div>
                  <div className="flex items-end gap-2">
                    <span className="whitespace-nowrap text-blue-900">ថ្ងៃចូលស្នាក់នៅ (Check-in):</span>
                    <input 
                      type="date"
                      className="flex-1 font-bold text-blue-900 outline-none pb-0.5 border-b border-stone-200/50 focus:border-emerald-500 focus:border-b-2 transition-all"
                      value={data.checkInDate}
                      onChange={(e) => setData({...data, checkInDate: e.target.value})}
                    />
                  </div>
                  
                  {/* Bilingual Khmer-English Security Deposit Field (Display only, does not accumulate) */}
                  <div className="flex items-end gap-2">
                    <span className="whitespace-nowrap text-blue-900">ប្រាក់កក់ (Security Deposit):</span>
                    <span className="flex-1 font-bold text-blue-900 pb-0.5 border-b border-stone-200/50 font-mono text-right pr-2">
                      {(() => {
                        const activeTenantRecord = savedTenants.find(t => t.roomNo === data.roomNo);
                        return activeTenantRecord && activeTenantRecord.deposit !== undefined 
                          ? `$${activeTenantRecord.deposit.toFixed(2)}` 
                          : '$0.00';
                      })()}
                    </span>
                    <span className="text-[9px] text-stone-400 italic shrink-0 print:hidden font-sans"></span>
                  </div>
                </div>
              </div>

              {/* Table and QR Section */}
              <div className="flex gap-8 mb-10 relative z-30">
                {/* Invoice Items Table */}
                <div className="flex-grow">
                  <table className="w-full border-collapse border border-stone-800 text-sm">
                    <thead>
                      <tr className="bg-stone-50">
                        <th className="border border-stone-800 p-2 text-center font-bold text-blue-900 w-1/3">
                          បរិយាយ<br/><span className="text-[10px] font-normal">Description</span>
                        </th>
                        <th className="border border-stone-800 p-2 text-center font-bold text-blue-900">
                          លេខចាស់<br/><span className="text-[10px] font-normal">Old Month Nº</span>
                        </th>
                        <th className="border border-stone-800 p-2 text-center font-bold text-blue-900">
                          លេខថ្មី<br/><span className="text-[10px] font-normal">New Month Nº</span>
                        </th>
                        <th className="border border-stone-800 p-2 text-center font-bold text-blue-900">
                          ចំនួនប្រើ<br/><span className="text-[10px] font-normal">Quantity</span>
                        </th>
                        <th className="border border-stone-800 p-2 text-center font-bold text-blue-900">
                          តម្លៃមួយ<br/><span className="text-[10px] font-normal">Unit Price</span>
                        </th>
                        <th className="border border-stone-800 p-2 text-center font-bold text-blue-900">
                          ទឹកប្រាក់សរុប<br/><span className="text-[10px] font-normal">Amount</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.items.map((item) => {
                        const isUtility = item.description.includes('អគ្គិសនី') || 
                                          item.description.includes('Electricity') || 
                                          item.description.includes('ទឹក') || 
                                          item.description.includes('Water');
                        return (
                          <tr key={item.id} className="h-12 group">
                            <td className="border border-stone-800 px-3 py-1 font-bold text-blue-900 relative">
                              <input 
                                className="w-full bg-transparent outline-none"
                                value={item.description}
                                onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                              />
                              <button 
                                onClick={() => removeItem(item.id)}
                                className={`absolute -left-8 top-1/2 -translate-y-1/2 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity ${isDownloading ? 'hidden' : 'print:hidden'}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                            
                            {/* Old Month Nº Cell */}
                            <td className="border border-stone-800 p-1 text-center">
                              {isUtility ? (
                                <input 
                                  className="w-full text-center bg-transparent outline-none font-bold"
                                  placeholder="លេខចាស់ / Old No."
                                  value={item.oldMonthNo}
                                  onChange={(e) => updateItem(item.id, 'oldMonthNo', e.target.value)}
                                />
                              ) : (
                                <span className="text-stone-400 font-sans">—</span>
                              )}
                            </td>
                            
                            {/* New Month Nº Cell */}
                            <td className="border border-stone-800 p-1 text-center">
                              {isUtility ? (
                                <input 
                                  className="w-full text-center bg-transparent outline-none font-bold text-emerald-700 bg-emerald-50/50 focus:bg-emerald-100/50 focus:border-emerald-500"
                                  placeholder="លេខថ្មី / New No."
                                  value={item.newMonthNo}
                                  onChange={(e) => updateItem(item.id, 'newMonthNo', e.target.value)}
                                />
                              ) : (
                                <span className="text-stone-400 font-sans">—</span>
                              )}
                            </td>
                            
                            <td className="border border-stone-800 p-1 text-center font-bold">
                              <div className="flex flex-col items-center">
                                <input 
                                  className="w-12 text-center bg-transparent outline-none"
                                  type="number"
                                  value={item.quantity}
                                  onChange={(e) => updateItem(item.id, 'quantity', parseFloat(e.target.value) || 0)}
                                />
                                {item.unit && <span className="text-[10px] text-blue-700">{item.unit}</span>}
                              </div>
                            </td>
                            <td className="border border-stone-800 p-1 text-center font-bold">
                              <div className="flex flex-col items-center justify-center gap-0.5">
                                <div className="flex items-center justify-center gap-1">
                                  <select 
                                    className={`bg-transparent outline-none text-[10px] ${isDownloading ? 'hidden' : 'print:hidden'}`}
                                    value={item.currency}
                                    onChange={(e) => updateItem(item.id, 'currency', e.target.value)}
                                  >
                                    <option value="USD">$</option>
                                    <option value="KHR">៛</option>
                                  </select>
                                  <span className="hidden print:inline">{item.currency === 'USD' ? '$' : '៛'}</span>
                                  <input 
                                    className="w-16 text-center bg-transparent outline-none"
                                    type="number"
                                    step={item.currency === 'KHR' ? "100" : "0.01"}
                                    value={item.unitPrice}
                                    onChange={(e) => updateItem(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                                  />
                                </div>
                                {item.currency === 'KHR' && (
                                  <span className="text-[9px] text-stone-500 font-normal leading-none font-sans">
                                    (${(item.unitPrice / 4000).toFixed(3)})
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="border border-stone-800 p-1 text-center font-bold text-blue-900">
                              {item.currency === 'USD' ? (
                                <span>${(item.quantity * item.unitPrice).toFixed(2)}</span>
                              ) : (
                                <div className="flex flex-col items-center justify-center leading-none">
                                  <span>៛{(item.quantity * item.unitPrice).toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                                  <span className="text-[9px] text-stone-500 font-normal mt-0.5 font-sans">
                                    (${( (item.quantity * item.unitPrice) / 4000 ).toFixed(2)})
                                  </span>
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                      
                      {/* Segmented template selector buttons under the table */}
                      <tr className={`bg-stone-50/50 ${isDownloading ? 'hidden' : 'print:hidden'}`}>
                        <td colSpan={6} className="border border-stone-800 p-2.5 text-center">
                          <div className="flex justify-center items-center gap-3">
                            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider font-sans">បន្ថែមជួរថ្មី / Add new row:</span>
                            <button 
                              type="button"
                              onClick={() => addItem('normal')}
                              className="flex items-center gap-1.5 bg-white border border-stone-200 px-3 py-1.5 rounded shadow-sm hover:bg-stone-50 transition-colors text-stone-700 font-bold text-xs font-sans"
                            >
                              <Plus className="w-3.5 h-3.5 text-stone-500" />
                              សេវាកម្មធម្មតា (Normal Service)
                            </button>
                            <button 
                              type="button"
                              onClick={() => addItem('electricity')}
                              className="flex items-center gap-1.5 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded shadow-sm hover:bg-amber-100 transition-colors text-amber-800 font-bold text-xs font-sans"
                            >
                              <Zap className="w-3.5 h-3.5 text-amber-500" />
                              អគ្គិសនី (Electricity KWH)
                            </button>
                            <button 
                              type="button"
                              onClick={() => addItem('water')}
                              className="flex items-center gap-1.5 bg-sky-50 border border-sky-200 px-3 py-1.5 rounded shadow-sm hover:bg-sky-100 transition-colors text-sky-800 font-bold text-xs font-sans"
                            >
                              <Droplets className="w-3.5 h-3.5 text-sky-500" />
                              ទឹក (Water M³)
                            </button>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  
                  {/* Convenient Tip Paragraph - Hidden during downloads and prints */}
                  <p className={`text-[10px] text-stone-400 mt-2 italic ${isDownloading ? 'hidden' : 'print:hidden'}`}>
                    💡 <b>ព័ត៌មានជំនួយ៖</b> អ្នកអាចវាយបញ្ចូល ឬកែសម្រួលទាំង <b>លេខវ៉ាត់ចាស់</b> និង <b>លេខវ៉ាត់ថ្មី</b> ដោយផ្ទាល់នៅក្នុងតារាងខាងលើ។ បន្ទាប់ពីវិក្កយបត្រត្រូវបានបោះពុម្ព ឬទាញយក ប្រព័ន្ធនឹងធ្វើបច្ចុប្បន្នភាពលេខថ្មីទាំងនេះជាលេខចាស់សម្រាប់ខែក្រោយដោយស្វ័យប្រវត្តិ! / <b>Tip:</b> You can freely edit both <b>Old</b> and <b>New Readings</b> directly in the table. Once the invoice is printed or downloaded, the system will automatically cycle the readings for next month!
                  </p>
                </div>

                {/* ABA QR Pay Code Card */}
                <div className="w-64 flex-shrink-0">
                  <input 
                    type="file" 
                    ref={qrInputRef} 
                    className="hidden" 
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, 'qr')}
                  />
                  <div 
                    onClick={() => qrInputRef.current?.click()}
                    className="border border-stone-200 rounded-2xl overflow-hidden bg-white flex flex-col items-center shadow-md cursor-pointer hover:shadow-lg transition-all group relative"
                  >
                    <div className="w-full h-2 bg-[#005a71]"></div>
                    
                    <div className="p-4 flex flex-col items-center w-full">
                      <div className="flex items-center gap-1 mb-2">
                        <span className="text-[#005a71] font-black text-2xl tracking-tighter">ABA</span>
                        <span className="text-red-500 font-bold text-2xl">'</span>
                        <span className="text-[#48b6d1] font-bold text-2xl tracking-tighter">PAY</span>
                      </div>
                      <p className="text-stone-800 font-medium text-[10px] mb-4">Scan. Pay. Done.</p>
                      
                      <div className="relative w-40 h-40 bg-white p-1 border border-stone-100 rounded-xl mb-3 overflow-hidden">
                        {data.qrUrl ? (
                          <img src={data.qrUrl} alt="QR Code" className="w-full h-full object-contain" />
                        ) : (
                          <div className="w-full h-full bg-white flex items-center justify-center relative">
                            <div className="w-full h-full border-2 border-stone-200 rounded-lg p-2 opacity-80">
                               <div className="w-full h-full bg-[url('https://www.qr-code-generator.com/wp-content/themes/qr/new_structure/markets/core_market/generator/dist/generator/assets/images/market/generator/qr-code-example.png')] bg-cover bg-center opacity-20"></div>
                            </div>
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="w-8 h-8 rounded-full bg-black border-2 border-white flex items-center justify-center shadow-lg">
                                <span className="text-white font-bold text-xs">$</span>
                              </div>
                            </div>
                          </div>
                        )}
                        <div className={`absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity ${isDownloading ? 'hidden' : 'print:hidden'}`}>
                          Upload QR
                        </div>
                      </div>

                      <div className="text-center mb-6">
                        <p className="text-stone-700 font-bold text-xs tracking-wide">NGUON SOVANNA</p>
                      </div>

                      <div className="w-full flex justify-between items-end mt-auto">
                        <div className="flex flex-col items-start">
                          <span className="text-[8px] text-stone-400 font-bold">Member of</span>
                          <div className="flex items-center gap-0.5">
                            <span className="text-red-600 font-black text-xs italic">KH</span>
                            <span className="text-blue-900 font-black text-xs italic">QR</span>
                          </div>
                        </div>
                        <div className="relative w-12 h-12">
                           <div className="absolute bottom-[-16px] right-[-16px] w-16 h-16 bg-red-600 rounded-tl-full"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Rules and Total */}
              <div className="grid grid-cols-3 gap-8 items-start relative z-30">
                <div className="col-span-2">
                  <h3 className="text-blue-900 font-bold text-sm mb-2">បញ្ជាក់ (Rules):</h3>
                  <ul className="text-[11px] text-blue-900 space-y-1 list-disc pl-4 leading-relaxed">
                    {data.rules.map((rule, idx) => (
                      <li key={idx}>{rule}</li>
                    ))}
                  </ul>
                  <p className="text-blue-900 font-bold text-[10px] mt-3 italic">
                    &gt;&gt; ម្ចាស់ផ្ទះមិនទទួលខុសត្រូវចំពោះការបាត់បង់ ឬខូចខាតទ្រព្យសម្បត្តិផ្ទាល់ខ្លួនរបស់អ្នកជួលឡើយ។
                    <br/>
                    <span className="text-blue-700 font-normal">(The landlord will not be responsible for any loss or damage to the tenant's personal property)</span>
                  </p>
                </div>

                <div className="text-right">
                  <div className="flex justify-between items-center border-b-2 border-stone-800 pb-2 mb-1">
                    <span className="font-bold text-red-600">សរុប (Total USD)</span>
                    <span className="text-3xl font-black text-red-600">${data.totalUsd.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-stone-300 pb-1.5 mb-1 text-blue-900 font-bold">
                    <span className="text-xs">សរុបជាលុយរៀល (Total KHR)</span>
                    <span className="text-lg font-black font-mono">៛{(data.totalUsd * 4000).toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                  </div>
                  <p className="text-[10px] text-red-500 italic">អត្រាប្រាក់ ១ $ = ៤០០០ រៀល (Rate: $1 = 4000 KHR)</p>
                </div>
              </div>

              {/* Signature block */}
              <div className="mt-16 grid grid-cols-2 gap-20 text-center relative z-30">
                <div className="space-y-12">
                  <p className="font-bold text-blue-900">អ្នកជួល (Tenant)</p>
                  <div className="flex flex-col items-center">
                    <p className="font-moul text-blue-900">{data.tenantName}</p>
                  </div>
                </div>
                <div className="space-y-12">
                  <p className="font-bold text-blue-900">ម្ចាស់ផ្ទះ (Landlord)</p>
                  <div className="flex flex-col items-center">
                    <p className="font-moul text-blue-900">{data.landlordName}</p>
                  </div>
                </div>
              </div>

            </div>
          </motion.div>
          )}

          {/* Summary Checker Tab */}
          {activeTab === 'summaryChecker' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full bg-white shadow-2xl rounded-xl overflow-hidden p-6 sm:p-8 border border-stone-200 font-sans"
            >
              {/* Header */}
              <div className="border-b border-stone-200 pb-4 mb-6">
                <h2 className="text-xl font-bold text-stone-800 flex items-center gap-2">
                  <Search className="w-5 h-5 text-emerald-600" />
                  🔍 ពិនិត្យផលបូកសរុប និងទាញយកវិក្កយបត្រ (TOTAL SUMMARY CHECKER & INVOICE GENERATOR)
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  ជ្រើសរើសបន្ទប់ស្នាក់នៅ ដើម្បីពិនិត្យលម្អិតការបង់ប្រាក់ប្រចាំខែ និងទាញយកវិក្កយបត្រសរុបជាលក្ខណៈ 4K PNG។<br/>
                  <span className="text-stone-400">Select a room to review cumulative monthly payments, see the live invoice draft, and download it as high-fidelity 4K PNG.</span>
                </p>
              </div>

              {/* Core Checker Dashboard Row */}
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
                
                {/* LEFT SIDE: SUMMARY LIST & TOTALS (5 cols) */}
                <div className="xl:col-span-5 bg-stone-50 border border-stone-200 rounded-xl p-5 shadow-sm space-y-4">
                  <div>
                    <h3 className="text-xs font-black text-blue-900 uppercase tracking-widest flex items-center gap-1.5">
                      🔎 ពិនិត្យផលបូកសរុបរបស់ភ្ញៀវ (TOTAL SUMMARY CHECKER)
                    </h3>
                    <p className="text-[10px] text-stone-500 mt-0.5">មើលសរុបចំណូលតាមខែនីមួយៗ និងពេញមួយឆ្នាំរបស់ភ្ញៀវនីមួយៗ / View totals of selected room.</p>
                  </div>

                  {/* Room & Statement Date Selectors */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">បន្ទប់ស្នាក់នៅ (Select Room)</label>
                      <select
                        className="bg-white border border-stone-300 rounded px-2.5 py-2 text-xs font-bold text-stone-800 outline-none w-full shadow-sm font-sans"
                        value={inputRoomNo}
                        onChange={(e) => {
                          const rNo = e.target.value;
                          setInputRoomNo(rNo);
                          const tData = savedTenants.find(t => t.roomNo === rNo);
                          if (tData) {
                            setInputTenantName(tData.tenantName);
                            setInputRoomPrice(tData.roomPrice);
                            setInputWifiPrice(tData.wifiPrice);
                          }
                        }}
                      >
                        {sortedSavedTenants.map(t => (
                          <option key={t.roomNo} value={t.roomNo}>បន្ទប់ P.{t.roomNo} ({t.tenantName})</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">កាលបរិច្ឆេទ (Statement Date)</label>
                      <input
                        type="date"
                        className="bg-white border border-stone-300 rounded px-2.5 py-2 text-xs font-bold text-stone-800 outline-none w-full shadow-sm font-sans"
                        value={statementDate}
                        onChange={(e) => setStatementDate(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* 12-Month Checkoff */}
                  <div className="border border-stone-200 bg-white rounded-lg p-3 text-xs space-y-2 max-h-64 overflow-y-auto font-sans">
                    <div className="flex justify-between items-center font-bold text-stone-800 border-b pb-1.5 mb-1.5 text-[11px] uppercase tracking-wider">
                      <span>ខែ (Month)</span>
                      <span>សរុបបង់ (Total Collected)</span>
                    </div>

                    {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((mIndex) => {
                      const mRecord = history.find(h => 
                        (h.roomNo === inputRoomNo || h.tenantName.toLowerCase().trim() === inputTenantName.toLowerCase().trim()) && 
                        h.paymentDate.split('-')[1] === mIndex
                      );
                      
                      return (
                        <div key={mIndex} className="flex justify-between items-center text-[11px] py-1.5 border-b border-stone-50 last:border-0 hover:bg-stone-50 transition-colors">
                          <span className="font-medium text-stone-600 font-sans">ខែ {parseInt(mIndex)} / Month {parseInt(mIndex)}</span>
                          {mRecord ? (
                            <span className="font-mono font-bold text-emerald-600">${mRecord.totalUsd.toFixed(2)}</span>
                          ) : (
                            <span className="text-stone-300 font-mono">—</span>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Year Cumulative box */}
                  <div className="bg-emerald-600 text-white rounded-lg p-3.5 flex justify-between items-center border border-emerald-500 shadow-sm font-sans">
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-100">សរុបរួមរបស់ភ្ញៀវ (Customer Cumulative Total)</p>
                      <p className="text-lg font-black font-mono mt-0.5">
                        ${history.filter(h => 
                          h.roomNo === inputRoomNo || 
                          h.tenantName.toLowerCase().trim() === inputTenantName.toLowerCase().trim()
                        ).reduce((sum, r) => sum + r.totalUsd, 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </p>
                    </div>
                    <span className="text-xl">💰</span>
                  </div>

                  {/* Download 4K Button */}
                  <button
                    type="button"
                    onClick={() => {
                      const filename = `Invoice-Total-Room-${inputRoomNo}-${inputTenantName.trim().replace(/\s+/g, '-')}`;
                      handleDownloadSlip(customerSummaryInvoiceRef, filename);
                    }}
                    disabled={isDownloading}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3 px-4 rounded-lg transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer text-xs uppercase font-sans tracking-wide"
                  >
                    {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                    ទាញយកវិក្កយបត្រសរុប 4K (Download 4K Summation Invoice)
                  </button>
                </div>

                {/* RIGHT SIDE: BEAUTIFUL LIVE PREVIEW OF THE PRINT STATEMENT (7 cols) */}
                <div className="xl:col-span-7 bg-stone-100 p-6 rounded-xl border border-stone-200 flex flex-col items-center overflow-x-auto">
                  <p className="text-xs font-black text-stone-500 uppercase tracking-widest mb-4 font-sans flex items-center gap-1.5">
                    👁️ ទិដ្ឋភាពផ្សាយបន្តផ្ទាល់នៃវិក្កយបត្រ (LIVE SUMMARY STATEMENT PREVIEW)
                  </p>

                  <div className="bg-white p-6 shadow-md border border-stone-200 rounded text-stone-800 w-[500px] text-[11px] font-sans relative shrink-0">
                    {/* Corner accents */}
                    <div className="absolute top-1.5 left-1.5 text-[8px] text-emerald-600/30">✦</div>
                    <div className="absolute top-1.5 right-1.5 text-[8px] text-emerald-600/30">✦</div>

                    {/* Header */}
                    <div className="text-center border-b border-stone-200 pb-3 mb-3">
                      <h4 className="font-moul text-emerald-800 text-xs">វិក្កយបត្រសង្ខេបរបស់ភ្ញៀវ</h4>
                      <h5 className="font-bold text-stone-800 text-[9px] tracking-wider uppercase mt-0.5">CUSTOMER SUMMARY STATEMENT ({statementDate ? statementDate.split('-')[0] : new Date().getFullYear()})</h5>
                      <p className="text-[9px] text-stone-400 font-sans">បន្ទប់ជួលផ្ទះបឹងកេងកង / Boeng Keng Kang Room Rental</p>
                    </div>

                    {/* Info */}
                    <div className="grid grid-cols-2 gap-2 text-[9px] mb-3 pb-3 border-b border-stone-100">
                      <div>
                        <p className="text-stone-500">បន្ទប់ស្នាក់នៅ (Room No): <span className="font-bold text-emerald-800">P.{inputRoomNo}</span></p>
                        <p className="text-stone-500 mt-0.5">ឈ្មោះអ្នកជួល (Tenant Name): <span className="font-bold text-blue-900 font-sans">{inputTenantName}</span></p>
                      </div>
                      <div className="text-right">
                        <p className="text-stone-500">ម្ចាស់ផ្ទះ (Landlord): <span className="font-bold text-stone-700">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</span></p>
                        <p className="text-stone-500 mt-0.5 font-sans">កាលបរិច្ឆេទ (Date): <span className="font-bold text-stone-700">{statementDate ? statementDate.split('-').reverse().join('-') : ''}</span></p>
                      </div>
                    </div>

                    {/* Table */}
                    <table className="w-full text-left border-collapse border border-stone-200 text-[9px] font-sans mb-4">
                      <thead>
                        <tr className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase text-[8px]">
                          <th className="p-1 border border-stone-200">ខែ (Month)</th>
                          <th className="p-1 border border-stone-200 text-right">ថ្លៃបន្ទប់ (Rent)</th>
                          <th className="p-1 border border-stone-200 text-right">ភ្លើង (Elec)</th>
                          <th className="p-1 border border-stone-200 text-right">ទឹក (Water)</th>
                          <th className="p-1 border border-stone-200 text-right">Wifi/ផ្សេងៗ (Wifi/Other)</th>
                          <th className="p-1 border border-stone-200 text-right">សរុប (Total)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((mIndex) => {
                          const mRecord = history.find(h => 
                            (h.roomNo === inputRoomNo || h.tenantName.toLowerCase().trim() === inputTenantName.toLowerCase().trim()) && 
                            h.paymentDate.split('-')[1] === mIndex
                          );

                          return (
                            <tr key={mIndex} className="border-b border-stone-100 hover:bg-stone-50/50">
                              <td className="p-1 border border-stone-200 font-bold">ខែ {parseInt(mIndex)}</td>
                              <td className="p-1 border border-stone-200 text-right font-mono text-stone-500">
                                {mRecord ? `$${mRecord.roomPrice.toFixed(2)}` : '—'}
                              </td>
                              <td className="p-1 border border-stone-200 text-right font-mono text-stone-500">
                                {mRecord ? `$${mRecord.elecPrice.toFixed(2)}` : '—'}
                              </td>
                              <td className="p-1 border border-stone-200 text-right font-mono text-stone-500">
                                {mRecord ? `$${mRecord.waterPrice.toFixed(2)}` : '—'}
                              </td>
                              <td className="p-1 border border-stone-200 text-right font-mono text-stone-500">
                                {mRecord ? `$${(mRecord.wifiPrice + mRecord.otherPrice).toFixed(2)}` : '—'}
                              </td>
                              <td className="p-1 border border-stone-200 text-right font-mono font-bold text-emerald-600">
                                {mRecord ? `$${mRecord.totalUsd.toFixed(2)}` : '—'}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>

                    {/* Total */}
                    <div className="flex justify-between items-center border-t border-stone-400 pt-2 font-bold mb-6 text-[10px]">
                      <span className="uppercase text-stone-700">សរុបប្រមូលបានទាំងអស់ (GRAND TOTAL COLLECTED)</span>
                      <span className="font-mono text-emerald-600 text-xs">
                        ${history.filter(h => 
                          h.roomNo === inputRoomNo || 
                          h.tenantName.toLowerCase().trim() === inputTenantName.toLowerCase().trim()
                        ).reduce((sum, r) => sum + r.totalUsd, 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>

                    {/* Stamp & Signs */}
                    <div className="grid grid-cols-2 gap-6 text-center text-[8px] font-sans border-t border-dashed border-stone-200 pt-4 relative">
                      {/* CSS Landlord Official Red Circular Stamp/Seal */}
                      <div className="absolute left-[38%] top-[-10px] pointer-events-none select-none flex items-center justify-center scale-75">
                        <div className="w-[60px] h-[60px] rounded-full border-[2px] border-red-500/80 flex items-center justify-center p-0.5 relative rotate-[-12deg]">
                          <div className="w-[50px] h-[50px] rounded-full border border-dashed border-red-500/80 flex items-center justify-center relative">
                            <span className="absolute text-[4px] font-black text-red-500/80 uppercase tracking-wider text-center leading-none">
                              បន្ទប់ជួលផ្ទះបឹងកេងកង
                            </span>
                            <span className="absolute bottom-1 text-[3.5px] font-bold text-red-500/80 tracking-widest uppercase">
                              * ម្ចាស់ផ្ទះ *
                            </span>
                            <div className="text-xs text-red-500/80 select-none">💮</div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <p className="text-stone-400">ហត្ថលេខាអ្នកជួល (Tenant)</p>
                        <div className="h-6"></div>
                        <p className="font-bold text-stone-700">{inputTenantName}</p>
                      </div>
                      <div>
                        <p className="text-stone-400">ហត្ថលេខាម្ចាស់ផ្ទះ (Owner)</p>
                        <div className="h-6"></div>
                        <p className="font-bold text-stone-700">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</p>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </motion.div>
          )}

          {/* Admin / Reports Tab */}
          {activeTab === 'reports' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full bg-white shadow-2xl rounded-xl overflow-hidden p-6 sm:p-8 border border-stone-200 font-sans"
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-stone-200 pb-4 mb-6">
                <div>
                  <h2 className="text-xl font-bold text-stone-800 flex items-center gap-2">
                    <Database className="w-5 h-5 text-emerald-600" />
                    ផ្ទាំងគ្រប់គ្រង និងស្ថិតិចំណូល (Admin Dashboard & Revenue Statistics)
                  </h2>
                  <p className="text-xs text-stone-500 mt-1">
                    ពិនិត្យបញ្ជីឈ្មោះអ្នកជួលសរុប និងស្ថិតិលម្អិតនៃចំណូលផ្សេងៗ។<br/>
                    <span className="text-stone-400">View aggregate tenant list and detailed revenue statistics.</span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowManualPayForm(!showManualPayForm)}
                  className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-3 rounded shadow-sm transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  កត់ត្រាចំណូលដោយដៃ (Record Manual Transaction)
                </button>
              </div>

              {/* Manual Payment Form */}
              {showManualPayForm && (
                <form onSubmit={handleManualPaymentSubmit} className="bg-stone-50 border border-stone-200 rounded-lg p-5 mb-6 space-y-4 border-l-4 border-l-emerald-500 font-sans">
                  <div className="flex justify-between items-center border-b border-stone-200 pb-2">
                    <h3 className="text-xs font-bold text-stone-700 uppercase tracking-wider">កត់ត្រាចំណូលដោយដៃ (Record Manual Transaction)</h3>
                    <button type="button" onClick={() => setShowManualPayForm(false)} className="text-stone-400 hover:text-stone-600 text-xs font-bold">បិទ (Close)</button>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">លេខបន្ទប់ (Room No) *</label>
                      <select
                        required
                        className="w-full bg-white border border-stone-200 rounded p-2 text-stone-800 outline-none focus:border-emerald-500 font-sans"
                        value={manualPay.roomNo}
                        onChange={(e) => {
                          const rNo = e.target.value;
                          const tenant = savedTenants.find(t => t.roomNo === rNo);
                          setManualPay(prev => {
                            const updated = {
                              ...prev,
                              roomNo: rNo,
                              tenantName: tenant ? tenant.tenantName : prev.tenantName,
                              roomPrice: tenant ? tenant.roomPrice : prev.roomPrice,
                              wifiPrice: tenant ? tenant.wifiPrice : prev.wifiPrice
                            };
                            updated.totalUsd = Number(updated.roomPrice) + Number(updated.wifiPrice) + Number(updated.elecPrice) + Number(updated.waterPrice) + Number(updated.otherPrice);
                            return updated;
                          });
                        }}
                      >
                        <option value="">-- Select Room --</option>
                        {sortedSavedTenants.map(t => (
                          <option key={t.roomNo} value={t.roomNo}>P.{t.roomNo} ({t.tenantName})</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1 font-sans">ឈ្មោះអ្នកជួល (Tenant Name) *</label>
                      <input
                        type="text"
                        required
                        placeholder="Tenant Name"
                        className="w-full bg-white border border-stone-200 rounded p-2 text-stone-800 outline-none focus:border-emerald-500 font-bold"
                        value={manualPay.tenantName}
                        onChange={(e) => setManualPay(prev => ({ ...prev, tenantName: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1 font-sans">កាលបរិច្ឆេទ (Payment Date) *</label>
                      <input
                        type="date"
                        required
                        className="w-full bg-white border border-stone-200 rounded p-2 text-stone-800 outline-none focus:border-emerald-500 font-sans"
                        value={manualPay.paymentDate}
                        onChange={(e) => setManualPay(prev => ({ ...prev, paymentDate: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1 font-sans">ថ្លៃបន្ទប់ (Room Price) ($)</label>
                      <input
                        type="number"
                        className="w-full bg-white border border-stone-200 rounded p-2 text-stone-800 outline-none focus:border-emerald-500 font-bold"
                        value={manualPay.roomPrice || ''}
                        onChange={(e) => handleManualPayChange('roomPrice', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1 font-sans">ថ្លៃ Wifi (Wi-Fi Price) ($)</label>
                      <input
                        type="number"
                        className="w-full bg-white border border-stone-200 rounded p-2 text-stone-800 outline-none focus:border-emerald-500 font-bold"
                        value={manualPay.wifiPrice || ''}
                        onChange={(e) => handleManualPayChange('wifiPrice', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1 font-sans">ថ្លៃអគ្គិសនី (Electricity) ($)</label>
                      <input
                        type="number"
                        className="w-full bg-white border border-stone-200 rounded p-2 text-stone-800 outline-none focus:border-emerald-500 font-bold"
                        value={manualPay.elecPrice || ''}
                        onChange={(e) => handleManualPayChange('elecPrice', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1 font-sans">ថ្លៃទឹកស្អាត (Water Price) ($)</label>
                      <input
                        type="number"
                        className="w-full bg-white border border-stone-200 rounded p-2 text-stone-800 outline-none focus:border-emerald-500 font-bold"
                        value={manualPay.waterPrice || ''}
                        onChange={(e) => handleManualPayChange('waterPrice', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1 font-sans">ផ្សេងៗ (Other Price) ($)</label>
                      <input
                        type="number"
                        className="w-full bg-white border border-stone-200 rounded p-2 text-stone-800 outline-none focus:border-emerald-500 font-bold"
                        value={manualPay.otherPrice || ''}
                        onChange={(e) => handleManualPayChange('otherPrice', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pt-3 border-t border-stone-200">
                    <div className="text-xs font-bold text-stone-700 font-sans">
                      ទឹកប្រាក់សរុប (Total Amount): <span className="text-emerald-600 font-mono text-sm font-black">${manualPay.totalUsd.toFixed(2)}</span>
                    </div>
                    <div className="flex gap-2 w-full sm:w-auto">
                      <button
                        type="submit"
                        className="flex-1 sm:flex-none bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-1.5 px-4 rounded text-xs transition-colors shadow-sm font-sans"
                      >
                        កត់ត្រាការទូទាត់ (Record Transaction)
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowManualPayForm(false)}
                        className="flex-1 sm:flex-none bg-stone-200 hover:bg-stone-300 text-stone-700 font-bold py-1.5 px-3 rounded text-xs transition-colors font-sans"
                      >
                        បោះបង់ (Cancel)
                      </button>
                    </div>
                  </div>
                </form>
              )}

              {/* Month Filter Selector */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 mb-6 font-sans">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <h3 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5 font-sans">
                      <Calendar className="w-4 h-4 text-emerald-600" />
                      ជម្រើសចម្រាញ់តាមខែ (MONTH FILTER SELECTOR)
                    </h3>
                    <p className="text-[11px] text-stone-500 mt-0.5">ជ្រើសរើសខែជាក់លាក់ដើម្បីចម្រាញ់ចំណូល ប្រាក់បៀវត្សរ៍បុគ្គលិក និងចំណូលសុទ្ធរបស់ម្ចាស់ផ្ទះ។ / Select a specific month to filter revenue, staff salaries, and landlord net profit.</p>
                  </div>
                  
                  {/* Month Selector Buttons */}
                  <div className="flex flex-wrap gap-1 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={() => setSelectedMonth('all')}
                      className={`px-3 py-1.5 text-xs font-bold rounded transition-all ${
                        selectedMonth === 'all'
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
                      }`}
                    >
                      ទាំងអស់ (All)
                    </button>
                    {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setSelectedMonth(m)}
                        className={`px-2 py-1.5 text-xs font-bold rounded transition-all font-mono ${
                          selectedMonth === m
                            ? 'bg-emerald-600 text-white shadow-sm'
                            : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
                        }`}
                      >
                        ខែ {parseInt(m)} (M{parseInt(m)})
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Section Header: Monthly Financial Status */}
              <div className="mb-4 flex items-center justify-between border-b border-stone-100 pb-2">
                <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                  ទិន្នន័យ (Data): {selectedMonth === 'all' ? 'គ្រប់ខែទាំងអស់ឆ្នាំ 2026 / All Months 2026' : `ខែ ${parseInt(selectedMonth)} / 2026 (Month ${parseInt(selectedMonth)} / 2026)`}
                </span>
                <span className="text-[11px] text-stone-400">
                  ប្រមូលបាន (Collected): {totalRoomsRented} បន្ទប់ (Rooms)
                </span>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6 font-sans">
                <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 shadow-sm">
                  <p className="text-[10px] font-bold text-stone-500 uppercase tracking-wide">ចំណូលសរុប / Total Income</p>
                  <p className="text-2xl font-black text-emerald-600 font-mono mt-1 tabular-nums">${totalIncome.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  <p className="text-[10px] text-stone-400 mt-1">{(totalIncome * 4000).toLocaleString()} ៛ (1$ = 4000៛)</p>
                </div>
                <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 shadow-sm">
                  <p className="text-[10px] font-bold text-stone-500 uppercase tracking-wide">ចំណូលថ្លៃបន្ទប់ / Room Rent</p>
                  <p className="text-xl font-black text-blue-900 font-mono mt-1.5 tabular-nums">${totalRoomRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  <p className="text-[10px] text-stone-400 mt-1">សមាមាត្រ (Ratio): {totalIncome > 0 ? ((totalRoomRevenue / totalIncome) * 100).toFixed(0) : 0}%</p>
                </div>
                <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 shadow-sm">
                  <p className="text-[10px] font-bold text-stone-500 uppercase tracking-wide">ថ្លៃទឹកភ្លើង / Electricity & Water</p>
                  <p className="text-xl font-black text-amber-600 font-mono mt-1.5 tabular-nums">${totalUtilRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  <p className="text-[10px] text-stone-400 mt-1">សមាមាត្រ (Ratio): {totalIncome > 0 ? ((totalUtilRevenue / totalIncome) * 100).toFixed(0) : 0}%</p>
                </div>
                <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 shadow-sm">
                  <p className="text-[10px] font-bold text-stone-500 uppercase tracking-wide">Wifi & ផ្សេងៗ / Wi-Fi & Other</p>
                  <p className="text-xl font-black text-sky-600 font-mono mt-1.5 tabular-nums">${(totalWifiRevenue + totalOtherRevenue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  <p className="text-[10px] text-stone-400 mt-1">សមាមាត្រ (Ratio): {totalIncome > 0 ? (((totalWifiRevenue + totalOtherRevenue) / totalIncome) * 100).toFixed(0) : 0}%</p>
                </div>
              </div>

              {/* Salary and Landlord Net Income Section (REQUESTED) */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 font-sans">
                {/* Sovanna Salary Card */}
                <div className="bg-amber-50/60 border border-amber-200/80 rounded-xl p-4 shadow-sm flex flex-col justify-between">
                  <div>
                    <p className="text-[10px] font-extrabold text-amber-800 uppercase tracking-wider">ប្រាក់ខែអ្នកទទួលបន្ទុក (Sovanna - 20%) / Sovanna Salary (20%)</p>
                    <p className="text-xl font-black text-amber-700 font-mono mt-1.5 tabular-nums">
                      ${sovannaSalaryFiltered.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="text-[10px] text-amber-600/90 mt-2 font-sans border-t border-amber-200/40 pt-1.5 leading-relaxed">
                    គណនា៖ ២០% ថ្លៃបន្ទប់ (${(totalRoomRevenue * 0.20).toFixed(2)}) + ១០០% ទឹកភ្លើង និង Wifi (${utilsAndWifiFiltered.toFixed(2)}) <br />
                    Formula: 20% Room share + 100% Utilities & Wifi
                  </div>
                </div>

                {/* Pheak Salary Card */}
                <div className="bg-sky-50/60 border border-sky-200/80 rounded-xl p-4 shadow-sm flex flex-col justify-between">
                  <div>
                    <p className="text-[10px] font-extrabold text-sky-800 uppercase tracking-wider">
                      ប្រាក់ខែអ្នកគ្រប់គ្រង (Pheak - {selectedMonth !== 'all' && parseInt(selectedMonth) >= 10 ? '$10' : (selectedMonth === 'all' ? '$15/$10' : '$15')}/បន្ទប់) / Pheak Salary ({selectedMonth !== 'all' && parseInt(selectedMonth) >= 10 ? '$10' : (selectedMonth === 'all' ? '$15/$10' : '$15')}/room)
                    </p>
                    <p className="text-xl font-black text-sky-700 font-mono mt-1.5 tabular-nums">
                      ${pheakSalaryFiltered.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="text-[10px] text-sky-600/90 mt-2 font-sans border-t border-sky-200/40 pt-1.5 leading-relaxed">
                    គណនា៖ {selectedMonth !== 'all' && parseInt(selectedMonth) >= 10 ? '$10' : (selectedMonth === 'all' ? 'ចម្រុះ (Mixed)' : '$15')} × {totalRoomsRented} បន្ទប់ (Rooms) <br />
                    Formula: {selectedMonth !== 'all' && parseInt(selectedMonth) >= 10 ? '$10' : (selectedMonth === 'all' ? 'Mixed' : '$15')} × {totalRoomsRented} rooms rented
                    {selectedMonth === 'all' && " (Months 1-9: $15/room, Months 10-12: $10/room)"}
                  </div>
                </div>

                {/* Landlord Net Income Card */}
                <div className="bg-emerald-600 text-white rounded-xl p-4 shadow-md flex flex-col justify-between border border-emerald-500">
                  <div>
                    <p className="text-[10px] font-extrabold text-emerald-100 uppercase tracking-wider">ចំណូលសុទ្ធម្ចាស់ផ្ទះ (Landlord Net Revenue)</p>
                    <p className="text-2xl font-black font-mono mt-1 tabular-nums">
                      ${landlordNetFiltered.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="text-[10px] text-emerald-100/80 mt-2 font-sans border-t border-emerald-500/40 pt-1.5 leading-relaxed">
                    ការទទួលបានពិតប្រាកដ៖ ថ្លៃបន្ទប់ (${totalRoomRevenue.toFixed(2)}) - ចំណែក Sovanna (${(totalRoomRevenue * 0.20).toFixed(2)}) - ថ្លៃ Pheak (${pheakSalaryFiltered.toFixed(2)}) <br />
                    Actual: Room Rent - Sovanna Share - Pheak Fee
                  </div>
                </div>
              </div>

              {/* Proportion Bar */}
              <div className="mb-6 font-sans">
                <div className="flex justify-between items-center mb-1.5 text-xs text-stone-600 font-bold">
                  <span>ការបែងចែកចំណូលសរុប (Revenue Distribution Ratio):</span>
                  <span className="text-stone-400 font-normal">Room Rent / Utilities / Wifi & Other</span>
                </div>
                <div className="h-3 w-full bg-stone-100 rounded-full overflow-hidden flex shadow-inner">
                  {totalIncome > 0 ? (
                    <>
                      <div style={{ width: `${(totalRoomRevenue / totalIncome) * 100}%` }} className="bg-blue-900 transition-all animate-pulse-slow" title={`Room Rent: ${((totalRoomRevenue / totalIncome) * 100).toFixed(1)}%`} />
                      <div style={{ width: `${(totalUtilRevenue / totalIncome) * 100}%` }} className="bg-amber-500 transition-all animate-pulse-slow" title={`Utilities: ${((totalUtilRevenue / totalIncome) * 100).toFixed(1)}%`} />
                      <div style={{ width: `${((totalWifiRevenue + totalOtherRevenue) / totalIncome) * 100}%` }} className="bg-sky-400 transition-all animate-pulse-slow" title={`Wifi & Other: ${(((totalWifiRevenue + totalOtherRevenue) / totalIncome) * 100).toFixed(1)}%`} />
                    </>
                  ) : (
                    <div className="w-full bg-stone-200" />
                  )}
                </div>
              </div>

              {/* Recharts Monthly Revenue Comparison Chart */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-5 mb-8 font-sans">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4 border-b border-stone-200 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-blue-900 uppercase flex items-center gap-1.5">
                      📈 របាយការណ៍ចំណូលប្រចាំខែសម្រាប់ឆ្នាំ {new Date().getFullYear()} / MONTHLY REVENUE CHART {new Date().getFullYear()}
                    </h3>
                    <p className="text-[11px] text-stone-500 mt-0.5">ការប្រៀបធៀបប្រភពចំណូលលម្អិតប្រចាំខែ (ថ្លៃបន្ទប់ ទឹកភ្លើង វ៉ាយហ្វាយ និងផ្សេងៗ) / Detailed monthly revenue source comparison (Room Rent, Utilities, Wi-Fi & Other).</p>
                  </div>
                  <div className="flex flex-wrap gap-x-3 gap-y-1 text-[10px] font-bold text-stone-600">
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-blue-900 rounded-sm inline-block" /> Room Rent</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-amber-500 rounded-sm inline-block" /> Utilities</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-sky-400 rounded-sm inline-block" /> Wifi & Other</span>
                    <span className="flex items-center gap-1"><span className="w-2 h-0.5 bg-emerald-600 inline-block" /> Total Revenue</span>
                  </div>
                </div>
                
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={monthlyChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
                      <XAxis dataKey="name" stroke="#78716c" fontSize={10} tickLine={false} />
                      <YAxis stroke="#78716c" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(v) => `$${v}`} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #e5e5e5', fontSize: '11px', fontFamily: 'sans-serif', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                        formatter={(value) => [`$${Number(value).toFixed(2)}`]}
                      />
                      <Bar dataKey="Room Rent" stackId="a" fill="#1e3a8a" radius={[0, 0, 0, 0]} />
                      <Bar dataKey="Utilities" stackId="a" fill="#f59e0b" radius={[0, 0, 0, 0]} />
                      <Bar dataKey="Wifi & Other" stackId="a" fill="#38bdf8" radius={[4, 4, 0, 0]} />
                      <Line type="monotone" dataKey="Total Revenue" stroke="#059669" strokeWidth={2.5} dot={{ r: 3, fill: '#059669' }} activeDot={{ r: 5 }} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Monthly Revenue & Staff Salary Table */}
              <div className="space-y-4 font-sans mb-8">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-stone-50 border border-stone-200 rounded-lg p-3">
                  <div>
                    <h3 className="text-sm font-bold text-blue-900 uppercase flex items-center gap-1.5">
                      📊 តារាងសង្ខេបចំណូល និងប្រាក់បៀវត្សរ៍ប្រចាំខែ (MONTHLY REVENUE & SALARY SUMMARY)
                    </h3>
                    <p className="text-[11px] text-stone-500 mt-0.5">
                      ស្ថិតិលម្អិតនៃចំណូលសុទ្ធរបស់ម្ចាស់ផ្ទះ បន្ទាប់ពីទូទាត់ប្រាក់ខែឱ្យ Sovanna (20%) និង Pheak ({selectedMonth !== 'all' && parseInt(selectedMonth) >= 10 ? '$10' : (selectedMonth === 'all' ? '$15/$10' : '$15')}/បន្ទប់) ប្រចាំខែ។<br/>
                      <span className="text-stone-400">Detailed landlord net profit statistics after paying Sovanna (20% room rental + utilities) and Pheak ({selectedMonth !== 'all' && parseInt(selectedMonth) >= 10 ? '$10' : (selectedMonth === 'all' ? '$15/$10' : '$15')}/room) monthly.</span>
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2 items-center">
                    <button
                      type="button"
                      onClick={() => setIsEditModeActive(!isEditModeActive)}
                      className={`px-3 py-1.5 rounded text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 ${
                        isEditModeActive 
                          ? 'bg-amber-600 text-white hover:bg-amber-700' 
                          : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
                      }`}
                    >
                      <Edit className="w-3.5 h-3.5" />
                      {isEditModeActive ? '✓ កំពុងកែសម្រួល (Editing)' : '✍️ បញ្ចូលទិន្នន័យដោយដៃ (Manual Input)'}
                    </button>

                    {/* Styled Month Selection Dropdown */}
                    <div className="flex items-center gap-1.5 bg-white border border-stone-200 rounded px-2.5 py-1.5 text-xs font-bold text-stone-700 shadow-sm">
                      <span className="text-stone-400 font-normal">ខែបង្ហាញ (Show Month):</span>
                      <select
                        className="bg-transparent border-none outline-none font-bold text-stone-800 cursor-pointer pr-1 font-sans"
                        value={selectedMonth}
                        onChange={(e) => setSelectedMonth(e.target.value)}
                      >
                        <option value="all">គ្រប់ខែទាំងអស់ (All Months)</option>
                        {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((m) => (
                          <option key={m} value={m}>ខែ {parseInt(m)} (Month {parseInt(m)})</option>
                        ))}
                      </select>
                    </div>
                    <div className="text-[11px] text-stone-400 font-sans italic">
                      *ចុចប៊ូតុង "មើល (View)" នៅជួរណាមួយដើម្បីពិនិត្យរបាយការណ៍លម្អិត / *Click "View" button to view that month's details
                    </div>
                  </div>
                </div>
                
                {isEditModeActive && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="bg-amber-50/40 border border-amber-200 rounded-xl p-5 mb-2 shadow-sm font-sans"
                  >
                    <h4 className="text-xs font-bold text-amber-800 uppercase tracking-wider mb-1 flex items-center gap-1.5 font-sans">
                      <Edit className="w-4 h-4" />
                      ទម្រង់បញ្ចូលទិន្នន័យដោយដៃប្រចាំខែ (MONTHLY MANUAL INPUT FORM)
                    </h4>
                    <p className="text-[11px] text-amber-700/90 mb-4 font-sans leading-relaxed">
                      ✍️ <strong>សេចក្តីណែនាំ៖</strong> ថ្លៃទឹក អគ្គិសនី និងវ៉ាយហ្វាយ នឹងត្រូវបំបែកចេញពីប្រាក់ចំណូលបន្ទប់ ហើយបូកបញ្ចូលទៅក្នុងប្រាក់ខែរបស់ <strong>Sovanna</strong> 100%។ <br />
                      💡 <strong>Info:</strong> Water, electricity, and Wi-Fi will be separated from room revenue and added 100% to <strong>Sovanna's</strong> salary.
                    </p>
                    
                    <form onSubmit={handleSaveManualForm} className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3 text-xs">
                      {/* 1. Select Month */}
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ខែបញ្ចូល (Month)</label>
                        <select
                          className="w-full bg-white border border-stone-200 rounded p-1.5 font-bold text-stone-800 outline-none focus:border-amber-500"
                          value={formMonth}
                          onChange={(e) => setFormMonth(e.target.value)}
                        >
                          {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((m) => (
                            <option key={m} value={m}>Month {parseInt(m)}</option>
                          ))}
                        </select>
                      </div>

                      {/* 2. Number of rooms */}
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ចំនួនបន្ទប់ (Rooms)</label>
                        <input
                          type="number"
                          className="w-full bg-white border border-stone-200 rounded p-1.5 font-mono font-bold text-stone-800 outline-none focus:border-amber-500"
                          placeholder="Rooms"
                          value={formRooms || ''}
                          onChange={(e) => setFormRooms(Number(e.target.value) || 0)}
                        />
                      </div>

                      {/* 3. Room price amount */}
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ប្រាក់បន្ទប់សរុប (Total Room Rent - $)</label>
                        <input
                          type="number"
                          step="0.01"
                          className="w-full bg-white border border-stone-200 rounded p-1.5 font-mono font-bold text-stone-800 outline-none focus:border-amber-500"
                          placeholder="Total Room Rent"
                          value={formTotalUsd || ''}
                          onChange={(e) => setFormTotalUsd(Number(e.target.value) || 0)}
                        />
                      </div>

                      {/* 4. Security deposit */}
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ប្រាក់កក់ (Deposit - $)</label>
                        <input
                          type="number"
                          step="0.01"
                          className="w-full bg-white border border-stone-200 rounded p-1.5 font-mono font-bold text-stone-800 outline-none focus:border-amber-500"
                          placeholder="Deposit"
                          value={formDeposit || ''}
                          onChange={(e) => setFormDeposit(Number(e.target.value) || 0)}
                        />
                      </div>

                      {/* 5. Electricity fee */}
                      <div>
                        <label className="block text-[10px] font-bold text-amber-700 uppercase mb-1">ថ្លៃអគ្គិសនី (Electricity - ៛)</label>
                        <input
                          type="number"
                          step="100"
                          className="w-full bg-white border border-stone-200 rounded p-1.5 font-mono font-bold text-amber-700 border-amber-200 outline-none focus:border-amber-500"
                          placeholder="Electricity KHR (៛)"
                          value={formElectricity || ''}
                          onChange={(e) => setFormElectricity(Number(e.target.value) || 0)}
                        />
                      </div>

                      {/* 6. Water fee */}
                      <div>
                        <label className="block text-[10px] font-bold text-blue-700 uppercase mb-1">ថ្លៃទឹកស្អាត (Water - ៛)</label>
                        <input
                          type="number"
                          step="100"
                          className="w-full bg-white border border-stone-200 rounded p-1.5 font-mono font-bold text-blue-700 border-blue-200 outline-none focus:border-amber-500"
                          placeholder="Water KHR (៛)"
                          value={formWater || ''}
                          onChange={(e) => setFormWater(Number(e.target.value) || 0)}
                        />
                      </div>

                      {/* 7. Wi-Fi fee */}
                      <div>
                        <label className="block text-[10px] font-bold text-sky-700 uppercase mb-1">ថ្លៃវ៉ាយហ្វាយ (Wi-Fi - $)</label>
                        <input
                          type="number"
                          step="0.01"
                          className="w-full bg-white border border-stone-200 rounded p-1.5 font-mono font-bold text-sky-700 border-sky-200 outline-none focus:border-amber-500"
                          placeholder="Wi-Fi"
                          value={formWifi || ''}
                          onChange={(e) => setFormWifi(Number(e.target.value) || 0)}
                        />
                      </div>

                      {/* Action Buttons */}
                      <div className="col-span-2 sm:col-span-4 md:col-span-7 flex justify-end gap-2 mt-2">
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`តើអ្នកប្រាកដជាចង់កំណត់ឡើងវិញទិន្នន័យខែ ${parseInt(formMonth)} ទៅជាទិន្នន័យដើមរបស់ប្រព័ន្ធវិញឬទេ? / Are you sure you want to RESET Month ${parseInt(formMonth)} data to system automatic records?`)) {
                              saveCustomMonthData(formMonth.padStart(2, '0'), 'useCustom', false);
                            }
                          }}
                          className="bg-stone-200 hover:bg-stone-300 text-stone-700 font-bold px-3 py-1.5 rounded transition-all shadow-sm cursor-pointer"
                        >
                          កំណត់ឡើងវិញ (Reset)
                        </button>
                        <button
                          type="submit"
                          className="bg-amber-600 hover:bg-amber-700 text-white font-bold px-4 py-1.5 rounded transition-all shadow-md cursor-pointer"
                        >
                          រក្សាទុក (Save Data)
                        </button>
                      </div>
                    </form>
                  </motion.div>
                )}
                
                <div className="overflow-x-auto border border-stone-200 rounded-lg shadow-sm bg-white">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase text-[10px] font-bold">
                        <th className="p-2.5 w-[140px]">ខែ (Month)</th>
                        <th className="p-2.5 w-[110px]">ប្រភព (Source)</th>
                        <th className="p-2.5 text-center w-[100px]">ចំនួនបន្ទប់ (Rooms)</th>
                        <th className="p-2.5 text-right w-[120px]">ចំណូលថ្លៃបន្ទប់ (Room Rent - $)</th>
                        <th className="p-2.5 text-right w-[110px] text-amber-700">ប្រាក់កក់ (Deposit - $)</th>
                        <th className="p-2.5 text-right w-[110px] text-amber-600">ថ្លៃអគ្គិសនី (Electricity - ៛)</th>
                        <th className="p-2.5 text-right w-[110px] text-blue-600">ថ្លៃទឹកស្អាត (Water - ៛)</th>
                        <th className="p-2.5 text-right w-[110px] text-sky-600">ថ្លៃវ៉ាយហ្វាយ (Wi-Fi - $)</th>
                        <th className="p-2.5 text-right w-[150px]">ប្រាក់ខែ Sovanna (Sovanna Salary)</th>
                        <th className="p-2.5 text-right w-[110px]">ប្រាក់ខែ Pheak (Pheak Salary)</th>
                        <th className="p-2.5 text-right font-bold text-emerald-700">ចំណូលសុទ្ធម្ចាស់ផ្ទះ (Landlord Net)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {(selectedMonth === 'all'
                        ? [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
                        : [parseInt(selectedMonth)]
                      ).map((m) => {
                        const stats = getMonthlyStats(m);
                        const isSelected = selectedMonth === stats.monthStr;
                        const monthStr = stats.monthStr;
                        
                        return (
                          <tr 
                            key={m} 
                            onClick={() => setSelectedMonth(stats.monthStr)}
                            className={`transition-colors ${
                              isSelected 
                                ? 'bg-emerald-50/40 font-medium' 
                                : 'hover:bg-stone-50/50'
                            }`}
                          >
                            {/* Month & View Action Button */}
                            <td className="p-2.5 font-bold text-stone-800">
                              <div className="flex items-center gap-1.5">
                                <span className={`px-2 py-0.5 rounded text-[11px] font-black font-sans shrink-0 ${
                                  isSelected ? 'bg-emerald-600 text-white' : 'bg-stone-100 text-stone-700'
                                }`}>
                                  ខែ {m} (Month {m})
                                </span>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedMonth(stats.monthStr);
                                  }}
                                  className="px-1.5 py-0.5 bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 rounded text-[9px] font-extrabold transition-all shrink-0"
                                  title="មើលព័ត៌មានលម្អិត / View slip details"
                                >
                                  មើល (View)
                                </button>
                              </div>
                            </td>

                            {/* Data Source Switcher */}
                            <td className="p-2.5">
                              <label 
                                onClick={(e) => e.stopPropagation()} 
                                className="flex items-center gap-1 cursor-pointer select-none"
                              >
                                <input
                                  type="checkbox"
                                  checked={stats.useCustom}
                                  onChange={(e) => {
                                    saveCustomMonthData(monthStr, 'useCustom', e.target.checked);
                                  }}
                                  className="rounded border-stone-300 text-emerald-600 focus:ring-emerald-500 w-3 h-3"
                               CustomName="source" />
                                <span className={`text-[9px] font-bold ${stats.useCustom ? 'text-amber-700' : 'text-stone-400'}`}>
                                  {stats.useCustom ? 'ដោយដៃ (Manual)' : 'ស្វ័យប្រវត្តិ (Auto)'}
                                </span>
                              </label>
                            </td>

                            {/* Rooms Count */}
                            <td className="p-2.5 text-center font-mono">
                              {isEditModeActive ? (
                                <div onClick={(e) => e.stopPropagation()} className="flex flex-col items-center gap-0.5">
                                  <input
                                    type="number"
                                    placeholder="បន្ទប់"
                                    className="w-11 bg-white border border-stone-200 rounded px-1 py-0.5 text-[11px] font-bold text-stone-800 text-center outline-none focus:border-amber-500 font-mono"
                                    value={stats.customRoomsCount || ''}
                                    onChange={(e) => {
                                      const val = parseInt(e.target.value) || 0;
                                      saveCustomMonthData(monthStr, 'roomsCount', val);
                                      saveCustomMonthData(monthStr, 'useCustom', true);
                                    }}
                                  />
                                  <span className="text-[8px] text-stone-400 font-sans">ដើម (Base): {stats.autoRoomsCount}</span>
                                </div>
                              ) : (
                                <div className="flex flex-col items-center">
                                  <span className="font-bold text-stone-700">{stats.roomsCount} បន្ទប់ (Rooms)</span>
                                  <span className="text-[8px] text-stone-400">ដើម (Base): {stats.autoRoomsCount}</span>
                                </div>
                              )}
                            </td>

                            {/* Total Revenue */}
                            <td className="p-2.5 text-right font-mono">
                              {isEditModeActive ? (
                                <div onClick={(e) => e.stopPropagation()} className="flex flex-col items-end gap-0.5">
                                  <input
                                    type="number"
                                    placeholder="ថ្លៃបន្ទប់"
                                    className="w-16 bg-white border border-stone-200 rounded px-1 py-0.5 text-[11px] font-bold text-stone-800 text-right outline-none focus:border-amber-500 font-mono"
                                    value={stats.customTotalUsd || ''}
                                    onChange={(e) => {
                                      const val = parseFloat(e.target.value) || 0;
                                      saveCustomMonthData(monthStr, 'totalUsd', val);
                                      saveCustomMonthData(monthStr, 'useCustom', true);
                                    }}
                                  />
                                  <span className="text-[8px] text-stone-400 font-sans">ដើម (Base): ${stats.autoRoomRevenue.toFixed(0)}</span>
                                </div>
                              ) : (
                                <div className="flex flex-col items-end">
                                  <span className="font-bold text-stone-700">${stats.roomRevenue.toFixed(1)}</span>
                                  <span className="text-[8px] text-stone-400">ដើម (Base): ${stats.autoRoomRevenue.toFixed(0)}</span>
                                </div>
                              )}
                            </td>

                            {/* Security Deposit */}
                            <td className="p-2.5 text-right font-mono text-amber-800">
                              {isEditModeActive ? (
                                <div onClick={(e) => e.stopPropagation()} className="flex flex-col items-end gap-0.5">
                                  <input
                                    type="number"
                                    placeholder="ប្រាក់កក់"
                                    className="w-14 bg-white border border-stone-200 rounded px-1 py-0.5 text-[11px] font-bold text-amber-800 text-right outline-none focus:border-amber-500 font-mono"
                                    value={stats.customDeposit || ''}
                                    onChange={(e) => {
                                      const val = parseFloat(e.target.value) || 0;
                                      saveCustomMonthData(monthStr, 'deposit', val);
                                      saveCustomMonthData(monthStr, 'useCustom', true);
                                    }}
                                  />
                                  <span className="text-[8px] text-stone-400 font-sans">ដើម (Base): ${stats.autoDeposit.toFixed(0)}</span>
                                </div>
                              ) : (
                                <div className="flex flex-col items-end">
                                  <span className="font-bold text-amber-800">${stats.deposit.toFixed(1)}</span>
                                  <span className="text-[8px] text-stone-400">ដើម (Base): ${stats.autoDeposit.toFixed(0)}</span>
                                </div>
                              )}
                            </td>

                            {/* Electricity Revenue */}
                            <td className="p-2.5 text-right font-mono text-amber-600">
                              {isEditModeActive ? (
                                <div onClick={(e) => e.stopPropagation()} className="flex flex-col items-end gap-0.5">
                                  <input
                                    type="number"
                                    placeholder="អគ្គិសនី"
                                    className="w-14 bg-white border border-stone-200 rounded px-1 py-0.5 text-[11px] font-bold text-amber-700 text-right outline-none focus:border-amber-500 font-mono"
                                    value={stats.customElectricityRevenue ? Math.round(stats.customElectricityRevenue * 4000) : ''}
                                    onChange={(e) => {
                                      const val = parseFloat(e.target.value) || 0;
                                      saveCustomMonthData(monthStr, 'electricityRevenue', val / 4000);
                                      saveCustomMonthData(monthStr, 'useCustom', true);
                                    }}
                                  />
                                  <span className="text-[8px] text-stone-400 font-sans">ដើម (Base): {Math.round(stats.autoElectricityRevenue * 4000).toLocaleString()}៛</span>
                                </div>
                              ) : (
                                <div className="flex flex-col items-end">
                                  <span className="font-bold text-amber-600">{Math.round(stats.electricityRevenue * 4000).toLocaleString()}៛</span>
                                  <span className="text-[8px] text-stone-400">(${stats.electricityRevenue.toFixed(1)})</span>
                                </div>
                              )}
                            </td>

                            {/* Water Revenue */}
                            <td className="p-2.5 text-right font-mono text-blue-600">
                              {isEditModeActive ? (
                                <div onClick={(e) => e.stopPropagation()} className="flex flex-col items-end gap-0.5">
                                  <input
                                    type="number"
                                    placeholder="ទឹក"
                                    className="w-14 bg-white border border-stone-200 rounded px-1 py-0.5 text-[11px] font-bold text-blue-700 text-right outline-none focus:border-amber-500 font-mono"
                                    value={stats.customWaterRevenue ? Math.round(stats.customWaterRevenue * 4000) : ''}
                                    onChange={(e) => {
                                      const val = parseFloat(e.target.value) || 0;
                                      saveCustomMonthData(monthStr, 'waterRevenue', val / 4000);
                                      saveCustomMonthData(monthStr, 'useCustom', true);
                                    }}
                                  />
                                  <span className="text-[8px] text-stone-400 font-sans">ដើម (Base): {Math.round(stats.autoWaterRevenue * 4000).toLocaleString()}៛</span>
                                </div>
                              ) : (
                                <div className="flex flex-col items-end">
                                  <span className="font-bold text-blue-600">{Math.round(stats.waterRevenue * 4000).toLocaleString()}៛</span>
                                  <span className="text-[8px] text-stone-400">(${stats.waterRevenue.toFixed(1)})</span>
                                </div>
                              )}
                            </td>

                            {/* Wifi Revenue */}
                            <td className="p-2.5 text-right font-mono text-sky-600">
                              {isEditModeActive ? (
                                <div onClick={(e) => e.stopPropagation()} className="flex flex-col items-end gap-0.5">
                                  <input
                                    type="number"
                                    placeholder="វ៉ាយហ្វាយ"
                                    className="w-14 bg-white border border-stone-200 rounded px-1 py-0.5 text-[11px] font-bold text-sky-700 text-right outline-none focus:border-amber-500 font-mono"
                                    value={stats.customWifiRevenue || ''}
                                    onChange={(e) => {
                                      const val = parseFloat(e.target.value) || 0;
                                      saveCustomMonthData(monthStr, 'wifiRevenue', val);
                                      saveCustomMonthData(monthStr, 'useCustom', true);
                                    }}
                                  />
                                  <span className="text-[8px] text-stone-400 font-sans">ដើម (Base): ${stats.autoWifiRevenue.toFixed(0)}</span>
                                </div>
                              ) : (
                                <div className="flex flex-col items-end">
                                  <span className="font-bold text-sky-600">${stats.wifiRevenue.toFixed(1)}</span>
                                  <span className="text-[8px] text-stone-400">ដើម (Base): ${stats.autoWifiRevenue.toFixed(0)}</span>
                                </div>
                              )}
                            </td>

                            {/* Sovanna Salary */}
                            <td className="p-2.5 text-right font-mono text-amber-700 font-bold bg-amber-50/20">
                              ${stats.sovannaSalary.toFixed(1)}
                            </td>

                            {/* Pheak Salary */}
                            <td className="p-2.5 text-right font-mono text-sky-600 font-bold bg-sky-50/20">
                              ${stats.pheakSalary.toFixed(1)}
                            </td>

                            {/* Landlord Net Income */}
                            <td className="p-2.5 text-right font-black text-emerald-600 font-mono text-[13px] tabular-nums bg-emerald-50/20">
                              ${stats.landlordNet.toFixed(1)}
                            </td>
                          </tr>
                        );
                      })}
                      {/* Cumulative Row */}
                      <tr className="bg-stone-50 font-bold border-t-2 border-stone-300">
                        <td className="p-3 text-stone-800 font-black" colSpan={2}>សរុបប្រចាំឆ្នាំ (YEAR TOTAL)</td>
                        <td className="p-3 text-center font-mono font-black text-stone-800">
                          {[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).roomsCount, 0)} Rooms
                        </td>
                        <td className="p-3 text-right font-mono font-black text-stone-800">
                          ${yearlyTotalIncome.toFixed(1)}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-amber-800">
                          ${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).deposit, 0).toFixed(1)}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-amber-600">
                          ${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).electricityRevenue, 0).toFixed(1)}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-blue-600">
                          ${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).waterRevenue, 0).toFixed(1)}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-sky-600">
                          ${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).wifiRevenue, 0).toFixed(1)}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-amber-700 bg-amber-50/30">
                          ${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).sovannaSalary, 0).toFixed(1)}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-sky-700 bg-sky-50/30">
                          ${([1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).roomsCount, 0) * 15).toFixed(1)}
                        </td>
                        <td className="p-3 text-right font-black text-emerald-700 font-mono text-[14px] tabular-nums bg-emerald-50/30">
                          ${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).landlordNet, 0).toFixed(1)}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* INDIVIDUAL INCOME STATEMENT PAYSLIPS */}
              <div className="space-y-4 font-sans mb-8">
                <div className="bg-stone-50 border border-stone-200 rounded-lg p-3">
                  <h3 className="text-sm font-bold text-blue-900 uppercase flex items-center gap-1.5">
                    📋 វិក្កយបត្រចំណូលផ្ទាល់ខ្លួន / PERSONAL PAYSLIPS
                  </h3>
                  <p className="text-[11px] text-stone-500 mt-0.5 font-sans">
                    របាយការណ៍ហិរញ្ញវត្ថុ ប្រាក់ខែគ្រប់គ្រង និងការបែងចែកកម្រៃជើងសារប្រចាំខែសម្រាប់ Sovanna, Pheak និងម្ចាស់ផ្ទះ។ / Monthly financial report, management salary, and commission distribution for Sovanna, Pheak, and Landlord.
                  </p>
                </div>

                {selectedMonth === 'all' ? (
                  <div className="bg-stone-50/50 border border-dashed border-stone-200 rounded-xl p-8 text-center text-stone-400">
                    <Info className="w-8 h-8 mx-auto mb-2 text-stone-300" />
                    <p className="text-xs font-bold text-stone-600 font-sans">
                      សូមចុចប៊ូតុង "មើល (View)" នៅខែណាមួយក្នុងតារាងសង្ខេប ដើម្បីបង្ហាញរបាយការណ៍ចំណូលលម្អិតរបស់បុគ្គលម្នាក់ៗសម្រាប់ខែនោះ។ <br />
                      Please click the "View" button on any month in the summary table to display the detailed personal payslips for that month.
                    </p>
                  </div>
                ) : (() => {
                  const mIndex = parseInt(selectedMonth);
                  const stats = getMonthlyStats(mIndex);
                  
                  return (
                    <div className="space-y-5">
                      {/* Tabs Bar */}
                      <div className="flex flex-wrap gap-2 border-b border-stone-200 pb-2">
                        <button
                          type="button"
                          onClick={() => setActiveSlipTab('sovanna')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                            activeSlipTab === 'sovanna'
                              ? 'bg-amber-600 text-white shadow-sm'
                              : 'bg-stone-50 text-stone-600 hover:bg-stone-100'
                          }`}
                        >
                          <User className="w-3.5 h-3.5" />
                          វិក្កយបត្រ Sovanna (20% + ទឹកភ្លើង) / Sovanna Slip (20% + Utilities)
                        </button>
                        <button
                          type="button"
                          onClick={() => setActiveSlipTab('pheak')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                            activeSlipTab === 'pheak'
                              ? 'bg-sky-600 text-white shadow-sm'
                              : 'bg-stone-50 text-stone-600 hover:bg-stone-100'
                          }`}
                        >
                          <User className="w-3.5 h-3.5" />
                          វិក្កយបត្រ Pheak ({selectedMonth !== 'all' && parseInt(selectedMonth) >= 10 ? '$10' : '$15'}/បន្ទប់) / Pheak Slip ({selectedMonth !== 'all' && parseInt(selectedMonth) >= 10 ? '$10' : '$15'}/room)
                        </button>
                         <button
                          type="button"
                          onClick={() => setActiveSlipTab('landlord')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                            activeSlipTab === 'landlord'
                              ? 'bg-emerald-600 text-white shadow-sm'
                              : 'bg-stone-50 text-stone-600 hover:bg-stone-100'
                          }`}
                        >
                          <Home className="w-3.5 h-3.5" />
                          វិក្កយបត្រ ម្ចាស់ផ្ទះ (ចំណូលសុទ្ធ) / Landlord Slip (Net Revenue)
                        </button>
                        <button
                          type="button"
                          onClick={() => setActiveSlipTab('yearly')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                            activeSlipTab === 'yearly'
                              ? 'bg-violet-600 text-white shadow-sm'
                              : 'bg-stone-50 text-stone-600 hover:bg-stone-100'
                          }`}
                        >
                          <Database className="w-3.5 h-3.5" />
                          របាយការណ៍ប្រចាំឆ្នាំ (Annual Report)
                        </button>
                      </div>

                      {/* Download Button Area */}
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={() => {
                            const filename = activeSlipTab === 'yearly'
                              ? `Bao-Cao-Thu-Nhap-Ca-Nam-2026`
                              : `Payslip-Thang-${mIndex}-${activeSlipTab === 'sovanna' ? 'Sovanna' : activeSlipTab === 'pheak' ? 'Pheak' : 'Landlord'}`;
                            const ref = activeSlipTab === 'sovanna'
                              ? sovannaSlipRef
                              : activeSlipTab === 'pheak'
                                ? pheakSlipRef
                                : activeSlipTab === 'landlord'
                                  ? landlordSlipRef
                                  : yearlySlipRef;
                            handleDownloadSlip(ref, filename);
                          }}
                          disabled={isDownloading}
                          className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-lg hover:bg-emerald-700 shadow-md transition-all flex items-center gap-1.5"
                        >
                          {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                          ទាញយកប័ណ្ណទូទាត់រូបភាពកម្រិត 4K (Download 4K PNG Slip)
                        </button>
                      </div>

                      {/* SLIPS WRAPPERS */}
                      <div className="bg-stone-100 p-4 rounded-xl border border-stone-200 overflow-x-auto flex justify-center">
                        
                        {/* 1. SOVANNA SLIP */}
                        <div 
                          ref={sovannaSlipRef} 
                          className={`w-[600px] shrink-0 bg-white p-8 border-4 border-amber-600/60 shadow-lg relative rounded-sm ${activeSlipTab === 'sovanna' ? 'block' : 'hidden'}`}
                        >
                          {/* Khmer Decorative corners */}
                          <div className="absolute top-2 left-2 text-[10px] text-amber-600/30">✦</div>
                          <div className="absolute top-2 right-2 text-[10px] text-amber-600/30">✦</div>
                          <div className="absolute bottom-2 left-2 text-[10px] text-amber-600/30">✦</div>
                          <div className="absolute bottom-2 right-2 text-[10px] text-amber-600/30">✦</div>

                          <div className="text-center border-b-2 border-stone-200 pb-4 mb-4">
                            <h2 className="font-moul text-amber-800 text-base">សន្លឹកបើកប្រាក់បៀវត្សរ៍ប្រចាំខែ</h2>
                            <h3 className="font-sans font-bold text-stone-800 text-sm tracking-widest uppercase mt-0.5">MONTHLY SALARY STATEMENT (SOVANNA)</h3>
                            <p className="text-xs text-stone-500 font-sans mt-1">សម្រាប់៖ ខែ {mIndex} ឆ្នាំ 2026 / For: Month {mIndex} / 2026</p>
                          </div>

                          <div className="grid grid-cols-2 gap-4 text-xs font-sans mb-4 border-b border-stone-100 pb-4">
                            <div>
                              <p className="text-stone-500">អ្នកទទួល (Receiver): <span className="font-bold text-stone-800">SOVANNA</span></p>
                              <p className="text-stone-500 mt-1">តួនាទី (Role): <span className="font-bold text-stone-800">អ្នកទទួលបន្ទុកអគ្គិសនី ទឹក និង Wifi / Supervisor of Elec, Water & Wifi</span></p>
                            </div>
                            <div className="text-right">
                              <p className="text-stone-500">ម្ចាស់ផ្ទះ (Landlord): <span className="font-bold text-stone-800">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</span></p>
                              <p className="text-stone-500 mt-1">កាលបរិច្ឆេទ (Date): <span className="font-bold text-stone-800">2026-{selectedMonth}-05</span></p>
                            </div>
                          </div>

                          <table className="w-full text-left border-collapse border border-stone-300 text-xs font-sans mb-6">
                            <thead>
                              <tr className="bg-stone-50 border-b border-stone-300 text-stone-600 font-bold uppercase">
                                <th className="p-2">បរិយាយ (Description)</th>
                                <th className="p-2 text-right">ទឹកប្រាក់ (Amount)</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-200 text-stone-700">
                              <tr>
                                <td className="p-2 font-medium">២០% នៃថ្លៃជួលបន្ទប់ (20% Room Rental Share)</td>
                                <td className="p-2 text-right font-mono font-bold">${(stats.roomRevenue * 0.20).toFixed(2)}</td>
                              </tr>
                              <tr>
                                <td className="p-2 font-medium">ថ្លៃអគ្គិសនីប្រចាំខែ (100% Monthly Electricity Collected)</td>
                                <td className="p-2 text-right font-mono font-bold">${stats.electricityRevenue.toFixed(2)}</td>
                              </tr>
                              <tr>
                                <td className="p-2 font-medium">ថ្លៃទឹកស្អាតប្រចាំខែ (100% Monthly Water Collected)</td>
                                <td className="p-2 text-right font-mono font-bold">${stats.waterRevenue.toFixed(2)}</td>
                              </tr>
                              {stats.wifiRevenue > 0 && (
                                <tr>
                                  <td className="p-2 font-medium">ថ្លៃអ៊ីនធឺណិតប្រចាំខែ (100% Monthly Wi-Fi Collected)</td>
                                  <td className="p-2 text-right font-mono font-bold">${stats.wifiRevenue.toFixed(2)}</td>
                                </tr>
                              )}
                            </tbody>
                          </table>

                          <div className="flex justify-between items-center border-t-2 border-stone-800 pt-4 mb-8">
                            <span className="text-sm font-bold text-stone-800 uppercase">ប្រាក់បៀវត្សរ៍សរុប (Grand Total Payout)</span>
                            <span className="text-xl font-black text-amber-700 font-mono">${stats.sovannaSalary.toFixed(2)}</span>
                          </div>

                          <div className="grid grid-cols-2 gap-8 text-center text-xs font-sans mt-8 pt-8 border-t border-dashed border-stone-200">
                            <div>
                              <p className="text-stone-400">ហត្ថលេខាអ្នកទទួល (Receiver's Signature)</p>
                              <div className="h-12"></div>
                              <p className="font-bold text-stone-700">SOVANNA</p>
                            </div>
                            <div>
                              <p className="text-stone-400">អ្នករៀបចំ (Prepared By)</p>
                              <div className="h-12"></div>
                              <p className="font-bold text-stone-700">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</p>
                            </div>
                          </div>
                        </div>


                        {/* 2. PHEAK SLIP */}
                        <div 
                          ref={pheakSlipRef} 
                          className={`w-[600px] shrink-0 bg-white p-8 border-4 border-sky-600/60 shadow-lg relative rounded-sm ${activeSlipTab === 'pheak' ? 'block' : 'hidden'}`}
                        >
                          <div className="absolute top-2 left-2 text-[10px] text-sky-600/30">✦</div>
                          <div className="absolute top-2 right-2 text-[10px] text-sky-600/30">✦</div>
                          <div className="absolute bottom-2 left-2 text-[10px] text-sky-600/30">✦</div>
                          <div className="absolute bottom-2 right-2 text-[10px] text-sky-600/30">✦</div>

                          <div className="text-center border-b-2 border-stone-200 pb-4 mb-4">
                            <h2 className="font-moul text-sky-800 text-base">សន្លឹកបើកប្រាក់បៀវត្សរ៍ប្រចាំខែ</h2>
                            <h3 className="font-sans font-bold text-stone-800 text-sm tracking-widest uppercase mt-0.5">MONTHLY SALARY STATEMENT (PHEAK)</h3>
                            <p className="text-xs text-stone-500 font-sans mt-1">សម្រាប់៖ ខែ {mIndex} ឆ្នាំ 2026 / For: Month {mIndex} / 2026</p>
                          </div>

                          <div className="grid grid-cols-2 gap-4 text-xs font-sans mb-4 border-b border-stone-100 pb-4">
                            <div>
                              <p className="text-stone-500">អ្នកទទួល (Receiver): <span className="font-bold text-stone-800">PHEAK</span></p>
                              <p className="text-stone-500 mt-1">តួនាទី (Role): <span className="font-bold text-stone-800">អ្នកគ្រប់គ្រងបន្ទប់ (Manager)</span></p>
                            </div>
                            <div className="text-right">
                              <p className="text-stone-500">ម្ចាស់ផ្ទះ (Landlord): <span className="font-bold text-stone-800">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</span></p>
                              <p className="text-stone-500 mt-1">កាលបរិច្ឆេទ (Date): <span className="font-bold text-stone-800">2026-{selectedMonth}-05</span></p>
                            </div>
                          </div>

                          <table className="w-full text-left border-collapse border border-stone-300 text-xs font-sans mb-6">
                            <thead>
                              <tr className="bg-stone-50 border-b border-stone-300 text-stone-600 font-bold uppercase">
                                <th className="p-2">បរិយាយ (Description)</th>
                                <th className="p-2 text-center">ចំនួនបន្ទប់ (Quantity)</th>
                                <th className="p-2 text-right">តម្លៃឯកតា (Unit Rate)</th>
                                <th className="p-2 text-right">ទឹកប្រាក់ (Amount)</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-200 text-stone-700">
                              <tr>
                                <td className="p-2 font-medium">ថ្លៃគ្រប់គ្រងបន្ទប់ដែលបានជួល (Rented Room Management Fee)</td>
                                <td className="p-2 text-center font-mono">{stats.roomsCount} បន្ទប់ (Rooms)</td>
                                <td className="p-2 text-right font-mono">${mIndex >= 10 ? '10.00' : '15.00'}</td>
                                <td className="p-2 text-right font-mono font-bold">${stats.pheakSalary.toFixed(2)}</td>
                              </tr>
                            </tbody>
                          </table>

                          <div className="flex justify-between items-center border-t-2 border-stone-800 pt-4 mb-8">
                            <span className="text-sm font-bold text-stone-800 uppercase">ប្រាក់បៀវត្សរ៍សរុប (Grand Total Payout)</span>
                            <span className="text-xl font-black text-sky-700 font-mono">${stats.pheakSalary.toFixed(2)}</span>
                          </div>

                          <div className="grid grid-cols-2 gap-8 text-center text-xs font-sans mt-8 pt-8 border-t border-dashed border-stone-200">
                            <div>
                              <p className="text-stone-400">ហត្ថលេខាអ្នកទទួល (Receiver's Signature)</p>
                              <div className="h-12"></div>
                              <p className="font-bold text-stone-700">PHEAK</p>
                            </div>
                            <div>
                              <p className="text-stone-400">អ្នករៀបចំ (Prepared By)</p>
                              <div className="h-12"></div>
                              <p className="font-bold text-stone-700">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</p>
                            </div>
                          </div>
                        </div>


                        {/* 3. LANDLORD NET REVENUE SLIP */}
                        <div 
                          ref={landlordSlipRef} 
                          className={`w-[600px] shrink-0 bg-white p-8 border-4 border-emerald-600/60 shadow-lg relative rounded-sm ${activeSlipTab === 'landlord' ? 'block' : 'hidden'}`}
                        >
                          <div className="absolute top-2 left-2 text-[10px] text-emerald-600/30">✦</div>
                          <div className="absolute top-2 right-2 text-[10px] text-emerald-600/30">✦</div>
                          <div className="absolute bottom-2 left-2 text-[10px] text-emerald-600/30">✦</div>
                          <div className="absolute bottom-2 right-2 text-[10px] text-emerald-600/30">✦</div>

                          <div className="text-center border-b-2 border-stone-200 pb-4 mb-4">
                            <h2 className="font-moul text-emerald-800 text-base">របាយការណ៍ហិរញ្ញវត្ថុប្រចាំខែ</h2>
                            <h3 className="font-sans font-bold text-stone-800 text-sm tracking-widest uppercase mt-0.5">MONTHLY NET REVENUE REPORT (LANDLORD)</h3>
                            <p className="text-xs text-stone-500 font-sans mt-1">សម្រាប់៖ ខែ {mIndex} ឆ្នាំ 2026 / For: Month {mIndex} / 2026</p>
                          </div>

                          <div className="grid grid-cols-2 gap-4 text-xs font-sans mb-4 border-b border-stone-100 pb-4">
                            <div>
                              <p className="text-stone-500">អ្នកទទួលផល (Owner): <span className="font-bold text-stone-800">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</span></p>
                              <p className="text-stone-500 mt-1">ប្រភពផ្ទះជួល (Property): <span className="font-bold text-stone-800">បន្ទប់ជួលផ្ទះបឹងកេងកង</span></p>
                            </div>
                            <div className="text-right">
                              <p className="text-stone-500">បន្ទប់សរុប (Total Rooms): <span className="font-bold text-stone-800">{stats.roomsCount} / 12</span></p>
                              <p className="text-stone-500 mt-1">កាលបរិច្ឆេទ (Date): <span className="font-bold text-stone-800">2026-{selectedMonth}-05</span></p>
                            </div>
                          </div>

                          <table className="w-full text-left border-collapse border border-stone-300 text-xs font-sans mb-6">
                            <thead>
                              <tr className="bg-stone-50 border-b border-stone-300 text-stone-600 font-bold uppercase">
                                <th className="p-2">លម្អិតប្រតិបត្តិការ (Description)</th>
                                <th className="p-2 text-right">ទឹកប្រាក់ (Amount)</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-200 text-stone-700">
                              <tr>
                                <td className="p-2 font-medium">ចំណូលថ្លៃបន្ទប់សរុប (Total Room Rental Income Collected)</td>
                                <td className="p-2 text-right font-mono text-emerald-600 font-bold">+${stats.roomRevenue.toFixed(2)}</td>
                              </tr>
                              <tr>
                                <td className="p-2 font-medium text-amber-700">ដក៖ ភាគលាភ Sovanna ២០% (Less: Sovanna 20% room rental share)</td>
                                <td className="p-2 text-right font-mono text-amber-700">-${(stats.roomRevenue * 0.20).toFixed(2)}</td>
                              </tr>
                              <tr>
                                <td className="p-2 font-medium text-sky-700">ដក៖ ថ្លៃគ្រប់គ្រង Pheak ${mIndex >= 10 ? '១០' : '១៥'}/បន្ទប់ (Less: Pheak Room Management Fee - ${mIndex >= 10 ? '$10' : '$15'}/room)</td>
                                <td className="p-2 text-right font-mono text-sky-700">-${stats.pheakSalary.toFixed(2)}</td>
                              </tr>
                              <tr className="bg-stone-50/50">
                                <td className="p-2 font-bold text-stone-600 italic">សំគាល់៖ ប្រាក់កក់មិនគិតចូលចំណូល (Deposit Held - displayed only)</td>
                                <td className="p-2 text-right font-mono font-bold text-amber-900">${stats.deposit.toFixed(2)}</td>
                              </tr>
                            </tbody>
                          </table>

                          <div className="flex justify-between items-center border-t-2 border-stone-800 pt-4 mb-8">
                            <span className="text-sm font-bold text-stone-800 uppercase">ប្រាក់ចំណេញសុទ្ធ (Landlord Net Revenue)</span>
                            <span className="text-xl font-black text-emerald-600 font-mono">${stats.landlordNet.toFixed(2)}</span>
                          </div>

                          <div className="grid grid-cols-2 gap-8 text-center text-xs font-sans mt-8 pt-8 border-t border-dashed border-stone-200">
                            <div>
                              <p className="text-stone-400">ហត្ថលេខាម្ចាស់ផ្ទះ (Owner's Signature)</p>
                              <div className="h-12"></div>
                              <p className="font-bold text-stone-700">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</p>
                            </div>
                            <div>
                              <p className="text-stone-400">អ្នកពិនិត្យ (Audited By)</p>
                              <div className="h-12"></div>
                              <p className="font-bold text-stone-700">ងួន សុវណ្ណា</p>
                            </div>
                          </div>
                        </div>


                        {/* 4. YEARLY INCOME REPORT SLIP */}
                        <div 
                          ref={yearlySlipRef} 
                          className={`w-[600px] shrink-0 bg-white p-8 border-4 border-violet-600/60 shadow-lg relative rounded-sm ${activeSlipTab === 'yearly' ? 'block' : 'hidden'}`}
                        >
                          <div className="absolute top-2 left-2 text-[10px] text-violet-600/30">✦</div>
                          <div className="absolute top-2 right-2 text-[10px] text-violet-600/30">✦</div>
                          <div className="absolute bottom-2 left-2 text-[10px] text-violet-600/30">✦</div>
                          <div className="absolute bottom-2 right-2 text-[10px] text-violet-600/30">✦</div>

                          <div className="text-center border-b-2 border-stone-200 pb-4 mb-4">
                            <h2 className="font-moul text-violet-800 text-base">របាយការណ៍សង្ខេបចំណូលប្រចាំឆ្នាំ</h2>
                            <h3 className="font-sans font-bold text-stone-800 text-sm tracking-widest uppercase mt-0.5">ANNUAL SUMMARY INCOME STATEMENT (2026)</h3>
                            <p className="text-xs text-stone-500 font-sans mt-1">របាយការណ៍សរុបចំណូលទាំងមូលពេញមួយឆ្នាំ / Full Year Cumulative Earnings Report</p>
                          </div>

                          <div className="grid grid-cols-2 gap-4 text-xs font-sans mb-4 border-b border-stone-100 pb-4">
                            <div>
                              <p className="text-stone-500">ប្រភពផ្ទះជួល (Property): <span className="font-bold text-stone-800">បន្ទប់ជួលផ្ទះបឹងកេងកង</span></p>
                              <p className="text-stone-500 mt-1">កាលបរិច្ឆេទរបាយការណ៍ (Date): <span className="font-bold text-stone-800">{statementDate ? statementDate.split('-').reverse().join('-') : ''}</span></p>
                            </div>
                            <div className="text-right">
                              <p className="text-stone-500">ម្ចាស់ផ្ទះ (Landlord): <span className="font-bold text-stone-800">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</span></p>
                              <p className="text-stone-500 mt-1">ចំនួនខែទូទាត់ (Months tracked): <span className="font-bold text-stone-800">12 ខែ (12 Months)</span></p>
                            </div>
                          </div>

                          <table className="w-full text-left border-collapse border border-stone-300 text-xs font-sans mb-6">
                            <thead>
                              <tr className="bg-stone-50 border-b border-stone-300 text-stone-600 font-bold uppercase">
                                <th className="p-2">សមាជិក (Person / Role)</th>
                                <th className="p-2">លម្អិតប្រភពចំណូល (Income Sources)</th>
                                <th className="p-2 text-right">ប្រាក់ចំណូលសរុប (Total Revenue)</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-200 text-stone-700">
                              {/* Sovanna */}
                              <tr>
                                <td className="p-2 font-bold text-amber-800 bg-amber-50/10">SOVANNA<br/><span className="text-[9px] font-normal text-stone-500">អ្នកទទួលខុសត្រូវ (Supervisor)</span></td>
                                <td className="p-2 text-stone-600">
                                  • ២០% នៃថ្លៃបន្ទប់សរុប (20% Room Share: <span className="font-mono">${([1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).roomRevenue * 0.20, 0)).toFixed(2)}</span>)<br/>
                                  • ១០០% ថ្លៃទឹក អគ្គិសនី វ៉ាយហ្វាយ (100% Utilities & Wifi: <span className="font-mono">${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => {
                                    const stats = getMonthlyStats(m);
                                    return sum + stats.electricityRevenue + stats.waterRevenue + stats.wifiRevenue;
                                  }, 0).toFixed(2)}</span>)
                                </td>
                                <td className="p-2 text-right font-mono font-bold text-amber-600 bg-amber-50/10 text-sm">
                                  ${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).sovannaSalary, 0).toFixed(2)}
                                </td>
                              </tr>

                              {/* Pheak */}
                              <tr>
                                <td className="p-2 font-bold text-sky-800 bg-sky-50/10">PHEAK<br/><span className="text-[9px] font-normal text-stone-500">អ្នកគ្រប់គ្រង (Manager)</span></td>
                                <td className="p-2 text-stone-600">
                                  • $15 ក្នុងមួយបន្ទប់ (ខែ ១-៩) និង $10 (ខែ ១០-១២) ជួលបានសរុប ($15/room for Months 1-9, $10/room for Months 10-12 for all { [1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).roomsCount, 0) } rooms rented throughout the year)
                                </td>
                                <td className="p-2 text-right font-mono font-bold text-sky-600 bg-sky-50/10 text-sm">
                                  ${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).pheakSalary, 0).toFixed(2)}
                                </td>
                              </tr>

                              {/* Landlord */}
                              <tr>
                                <td className="p-2 font-bold text-emerald-800 bg-emerald-50/10">LANDLORD<br/><span className="text-[9px] font-normal text-stone-500">ម្ចាស់ផ្ទះ សាង សុវណ្ណារតនៈ (Owner)</span></td>
                                <td className="p-2 text-stone-600">
                                  • ៨០% ថ្លៃបន្ទប់សរុបដកថ្លៃ Pheak (Remaining Room Rent after paying commissions: Room Revenue <span className="font-mono">${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).roomRevenue, 0).toFixed(2)}</span> - Sovanna Share - Pheak Share)
                                </td>
                                <td className="p-2 text-right font-mono font-bold text-emerald-600 bg-emerald-50/10 text-sm">
                                  ${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).landlordNet, 0).toFixed(2)}
                                </td>
                              </tr>
                            </tbody>
                          </table>

                          <div className="bg-stone-50 p-3 rounded border border-stone-200 mb-6 flex justify-between items-center text-xs font-bold text-stone-700">
                            <span>សរុបចំណូលរួមទូទាំងឆ្នាំ (Combined Annual Revenue Collected):</span>
                            <span className="font-mono text-stone-900 text-sm">${[1,2,3,4,5,6,7,8,9,10,11,12].reduce((sum, m) => sum + getMonthlyStats(m).totalUsd, 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                          </div>

                          <div className="grid grid-cols-2 gap-8 text-center text-xs font-sans mt-8 pt-8 border-t border-dashed border-stone-200">
                            <div>
                              <p className="text-stone-400">ហត្ថលេខាម្ចាស់ផ្ទះ (Owner's Signature)</p>
                              <div className="h-12"></div>
                              <p className="font-bold text-stone-700">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</p>
                            </div>
                            <div>
                              <p className="text-stone-400">អ្នកពិនិត្យ (Audited By)</p>
                              <div className="h-12"></div>
                              <p className="font-bold text-stone-700">ងួន សុវណ្ណា</p>
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* List of Rented Guests with Cumulative Payments (REQUESTED) */}
              <div className="space-y-4 font-sans mb-8">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-stone-50 border border-stone-200 rounded-lg p-3">
                  <div>
                    <h3 className="text-sm font-bold text-blue-900 uppercase flex items-center gap-1.5">
                      👥 បញ្ជីចំណូលសរុបតាមភ្ញៀវម្នាក់ៗ (TOTAL REVENUE BY TENANT)
                    </h3>
                    <p className="text-[11px] text-stone-500 mt-0.5 font-sans">តារាងសង្ខេបទឹកប្រាក់បង់សរុបលម្អិតរបស់ភ្ញៀវម្នាក់ៗ / Summary table of accumulated payments made by each tenant room.</p>
                  </div>
                  <div className="text-xs bg-white border border-stone-200 rounded px-3 py-1.5 flex items-center gap-3 font-sans">
                    <span className="font-bold text-stone-700">បានបង់ប្រាក់ខែតុលា (Paid for October):</span>
                    <span className="font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded text-xs font-mono">
                      {savedTenants.filter(t => t.isPaid).length} / {savedTenants.length} បន្ទប់ (Rooms)
                    </span>
                  </div>
                </div>
                
                <div className="overflow-x-auto border border-stone-200 rounded-lg shadow-sm">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase text-[10px] font-bold">
                        <th className="p-3">បន្ទប់ (Room)</th>
                        <th className="p-3">ភ្ញៀវជួល (Tenant Name)</th>
                        <th className="p-3">ថ្ងៃចូលស្នាក់នៅ (Check-In)</th>
                        <th className="p-3 text-right">តម្លៃបន្ទប់ដើម (Base Room Rent)</th>
                        <th className="p-3 text-right text-amber-800">ប្រាក់កក់ (Security Deposit)</th>
                        <th className="p-3 text-center font-sans">វិក្កយបត្រដែលបានប្រមូល (Invoices Collected)</th>
                        <th className="p-3 text-right font-bold text-emerald-700 font-sans">ចំណូលសរុបដែលបានទទួល (Total Accumulated Revenue)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {sortedSavedTenants.map((tenant) => {
                        const tenantRecords = history.filter(h => h.tenantName.toLowerCase().trim() === tenant.tenantName.toLowerCase().trim() || h.roomNo === tenant.roomNo);
                        const totalPaid = tenantRecords.reduce((sum, r) => sum + r.totalUsd, 0);
                        const isSelected = selectedYearlyTenant === tenant.roomNo;
                        
                        return (
                          <tr 
                            key={tenant.tenantName} 
                            onClick={() => setSelectedYearlyTenant(tenant.roomNo)}
                            className={`hover:bg-emerald-50/40 cursor-pointer transition-all duration-150 ${isSelected ? 'bg-emerald-50/70 border-l-4 border-l-emerald-600 font-semibold' : ''}`}
                          >
                            <td className="p-3 font-bold text-stone-800">
                              <span className="text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded text-[11px] font-black font-sans">
                                P.{tenant.roomNo}
                              </span>
                            </td>
                            <td className="p-3">
                              <div className="flex items-center gap-2">
                                <div>
                                  <p className="font-moul text-[11px] text-blue-900 leading-tight">{tenant.tenantName}</p>
                                  {tenant.tenantPhone && <p className="text-[10px] text-stone-400 mt-0.5">{tenant.tenantPhone}</p>}
                                </div>
                                {isSelected && (
                                  <span className="text-[9px] bg-emerald-500 text-white font-bold font-sans px-1.5 py-0.5 rounded scale-90 uppercase tracking-wider">សកម្ម (Active)</span>
                                )}
                              </div>
                            </td>
                            <td className="p-3 text-stone-500 font-sans">{tenant.checkInDate || '—'}</td>
                            <td className="p-3 text-right font-sans">
                              <p className="font-medium text-stone-700">${tenant.roomPrice}/ខែ (Month)</p>
                              {tenant.wifiPrice > 0 && <p className="text-[10px] text-stone-400 mt-0.5">Wifi: ${tenant.wifiPrice}</p>}
                            </td>
                            <td className="p-3 text-right font-mono font-bold text-amber-700">
                              {tenant.deposit !== undefined ? `$${tenant.deposit.toFixed(2)}` : '$0.00'}
                            </td>
                            <td className="p-3 text-center font-sans">
                              <span className="px-2 py-0.5 rounded bg-stone-100 text-[10px] font-bold text-stone-600 font-sans">
                                {tenantRecords.length} ប្រតិបត្តិការ (Transactions)
                              </span>
                            </td>
                            <td className="p-3 text-right font-black text-emerald-600 font-mono text-[13px] tabular-nums">
                              <div className="flex items-center justify-end gap-2.5">
                                <span>${totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedYearlyTenant(tenant.roomNo);
                                  }}
                                  className={`px-2 py-1 rounded text-[9px] font-bold uppercase tracking-wider font-sans shadow-sm transition-all ${
                                    isSelected 
                                      ? 'bg-emerald-600 text-white hover:bg-emerald-700' 
                                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                                  }`}
                                >
                                  មើល (View)
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* DYNAMIC CUMULATIVE TRACKING & 12-MONTH INPUT MATRIX SECTION (REQUESTED) */}
                <div className="mt-6 border border-stone-200 rounded-xl overflow-hidden shadow-sm bg-white font-sans">
                  {/* Selector Header Sub-tabs */}
                  <div className="flex items-center justify-between border-b border-stone-200 bg-stone-50 p-1">
                    <div className="flex gap-1">
                      <button
                        type="button"
                        onClick={() => setYearlyViewTab('individual')}
                        className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                          yearlyViewTab === 'individual'
                            ? 'bg-emerald-600 text-white shadow-sm'
                            : 'text-stone-600 hover:bg-stone-100'
                        }`}
                      >
                        <User className="w-4 h-4" />
                        របាយការណ៍ម្នាក់ៗ (Individual Report)
                      </button>
                      <button
                        type="button"
                        onClick={() => setYearlyViewTab('matrix')}
                        className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                          yearlyViewTab === 'matrix'
                            ? 'bg-violet-600 text-white shadow-sm'
                            : 'text-stone-600 hover:bg-stone-100'
                        }`}
                      >
                        <BarChart3 className="w-4 h-4" />
                        ម៉ាទ្រីស ១២ខែ (12-Month Matrix)
                      </button>
                    </div>
                    <div className="text-[10px] text-stone-400 font-mono px-3">
                      * ស្ថិតិតាមដានពេញមួយឆ្នាំ ២០២៦ / Full Year 2026 Tracking
                    </div>
                  </div>

                  {/* Panel Contents */}
                  <div className="p-5 bg-white">
                    {yearlyViewTab === 'individual' ? (
                      (() => {
                        const selectedTenantData = savedTenants.find(t => t.roomNo === selectedYearlyTenant) || savedTenants[0];
                        const selectedTenantName = selectedTenantData ? selectedTenantData.tenantName : '';
                        
                        const getMonthFromPaymentDate = (dateStr: string) => {
                          if (!dateStr) return '';
                          const parts = dateStr.split('-');
                          return parts[1] || '';
                        };

                        const selectedTenantHistory = history.filter(h => 
                          h.roomNo === selectedYearlyTenant || 
                          h.tenantName.toLowerCase().trim() === selectedTenantName.toLowerCase().trim()
                        );
                        const selectedTenantYearTotal = selectedTenantHistory.reduce((sum, r) => sum + r.totalUsd, 0);

                        return (
                          <div className="space-y-4">
                            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-stone-100 pb-3">
                              <div>
                                <h4 className="text-sm font-black text-emerald-800 uppercase tracking-wide flex items-center gap-1.5 font-moul leading-normal">
                                  📊 តារាងលម្អិតការបង់ប្រាក់ប្រចាំខែ - បន្ទប់ {selectedYearlyTenant} ({selectedTenantName})
                                </h4>
                                <p className="text-[11px] text-stone-500">ការតាមដានការទូទាត់ប្រចាំខែតាមជួរឈរនីមួយៗក្នុងឆ្នាំ ២០២៦ / Monthly payment details for the selected room in 2026.</p>
                              </div>
                              <div className="bg-emerald-50 border border-emerald-200 rounded px-3 py-1.5 text-xs font-bold flex items-center gap-2">
                                <span className="text-emerald-800">សរុបប្រចាំឆ្នាំ (Yearly Accumulated):</span>
                                <span className="text-emerald-700 font-mono text-sm font-black">${selectedTenantYearTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                              </div>
                            </div>

                            <div className="overflow-x-auto border border-stone-100 rounded-lg">
                              <table className="w-full text-left border-collapse text-xs">
                                <thead>
                                  <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase text-[10px] font-bold">
                                    <th className="p-2.5 font-sans">ខែ (Month)</th>
                                    <th className="p-2.5 text-center font-sans">ស្ថានភាព (Status)</th>
                                    <th className="p-2.5 font-sans">កាលបរិច្ឆេទ (Payment Date)</th>
                                    <th className="p-2.5 text-right font-sans">ថ្លៃបន្ទប់ (Room Price)</th>
                                    <th className="p-2.5 text-right font-sans">ទឹកភ្លើង (Utilities)</th>
                                    <th className="p-2.5 text-right font-sans">វ៉ាយហ្វាយ (Wifi / Other)</th>
                                    <th className="p-2.5 text-right font-bold text-emerald-800 font-sans">សរុប (Total Amount)</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-stone-100 font-sans text-stone-700 bg-white">
                                  {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((mIndex) => {
                                    const mRecord = history.find(h => 
                                      (h.roomNo === selectedYearlyTenant || h.tenantName.toLowerCase().trim() === selectedTenantName.toLowerCase().trim()) && 
                                      getMonthFromPaymentDate(h.paymentDate) === mIndex
                                    );

                                    return (
                                      <tr key={mIndex} className="hover:bg-stone-50/50 transition-colors">
                                        <td className="p-2.5 font-bold font-mono">ខែ {parseInt(mIndex)} / Month {parseInt(mIndex)}</td>
                                        <td className="p-2.5 text-center">
                                          {mRecord ? (
                                            <span className="px-2.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-100 text-[10px] font-black uppercase tracking-wider">បង់រួច (PAID)</span>
                                          ) : (
                                            <span className="px-2.5 py-0.5 rounded bg-stone-50 text-stone-400 border border-stone-100 text-[10px] font-medium uppercase">គ្មានទិន្នន័យ (PENDING)</span>
                                          )}
                                        </td>
                                        <td className="p-2.5 text-stone-500 font-mono">{mRecord ? mRecord.paymentDate : '—'}</td>
                                        <td className="p-2.5 text-right font-mono text-stone-600">{mRecord ? `$${mRecord.roomPrice.toFixed(2)}` : '—'}</td>
                                        <td className="p-2.5 text-right font-mono text-stone-600">{mRecord ? `$${(mRecord.elecPrice + mRecord.waterPrice).toFixed(2)}` : '—'}</td>
                                        <td className="p-2.5 text-right font-mono text-stone-600">{mRecord ? `$${(mRecord.wifiPrice + mRecord.otherPrice).toFixed(2)}` : '—'}</td>
                                        <td className="p-2.5 text-right font-black text-emerald-600 font-mono text-sm">
                                          {mRecord ? `$${mRecord.totalUsd.toFixed(2)}` : '—'}
                                        </td>
                                      </tr>
                                    );
                                  })}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        );
                      })()
                    ) : (
                      <div className="space-y-4">
                        <div className="border-b border-stone-100 pb-3">
                          <h4 className="text-sm font-black text-violet-800 uppercase tracking-wide flex items-center gap-1.5 font-moul leading-normal">
                            📊 ម៉ាទ្រីសចំណូលសរុបប្រចាំឆ្នាំតាមបន្ទប់ (12-MONTH ROOM REVENUE MATRIX)
                          </h4>
                          <p className="text-[11px] text-stone-500">តារាងសរុបចំណូលតាមខែនីមួយៗរបស់បន្ទប់ទាំងអស់ក្នុងឆ្នាំ ២០២៦ / Aggregate 12-month revenue matrix for all rooms.</p>
                        </div>

                        <div className="overflow-x-auto border border-stone-100 rounded-lg">
                          <table className="w-full text-center border-collapse text-[10px] font-sans">
                            <thead>
                              <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase font-bold">
                                <th className="p-2.5 text-left">បន្ទប់ (Room)</th>
                                <th className="p-2.5 text-left">ឈ្មោះ (Guest)</th>
                                {["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"].map(m => (
                                  <th key={m} className="p-1.5 font-mono">Th{m}</th>
                                ))}
                                <th className="p-2.5 text-right text-emerald-800 font-bold">សរុប (Total)</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-100 bg-white text-stone-700">
                              {sortedSavedTenants.map((tenant) => {
                                const tenantRecords = history.filter(h => h.roomNo === tenant.roomNo || h.tenantName.toLowerCase().trim() === tenant.tenantName.toLowerCase().trim());
                                const rowTotal = tenantRecords.reduce((sum, r) => sum + r.totalUsd, 0);

                                const getMonthFromPaymentDate = (dateStr: string) => {
                                  if (!dateStr) return '';
                                  const parts = dateStr.split('-');
                                  return parts[1] || '';
                                };

                                return (
                                  <tr key={tenant.roomNo} className="hover:bg-stone-50/50 transition-colors">
                                    <td className="p-2.5 text-left font-bold font-sans text-stone-900 bg-stone-50/30">P.{tenant.roomNo}</td>
                                    <td className="p-2.5 text-left font-moul text-[10px] truncate max-w-[90px] text-blue-950" title={tenant.tenantName}>{tenant.tenantName}</td>
                                    {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((mIndex) => {
                                      const mRecord = tenantRecords.find(h => getMonthFromPaymentDate(h.paymentDate) === mIndex);
                                      return (
                                        <td key={mIndex} className="p-1.5 font-mono">
                                          {mRecord ? (
                                            <span className="text-emerald-600 font-bold" title={`Transaction: $${mRecord.totalUsd.toFixed(2)} on ${mRecord.paymentDate}`}>${mRecord.totalUsd.toFixed(0)}</span>
                                          ) : (
                                            <span className="text-stone-300 font-normal">—</span>
                                          )}
                                        </td>
                                      );
                                    })}
                                    <td className="p-2.5 text-right font-black text-emerald-600 font-mono text-[11px] bg-emerald-50/20">
                                      ${rowTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Detailed Payment History Ledger */}
              <div className="space-y-4 font-sans">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-stone-800 flex items-center gap-1.5 mb-1 text-blue-900 uppercase">
                      📜 សៀវភៅបញ្ជីប្រវត្តិប្រតិបត្តិការលម្អិត (DETAILED TRANSACTION LEDGER • {history.length})
                    </h3>
                    <p className="text-xs text-stone-500">ប្រវត្តិទូទាត់លម្អិតរាល់ការបង់ប្រាក់ថ្លៃបន្ទប់ និងប្រតិបត្តិការដោយដៃ / Detailed payment history ledger of room rentals and manual entries.</p>
                  </div>
                  
                  <div className="relative w-full sm:w-64">
                    <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-stone-400 font-sans" />
                    <input
                      type="text"
                      placeholder="Search room, tenant, date..."
                      className="w-full bg-stone-50 border border-stone-200 rounded pl-8 pr-3 py-1.5 text-xs outline-none focus:bg-white focus:border-emerald-500 transition-all text-stone-800 font-sans"
                      value={adminSearchQuery}
                      onChange={(e) => setAdminSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="overflow-x-auto border border-stone-200 rounded-lg shadow-sm">
                  <table className="w-full text-left border-collapse text-xs font-sans">
                    <thead>
                      <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase text-[10px] font-bold">
                        <th className="p-3">កាលបរិច្ឆេទ (Date)</th>
                        <th className="p-3 font-sans">បន្ទប់ (Room)</th>
                        <th className="p-3">ឈ្មោះអ្នកជួល (Tenant)</th>
                        <th className="p-3 text-right">ថ្លៃបន្ទប់ (Room Price)</th>
                        <th className="p-3 text-right">ទឹកភ្លើង (Utilities)</th>
                        <th className="p-3 text-right">វ៉ាយហ្វាយ/ផ្សេងៗ (Wifi/Other)</th>
                        <th className="p-3 text-right font-bold text-indigo-700">ប្រាក់សរុប (Paid Amount)</th>
                        <th className="p-3 text-center">សកម្មភាព (Actions)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {history.filter(h => 
                        h.tenantName.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                        h.roomNo.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                        h.paymentDate.includes(adminSearchQuery)
                      ).length === 0 ? (
                        <tr>
                          <td colSpan={8} className="p-8 text-center text-stone-400">គ្មានទិន្នន័យទូទាត់សមស្របត្រូវបានរកឃើញទេ / No matching transaction records found.</td>
                        </tr>
                      ) : (
                        history.filter(h => 
                          h.tenantName.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                          h.roomNo.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                          h.paymentDate.includes(adminSearchQuery)
                        ).map((record) => (
                          <tr key={record.id} className="hover:bg-stone-50/50 transition-colors">
                            <td className="p-3 text-stone-600 font-mono text-[11px] whitespace-nowrap">{record.paymentDate}</td>
                            <td className="p-3 font-bold text-stone-800">
                              <span className="text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded text-[10px] font-black font-sans">
                                P.{record.roomNo}
                              </span>
                            </td>
                            <td className="p-3 font-moul text-[11px] text-blue-900 leading-tight">{record.tenantName}</td>
                            <td className="p-3 text-right font-mono text-stone-600">${record.roomPrice.toFixed(2)}</td>
                            <td className="p-3 text-right font-mono text-stone-600">
                              ${(record.elecPrice + record.waterPrice).toFixed(2)}
                              {(record.elecUsage > 0 || record.waterUsage > 0) && (
                                <p className="text-[9px] text-stone-400 font-sans mt-0.5">
                                  {record.elecUsage > 0 ? `${record.elecUsage}KWH` : ''} {record.waterUsage > 0 ? `/ ${record.waterUsage}M³` : ''}
                                </p>
                              )}
                            </td>
                            <td className="p-3 text-right font-mono text-stone-600">${(record.wifiPrice + record.otherPrice).toFixed(2)}</td>
                            <td className="p-3 text-right font-black text-indigo-600 font-mono text-[12px] tabular-nums">
                              ${record.totalUsd.toFixed(2)}
                            </td>
                            <td className="p-3 text-center">
                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(`តើអ្នកប្រាកដជាចង់លុបប្រតិបត្តិការបន្ទប់ P.${record.roomNo} ថ្ងៃទី ${record.paymentDate} នេះឬទេ? / Are you sure you want to delete room P.${record.roomNo} transaction dated ${record.paymentDate}?`)) {
                                    handleDeleteHistory(record.id);
                                  }
                                }}
                                className="p-1 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded transition-all inline-flex"
                                title="លុបប្រតិបត្តិការ (Delete Transaction)"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}

          {/* Tenants Tab Screen */}
          {activeTab === 'tenants' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full bg-white shadow-2xl rounded-xl overflow-hidden p-6 sm:p-8 border border-stone-200 font-sans"
            >
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-stone-200 pb-4 mb-6">
                <div>
                  <h2 className="text-xl font-bold text-stone-800 flex items-center gap-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    សៀវភៅគ្រប់គ្រងអ្នកជួលបន្ទប់ (Tenants & Rooms Directory)
                  </h2>
                  <p className="text-xs text-stone-500 mt-1">
                    គ្រប់គ្រងព័ត៌មានលម្អិតរបស់បន្ទប់នីមួយៗ និងស្ថានភាពបង់ប្រាក់។<br/>
                    <span className="text-stone-400">Manage room details, rental pricing, utility starting numbers, and monthly payment status.</span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddForm(true);
                    formRef.current?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2 px-3 rounded shadow-sm transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  បន្ថែមបន្ទប់ថ្មី (Add Room)
                </button>
              </div>

              {/* Tenants Grid list */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sortedSavedTenants.map((tenant) => {
                  const isCurrent = data.roomNo === tenant.roomNo;
                  return (
                    <div 
                      key={tenant.tenantName}
                      className={`p-5 rounded-xl border relative transition-all shadow-sm ${
                        isCurrent 
                          ? 'border-blue-500 bg-blue-50/10 shadow-blue-50/20' 
                          : 'border-stone-200 bg-stone-50/30 hover:border-blue-300'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          <span className="text-lg font-black text-blue-900 bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-lg font-sans">
                            P.{tenant.roomNo}
                          </span>
                          <div>
                            <h4 className="font-moul text-sm text-blue-900 leading-normal">{tenant.tenantName}</h4>
                            <p className="text-[10px] text-stone-400 mt-0.5 font-sans">កាលបរិច្ឆេទចូល (Check-in): {tenant.checkInDate || '—'}</p>
                          </div>
                        </div>

                        {/* Payment Pill */}
                        <button
                          type="button"
                          onClick={() => handleTogglePaidStatus(tenant.roomNo)}
                          className={`px-2.5 py-1 rounded-full text-xs font-bold border transition-all flex items-center gap-1.5 ${
                            tenant.isPaid 
                              ? 'bg-emerald-100 border-emerald-200 text-emerald-800' 
                              : 'bg-amber-50 border-amber-100 text-amber-700 hover:bg-amber-100'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${tenant.isPaid ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
                          {tenant.isPaid ? 'បានប្រមូល (Paid)' : 'មិនទាន់ប្រមូល (Unpaid)'}
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 mt-4 text-xs text-stone-600 border-t border-stone-100 pt-3 font-sans">
                        <p>ថ្លៃបន្ទប់ (Room Price): <span className="font-bold text-stone-800">${tenant.roomPrice}</span></p>
                        <p>វ៉ាយហ្វាយ (Wi-Fi): <span className="font-bold text-stone-800">${tenant.wifiPrice}</span></p>
                        <p>ភ្លើងចាស់ (Old Elec): <span className="font-bold text-stone-800">{tenant.elecOld || '0'} KWH</span></p>
                        <p>ទឹកចាស់ (Old Water): <span className="font-bold text-stone-800">{tenant.waterOld || '0'} M³</span></p>
                        {tenant.deposit !== undefined && (
                          <p className="col-span-2 text-stone-700 font-medium">
                            ប្រាក់កក់ (Deposit): <span className="font-extrabold text-amber-700 font-mono">${tenant.deposit}</span>
                          </p>
                        )}
                        {tenant.tenantPhone && (
                          <p className="col-span-2 text-stone-500 flex items-center gap-1 mt-1 text-[11px]">
                            <span>📞 លេខទូរស័ព្ទ (Phone):</span>
                            <span className="font-bold text-stone-700">{tenant.tenantPhone}</span>
                          </p>
                        )}
                        {tenant.tenantIdNo && (
                          <p className="col-span-2 text-stone-500 flex items-center gap-1 text-[11px]">
                            <span>🪪 ID Card:</span>
                            <span className="font-medium text-stone-700">{tenant.tenantIdNo}</span>
                          </p>
                        )}
                      </div>

                      {/* Room Footer Action Buttons */}
                      <div className="flex gap-2 mt-4 pt-3 border-t border-stone-100">
                        <button
                          type="button"
                          onClick={() => {
                            handleSelectTenant(tenant);
                            setActiveTab('invoice');
                          }}
                          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-1.5 px-3 rounded-lg text-xs transition-colors shadow-sm flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <CreditCard className="w-3.5 h-3.5" />
                          បង្កើតវិក្កយបត្រ (Use Tenant)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            handleStartEditTenant(tenant);
                            setShowAddForm(true);
                          }}
                          className="bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold py-1.5 px-3 rounded-lg text-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Edit className="w-3.5 h-3.5" />
                          កែសម្រួល (Edit)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`តើអ្នកប្រាកដជាចង់លុបបន្ទប់ P.${tenant.roomNo} (${tenant.tenantName}) នេះឬទេ? / Are you sure you want to delete room P.${tenant.roomNo} (${tenant.tenantName})?`)) {
                              handleDeleteTenant(tenant.tenantName);
                            }
                          }}
                          className="bg-red-50 hover:bg-red-100 text-red-600 font-bold py-1.5 px-2.5 rounded-lg text-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                          title="លុບບន្ទប់ (Delete Room)"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Manual Input Tab Screen */}
          {activeTab === 'manualForm' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full bg-white shadow-2xl rounded-xl overflow-hidden p-6 sm:p-8 border border-stone-200 font-sans"
            >
              {/* Header */}
              <div id="input-form-title" className="border-b border-stone-200 pb-4 mb-6">
                <h2 className="text-xl font-bold text-stone-800 flex items-center gap-2">
                  <Edit className="w-5 h-5 text-amber-600" />
                  {editingRecordId ? '✍️ របៀបកែសម្រួលទិន្នន័យរបស់ភ្ញៀវ (EDIT MONTHLY LEDGER RECORDS)' : '✍️ បញ្ចូលទិន្នន័យរបស់ភ្ញៀវប្រចាំខែ (RECORD NEW MONTHLY INPUTS)'}
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  បញ្ចូល ធ្វើបច្ចុប្បន្នភាព ឬលុបទិន្នន័យចំណូលលម្អិតរបស់ភ្ញៀវម្នាក់ៗតាមខែ។<br/>
                  <span className="text-stone-400">Add, edit, delete, and check monthly ledger input figures for each tenant room.</span>
                </p>
              </div>

              {/* Form & Checker Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-8">
                
                {/* FORM LEFT: 7 Cols */}
                <form 
                  onSubmit={handleSaveCustomerMonthlyInput} 
                  className="lg:col-span-7 bg-stone-50 border border-stone-200 rounded-xl p-5 md:p-6 space-y-4 shadow-sm"
                >
                  <div className="flex justify-between items-center border-b border-stone-200 pb-2">
                    <span className="text-xs font-black text-stone-700 uppercase tracking-widest">
                      {editingRecordId ? '📝 កែសម្រួលកំណត់ត្រា (EDIT MODE ACTIVE)' : '✨ បញ្ចូលកំណត់ត្រាថ្មី (RECORD NEW INPUT)'}
                    </span>
                    {editingRecordId && (
                      <button 
                        type="button" 
                        onClick={() => {
                          setEditingRecordId(null);
                          setInputElecPrice(0);
                          setInputWaterPrice(0);
                          setInputOtherPrice(0);
                        }} 
                        className="text-red-500 hover:text-red-700 text-[10px] font-bold uppercase"
                      >
                        បោះបង់ការកែ (Cancel Edit)
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                    {/* Room Selector */}
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">បន្ទប់ស្នាក់នៅ (Select Room) *</label>
                      <select
                        required
                        className="w-full bg-white border border-stone-300 rounded-lg p-2.5 font-bold text-stone-800 outline-none focus:border-emerald-500 text-sm shadow-sm font-sans"
                        value={inputRoomNo}
                        onChange={(e) => {
                          const rNo = e.target.value;
                          setInputRoomNo(rNo);
                          const tData = savedTenants.find(t => t.roomNo === rNo);
                          if (tData) {
                            setInputTenantName(tData.tenantName);
                            setInputRoomPrice(tData.roomPrice);
                            setInputWifiPrice(tData.wifiPrice);
                          }
                        }}
                      >
                        {sortedSavedTenants.map(t => (
                          <option key={t.roomNo} value={t.roomNo}>បន្ទប់ (Room) {t.roomNo} ({t.tenantName})</option>
                        ))}
                      </select>
                    </div>

                    {/* Tenant Name */}
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ឈ្មោះភ្ញៀវ (Guest Name) *</label>
                      <input
                        type="text"
                        required
                        className="w-full bg-white border border-stone-300 rounded-lg p-2.5 font-bold text-stone-800 outline-none focus:border-emerald-500 text-sm shadow-sm"
                        value={inputTenantName}
                        onChange={(e) => setInputTenantName(e.target.value)}
                      />
                    </div>

                    {/* Target Month */}
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ខែបញ្ចូល (Select Month) *</label>
                      <select
                        required
                        className="w-full bg-white border border-stone-300 rounded-lg p-2.5 font-bold text-stone-800 outline-none focus:border-emerald-500 text-sm shadow-sm font-sans"
                        value={inputMonth}
                        onChange={(e) => setInputMonth(e.target.value)}
                      >
                        {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((m) => (
                          <option key={m} value={m}>ខែ {parseInt(m)} (Month {parseInt(m)})</option>
                        ))}
                      </select>
                    </div>

                    {/* Payment Date */}
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">កាលបរិច្ឆេទបង់ (Payment Date) *</label>
                      <input
                        type="date"
                        required
                        className="w-full bg-white border border-stone-300 rounded-lg p-2.5 font-mono text-stone-800 outline-none focus:border-emerald-500 text-sm shadow-sm"
                        value={inputPaymentDate}
                        onChange={(e) => setInputPaymentDate(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                    {/* Room Price */}
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ថ្លៃបន្ទប់ (Room Price - $)</label>
                      <input
                        type="number"
                        step="0.01"
                        className="w-full bg-white border border-stone-300 rounded-lg p-2.5 font-mono font-bold text-stone-800 outline-none focus:border-emerald-500 text-sm shadow-sm"
                        value={inputRoomPrice || ''}
                        onChange={(e) => setInputRoomPrice(parseFloat(e.target.value) || 0)}
                      />
                    </div>

                    {/* Wifi Price */}
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ថ្លៃវ៉ាយហ្វាយ (Wifi Price - $)</label>
                      <input
                        type="number"
                        step="0.01"
                        className="w-full bg-white border border-stone-300 rounded-lg p-2.5 font-mono font-bold text-stone-800 outline-none focus:border-emerald-500 text-sm shadow-sm"
                        value={inputWifiPrice || ''}
                        onChange={(e) => setInputWifiPrice(parseFloat(e.target.value) || 0)}
                      />
                    </div>

                    {/* Other Price */}
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ថ្លៃផ្សេងៗ (Other - $)</label>
                      <input
                        type="number"
                        step="0.01"
                        className="w-full bg-white border border-stone-300 rounded-lg p-2.5 font-mono font-bold text-stone-800 outline-none focus:border-emerald-500 text-sm shadow-sm"
                        value={inputOtherPrice || ''}
                        onChange={(e) => setInputOtherPrice(parseFloat(e.target.value) || 0)}
                      />
                    </div>

                    {/* Elec Usage (KWH) */}
                    <div>
                      <label className="block text-[10px] font-bold text-amber-700 uppercase mb-1">
                        ចំនួនអគ្គិសនី (Electricity - KWH) *
                      </label>
                      <input
                        type="number"
                        required
                        className="w-full bg-white border border-amber-300 rounded-lg p-2.5 font-mono font-bold text-amber-700 outline-none focus:border-amber-500 text-sm shadow-sm"
                        placeholder="e.g. 45"
                        value={inputElecUsage || ''}
                        onChange={(e) => setInputElecUsage(parseInt(e.target.value) || 0)}
                      />
                      <div className="text-[10px] font-bold text-amber-600 mt-1 font-sans">
                        = {(inputElecUsage * 1500).toLocaleString()} ៛ (${inputElecPrice.toFixed(2)})
                      </div>
                    </div>

                    {/* Water Usage (M³) */}
                    <div>
                      <label className="block text-[10px] font-bold text-blue-700 uppercase mb-1">
                        ចំនួនទឹកស្អាត (Water - M³) *
                      </label>
                      <input
                        type="number"
                        required
                        className="w-full bg-white border border-blue-300 rounded-lg p-2.5 font-mono font-bold text-blue-700 outline-none focus:border-emerald-500 text-sm shadow-sm"
                        placeholder="e.g. 5"
                        value={inputWaterUsage || ''}
                        onChange={(e) => setInputWaterUsage(parseInt(e.target.value) || 0)}
                      />
                      <div className="text-[10px] font-bold text-blue-600 mt-1 font-sans">
                        = {(inputWaterUsage * 2000).toLocaleString()} ៛ (${inputWaterPrice.toFixed(2)})
                      </div>
                    </div>

                    {/* Status */}
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ស្ថានភាព (Paid Status)</label>
                      <select
                        className="w-full bg-white border border-stone-300 rounded-lg p-2.5 font-bold text-stone-800 outline-none focus:border-emerald-500 text-sm shadow-sm font-sans"
                        value={inputStatus}
                        onChange={(e) => setInputStatus(e.target.value as 'PAID' | 'PENDING')}
                      >
                        <option value="PAID">បង់រួច (PAID)</option>
                        <option value="PENDING">មិនទាន់បង់ (PENDING)</option>
                      </select>
                    </div>
                  </div>

                  {/* Submit buttons */}
                  <div className="pt-4 border-t border-stone-200 flex justify-between items-center">
                    <div className="text-xs font-bold text-stone-700">
                      សរុបប្រចាំខែ (Monthly Sum): <span className="text-emerald-600 font-mono text-sm font-black">${(Number(inputRoomPrice) + Number(inputWifiPrice) + Number(inputElecPrice) + Number(inputWaterPrice) + Number(inputOtherPrice)).toFixed(2)}</span>
                    </div>
                    <button
                      type="submit"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-black px-6 py-2.5 rounded-lg transition-all shadow-md cursor-pointer text-xs uppercase font-sans tracking-wide"
                    >
                      {editingRecordId ? '✓ រក្សាទុកការកែប្រែ (Save Changes)' : '💾 កត់ត្រាទិន្នន័យ (Record Entry)'}
                    </button>
                  </div>
                </form>

                {/* CHECKER RIGHT: 5 Cols */}
                <div className="lg:col-span-5 bg-stone-50 border border-stone-200 rounded-xl p-5 shadow-sm space-y-4">
                  <div>
                    <h3 className="text-xs font-black text-blue-900 uppercase tracking-widest flex items-center gap-1.5">
                      🔎 ពិនិត្យផលបូកសរុបរបស់ភ្ញៀវ (TOTAL SUMMARY CHECKER)
                    </h3>
                    <p className="text-[10px] text-stone-500 mt-0.5">មើលសរុបចំណូលតាមខែនីមួយៗ និងពេញមួយឆ្នាំរបស់ភ្ញៀវនីមួយៗ / View totals of selected room.</p>
                  </div>

                  {/* Selected room and Statement Date in checker */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <select
                        className="bg-white border border-stone-300 rounded px-2.5 py-1.5 text-xs font-bold text-stone-800 outline-none w-full"
                        value={inputRoomNo}
                        onChange={(e) => {
                          const rNo = e.target.value;
                          setInputRoomNo(rNo);
                          const tData = savedTenants.find(t => t.roomNo === rNo);
                          if (tData) {
                            setInputTenantName(tData.tenantName);
                            setInputRoomPrice(tData.roomPrice);
                            setInputWifiPrice(tData.wifiPrice);
                          }
                        }}
                      >
                        {sortedSavedTenants.map(t => (
                          <option key={t.roomNo} value={t.roomNo}>P.{t.roomNo} ({t.tenantName})</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <input
                        type="date"
                        className="bg-white border border-stone-300 rounded px-2.5 py-1.5 text-xs font-bold text-stone-800 outline-none w-full font-sans"
                        value={statementDate}
                        onChange={(e) => setStatementDate(e.target.value)}
                        title="កាលបរិច្ឆេទរបាយការណ៍ (Statement Date)"
                      />
                    </div>
                  </div>

                  {/* 12-Month summary for this customer */}
                  <div className="border border-stone-200 bg-white rounded-lg p-3 text-xs space-y-2 max-h-64 overflow-y-auto font-sans">
                    <div className="flex justify-between items-center font-bold text-stone-800 border-b pb-1.5 mb-1.5 text-[11px] uppercase tracking-wider">
                      <span>ខែ (Month)</span>
                      <span>សរុបបង់ (Total Collected)</span>
                    </div>

                    {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((mIndex) => {
                      const mRecord = history.find(h => 
                        (h.roomNo === inputRoomNo || h.tenantName.toLowerCase().trim() === inputTenantName.toLowerCase().trim()) && 
                        h.paymentDate.split('-')[1] === mIndex
                      );
                      
                      return (
                        <div key={mIndex} className="flex justify-between items-center text-[11px] py-1 border-b border-stone-50 last:border-0 hover:bg-stone-50 transition-colors">
                          <span className="font-medium text-stone-600">ខែ {parseInt(mIndex)} / Month {parseInt(mIndex)}</span>
                          {mRecord ? (
                            <span className="font-mono font-bold text-emerald-600">${mRecord.totalUsd.toFixed(2)}</span>
                          ) : (
                            <span className="text-stone-300 font-mono">—</span>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Year Total Box */}
                  <div className="bg-emerald-600 text-white rounded-lg p-3.5 flex justify-between items-center border border-emerald-500 shadow-sm font-sans">
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-100">សរុបរួមរបស់ភ្ញៀវ (Customer Cumulative Total)</p>
                      <p className="text-lg font-black font-mono mt-0.5">
                        ${history.filter(h => 
                          h.roomNo === inputRoomNo || 
                          h.tenantName.toLowerCase().trim() === inputTenantName.toLowerCase().trim()
                        ).reduce((sum, r) => sum + r.totalUsd, 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </p>
                    </div>
                    <span className="text-xl">💰</span>
                  </div>

                  {/* 4K Summation Invoice Download Button */}
                  <button
                    type="button"
                    onClick={() => {
                      const filename = `Invoice-Total-Room-${inputRoomNo}-${inputTenantName.trim().replace(/\s+/g, '-')}`;
                      handleDownloadSlip(customerSummaryInvoiceRef, filename);
                    }}
                    disabled={isDownloading}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3 px-4 rounded-lg transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer text-xs uppercase font-sans tracking-wide"
                  >
                    {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                    ទាញយកវិក្កយបត្រសរុប 4K (Download 4K Summation Invoice)
                  </button>


                </div>
              </div>

              {/* LIST OF ENTERED RECORDS: EDIT AND DELETE TABLE */}
              <div className="space-y-3 font-sans">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div>
                    <h3 className="text-xs font-black text-stone-800 flex items-center gap-1.5 mb-0.5 text-blue-900 uppercase tracking-wider">
                      📜 បញ្ជីកំណត់ត្រាបញ្ចូលរួច (RECORDED LEDGER FIGURES • {history.length})
                    </h3>
                    <p className="text-[11px] text-stone-500">ចុច "កែសម្រួល" ដើម្បីធ្វើបច្ចុប្បន្នភាពឡើងវិញ ឬ "លុប" ដើម្បីដកចេញ / Click Edit or Delete to manage records.</p>
                  </div>
                  
                  {/* Search Query */}
                  <div className="relative w-full sm:w-64">
                    <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-stone-400 font-sans" />
                    <input
                      type="text"
                      placeholder="ស្វែងរកបន្ទប់ ឈ្មោះភ្ញៀវ ឬកាលបរិច្ឆេទ... / Search room, guest, date..."
                      className="w-full bg-stone-50 border border-stone-200 rounded pl-8 pr-3 py-1.5 text-xs outline-none focus:bg-white focus:border-emerald-500 transition-all text-stone-800 font-sans"
                      value={adminSearchQuery}
                      onChange={(e) => setAdminSearchQuery(e.target.value)}
                    />
                  </div>
                </div>

                <div className="overflow-x-auto border border-stone-200 rounded-lg shadow-sm">
                  <table className="w-full text-left border-collapse text-xs font-sans">
                    <thead>
                      <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase text-[10px] font-bold">
                        <th className="p-3">ថ្ងៃទូទាត់ (Payment Date)</th>
                        <th className="p-3 font-sans">បន្ទប់ (Room)</th>
                        <th className="p-3">ឈ្មោះភ្ញៀវ (Guest Name)</th>
                        <th className="p-3 text-right">ថ្លៃបន្ទប់ (Room Price)</th>
                        <th className="p-3 text-right">ថ្លៃទឹកភ្លើង (Utilities)</th>
                        <th className="p-3 text-right">Wifi & ផ្សេងៗ (Wifi & Other)</th>
                        <th className="p-3 text-right font-bold text-emerald-700">សរុប (Total)</th>
                        <th className="p-3 text-center">ស្ថានភាព (Status)</th>
                        <th className="p-3 text-center">សកម្មភាព (Actions)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {history.filter(h => 
                        h.tenantName.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                        h.roomNo.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                        h.paymentDate.includes(adminSearchQuery)
                      ).length === 0 ? (
                        <tr>
                          <td colSpan={9} className="p-8 text-center text-stone-400">គ្មានកំណត់ត្រាណាមួយត្រូវបានរកឃើញទេ / No matching transaction records found.</td>
                        </tr>
                      ) : (
                        history.filter(h => 
                          h.tenantName.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                          h.roomNo.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                          h.paymentDate.includes(adminSearchQuery)
                        ).map((record) => (
                          <tr key={record.id} className="hover:bg-stone-50/50 transition-colors">
                            <td className="p-3 text-stone-600 font-mono text-[11px] whitespace-nowrap">{record.paymentDate}</td>
                            <td className="p-3 font-bold text-stone-800">
                              <span className="text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded text-[10px] font-black font-sans">
                                P.{record.roomNo}
                              </span>
                            </td>
                            <td className="p-3 font-moul text-[11px] text-blue-900 leading-tight">{record.tenantName}</td>
                            <td className="p-3 text-right font-mono text-stone-600">${record.roomPrice.toFixed(2)}</td>
                            <td className="p-3 text-right font-mono text-stone-600">
                              ${(record.elecPrice + record.waterPrice).toFixed(2)}
                              {(record.elecUsage > 0 || record.waterUsage > 0) && (
                                <p className="text-[9px] text-stone-400 font-sans mt-0.5">
                                  {record.elecUsage > 0 ? `${record.elecUsage}KWH` : ''} {record.waterUsage > 0 ? `/ ${record.waterUsage}M³` : ''}
                                </p>
                              )}
                            </td>
                            <td className="p-3 text-right font-mono text-stone-600">${(record.wifiPrice + record.otherPrice).toFixed(2)}</td>
                            <td className="p-3 text-right font-black text-emerald-600 font-mono text-[12px] tabular-nums bg-emerald-50/10">
                              ${record.totalUsd.toFixed(2)}
                            </td>
                            <td className="p-3 text-center">
                              {record.status === 'PAID' ? (
                                <span className="px-2 py-0.5 rounded bg-emerald-50 border border-emerald-100 text-emerald-700 font-bold text-[9px] uppercase tracking-wide">PAID</span>
                              ) : (
                                <span className="px-2 py-0.5 rounded bg-red-50 border border-red-100 text-red-600 font-bold text-[9px] uppercase tracking-wide">PENDING</span>
                              )}
                            </td>
                            <td className="p-3 text-center">
                              <div className="flex justify-center items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleLoadCustomerRecordForEdit(record)}
                                  className="p-1.5 text-stone-500 hover:text-amber-600 hover:bg-amber-50 rounded transition-all inline-flex"
                                  title="កែសម្រួល (Edit)"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (confirm(`តើអ្នកប្រាកដជាចង់លុបកំណត់ត្រាបន្ទប់ P.${record.roomNo} ថ្ងៃទី ${record.paymentDate} នេះឬទេ? / Are you sure you want to delete room P.${record.roomNo} record dated ${record.paymentDate}?`)) {
                                      handleDeleteHistory(record.id);
                                    }
                                  }}
                                  className="p-1.5 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded transition-all inline-flex"
                                  title="លុប (Delete)"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}
            </div> {/* Screen Inner Display Frame */}
          </div> {/* AUXILIARY CORE DISPLAY SCREEN */}
        </div>

        {/* Right Column: Preseeded Rooms & Automatic Updates Directory - Hidden on print */}
        <div className="lg:col-span-4 xl:col-span-3 w-full print:hidden space-y-6 relative z-30">
          
          {/* Quick Action: Confirm Readings (Cycle Readings) */}
          {activeTab === 'invoice' && data.tenantName && (
            <div className="bg-emerald-600 rounded-lg p-5 text-white shadow-md">
              <h3 className="text-sm font-bold flex items-center gap-1.5 mb-2">
                <RefreshCw className="w-4 h-4 animate-spin-slow" />
                ចងក្រងនិងចតលេខវ៉ាត់ (Cycle & Save Utility Readings)
              </h3>
              <p className="text-xs text-emerald-100 mb-4 leading-relaxed font-sans">
                បន្ទាប់ពីបញ្ចូលលេខវ៉ាត់ថ្មីសម្រាប់ <strong>បន្ទប់ {data.roomNo}</strong> សូមចុចប៊ូតុងខាងក្រោមដើម្បីរក្សាទុកវាជាលេខវ៉ាត់ចាស់សម្រាប់ខែក្រោយ។ / After entering new electricity/water readings for <strong>Room {data.roomNo}</strong>, click below to save them as the starting readings for next month.
              </p>
              <button
                type="button"
                onClick={handleCycleReadings}
                className="w-full bg-white hover:bg-emerald-50 text-emerald-800 font-bold text-xs py-2.5 px-4 rounded-md shadow-sm transition-all flex items-center justify-center gap-2"
              >
                ចតលេខវ៉ាត់សន្សំទៅខែក្រោយ / Cycle Readings & Save
              </button>
            </div>
          )}

          {/* Directory Panel */}
          <div className="bg-white rounded-lg border border-stone-200 p-5 shadow-sm space-y-4 font-sans text-stone-800">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-stone-800 flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-600" />
                ជ្រើសរើសបន្ទប់ / Select Tenant Room
              </h2>
              <button
                onClick={() => {
                  if (showAddForm) {
                    handleCancelForm();
                  } else {
                    setShowAddForm(true);
                  }
                }}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
              >
                {showAddForm ? "បោះបង់ (Cancel)" : "+ បន្ថែមបន្ទប់ (Add Room)"}
              </button>
            </div>

            {/* Inline Add / Edit Room Form */}
            {showAddForm && (
              <form 
                ref={formRef}
                onSubmit={handleFormSubmit} 
                className="bg-stone-50 border border-stone-200 rounded-lg p-4 space-y-3 border-l-4 border-l-emerald-500"
              >
                <div className="flex items-center justify-between border-b border-stone-200 pb-1.5">
                  <h4 className="text-xs font-bold text-stone-700 uppercase">
                    {editingTenantName ? `កែសម្រួលបន្ទប់ P.${newTenant.roomNo} (EDIT ROOM P.${newTenant.roomNo})` : "បន្ថែមបន្ទប់ និងភ្ញៀវថ្មី (ADD NEW ROOM & GUEST)"}
                  </h4>
                  {editingTenantName && (
                    <span className="text-[10px] text-amber-700 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded font-bold">
                      របៀបកែសម្រួល (Edit Mode)
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">លេខបន្ទប់ (Room No) *</label>
                    <input
                      type="text"
                      required
                      placeholder="VD: 5"
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.roomNo}
                      onChange={(e) => setNewTenant({...newTenant, roomNo: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">ឈ្មោះភ្ញៀវ (Tenant Name) *</label>
                    <input
                      type="text"
                      required
                      placeholder="VD: Seng..."
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.tenantName}
                      onChange={(e) => setNewTenant({...newTenant, tenantName: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">លេខទូរស័ព្ទ (Phone)</label>
                    <input
                      type="text"
                      placeholder="VD: 070..."
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.tenantPhone}
                      onChange={(e) => setNewTenant({...newTenant, tenantPhone: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">អត្តសញ្ញាណប័ណ្ណ (ID Card No)</label>
                    <input
                      type="text"
                      placeholder="VD: 180..."
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.tenantIdNo}
                      onChange={(e) => setNewTenant({...newTenant, tenantIdNo: e.target.value})}
                    />
                  </div>
                </div>

                {/* Grid row 3: Check-in Date and Room Price with Calendar Icon */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-stone-400" />
                      ថ្ងៃចូលស្នាក់នៅ (Check-in Date) *
                    </label>
                    <input
                      type="date"
                      required
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.checkInDate}
                      onChange={(e) => setNewTenant({...newTenant, checkInDate: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">តម្លៃជួលប្រចាំខែ (Monthly Rent - $) *</label>
                    <input
                      type="number"
                      required
                      placeholder="80"
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.roomPrice || ''}
                      onChange={(e) => setNewTenant({...newTenant, roomPrice: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">Wifi ($)</label>
                    <input
                      type="number"
                      placeholder="5"
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.wifiPrice || ''}
                      onChange={(e) => setNewTenant({...newTenant, wifiPrice: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">ប្រាក់កក់ (Security Deposit - $)</label>
                    <input
                      type="number"
                      placeholder="VD: 100"
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.deposit || ''}
                      onChange={(e) => setNewTenant({...newTenant, deposit: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">លេខវ៉ាត់ភ្លើងចាស់ (Starting Elec KWH)</label>
                    <input
                      type="text"
                      placeholder="VD: 1250"
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.elecOld}
                      onChange={(e) => setNewTenant({...newTenant, elecOld: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">លេខវ៉ាត់ទឹកចាស់ (Starting Water M³)</label>
                    <input
                      type="text"
                      placeholder="VD: 101"
                      className="w-full bg-white border border-stone-200 rounded p-1.5 text-stone-800 outline-none focus:border-emerald-500"
                      value={newTenant.waterOld}
                      onChange={(e) => setNewTenant({...newTenant, waterOld: e.target.value})}
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-1.5 rounded text-xs transition-colors"
                  >
                    {editingTenantName ? "ធ្វើបច្ចុប្បន្នភាពគណនី (Update Directory)" : "រក្សាទុកព័ត៌មាន (Save Room & Tenant)"}
                  </button>
                  <button
                    type="button"
                    onClick={handleCancelForm}
                    className="bg-stone-200 hover:bg-stone-300 text-stone-700 font-bold py-1.5 px-3 rounded text-xs transition-colors"
                  >
                    បោះបង់ (Cancel)
                  </button>
                </div>
              </form>
            )}

            <p className="text-xs text-stone-500 leading-relaxed font-sans">
              បញ្ជីបន្ទប់ត្រូវបានរៀបចំតាមលំដាប់លេខបន្ទប់។ សូមជ្រើសរើសបន្ទប់ណាមួយដើម្បីបំពេញតម្លៃបន្ទប់ សេវាអ៊ីនធឺណិត និងលេខវ៉ាត់ទឹកភ្លើងចាស់ដោយស្វ័យប្រវត្តិ។ / Directory ordered by room number. Select a room card to load base prices, Wi-Fi rates, and historical meter starting numbers.
            </p>

            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-stone-400" />
              <input
                type="text"
                placeholder="ស្វែងរករហ័សតាមបន្ទប់ ឈ្មោះ ឬលេខទូរស័ព្ទ... / Search by room, name, phone..."
                className="w-full bg-stone-50 border border-stone-200 rounded-lg pl-9 pr-4 py-2 text-xs outline-none focus:bg-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all text-stone-800 font-sans"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* List of Saved Tenants with Edit and Delete capabilities */}
            <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
              {filteredSavedTenantsForSidebar.length === 0 ? (
                <div className="text-center py-8 text-stone-400 border border-dashed border-stone-100 rounded-lg font-sans">
                  <User className="w-8 h-8 mx-auto mb-2 opacity-30 text-stone-500" />
                  <p className="text-xs font-semibold text-stone-600">រកមិនឃើញបន្ទប់ណាមួយទេ / No matching rooms found</p>
                </div>
              ) : (
                filteredSavedTenantsForSidebar.map((tenant) => {
                  const isCurrent = data.roomNo === tenant.roomNo;
                  return (
                    <div 
                      key={tenant.tenantName}
                      onClick={() => handleSelectTenant(tenant)}
                      className={`group relative p-3 rounded-lg border text-left cursor-pointer transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] ${
                        isCurrent 
                          ? 'border-emerald-500 bg-emerald-50/40 shadow-md ring-1 ring-emerald-500/20' 
                          : 'border-stone-100 bg-stone-50/50 hover:border-emerald-300 hover:bg-white hover:shadow'
                      }`}
                    >
                      <div className="pr-12">
                        <div className="flex items-center gap-1.5 justify-between">
                          <span className="font-bold text-stone-800 text-sm flex items-center gap-1">
                            <span className="text-emerald-600 bg-emerald-50 border border-emerald-100 px-1.5 py-0.5 rounded text-xs font-black font-sans">
                              P.{tenant.roomNo}
                            </span>
                            <span className="font-moul text-xs text-blue-900">{tenant.tenantName}</span>
                          </span>
                          
                          {/* Paid/Unpaid quick toggle button */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleTogglePaidStatus(tenant.roomNo);
                            }}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-all flex items-center gap-1 ${
                              tenant.isPaid 
                                ? 'bg-emerald-100 border-emerald-200 text-emerald-800' 
                                : 'bg-red-50 border-red-100 text-red-700 hover:bg-red-100'
                            }`}
                            title="ចុចដើម្បីកត់ត្រាការទូទាត់រហ័សសម្រាប់ខែតុលា / Click to quick toggle October payment status"
                          >
                            <span className={`w-1 h-1 rounded-full ${tenant.isPaid ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
                            {tenant.isPaid ? 'បានបង់ (Paid)' : 'មិនទាន់បង់ (Unpaid)'}
                          </button>
                        </div>
                        <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 mt-2.5 text-[11px] text-stone-500 border-t border-stone-100/50 pt-2 font-sans">
                          <p>តម្លៃជួល (Rent): <span className="font-bold text-stone-700">${tenant.roomPrice}</span></p>
                          <p>Wifi: <span className="font-bold text-stone-700">${tenant.wifiPrice}</span></p>
                          <p>ភ្លើងចាស់ (Elec): <span className="font-bold text-stone-700">{tenant.elecOld || '0'}</span></p>
                          <p>ទឹកចាស់ (Water): <span className="font-bold text-stone-700">{tenant.waterOld || '0'}</span></p>
                          {tenant.deposit !== undefined && (
                            <p className="col-span-2 text-stone-600 font-medium mt-1">ប្រាក់កក់ (Deposit): <span className="font-extrabold text-amber-700 font-mono">${tenant.deposit}</span> <span className="text-[9px] text-stone-400 font-normal font-sans">(display only)</span></p>
                          )}
                        </div>
                        <p className="text-[10px] text-stone-400 mt-1 font-sans">ថ្ងៃចូលស្នាក់នៅ (Check-in): {tenant.checkInDate || 'មិនទាន់បញ្ចូលទេ / Not specified'}</p>
                        {isCurrent && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (activeTab !== 'invoice') {
                                setActiveTab('invoice');
                                setTimeout(() => {
                                  handleDownloadImage();
                                }, 300);
                              } else {
                                handleDownloadImage();
                              }
                            }}
                            className="mt-2.5 w-full py-2 px-3 bg-sky-600 hover:bg-sky-700 text-white font-bold text-[10px] rounded shadow-md flex items-center justify-center gap-1.5 transition-all uppercase tracking-wider font-sans border border-sky-500"
                            title="ទាញយកវិក្កយបត្រកម្រិតរូបភាពច្បាស់ 4K របស់ភ្ញៀវនេះ / Download high-resolution 4K PNG invoice for this room"
                          >
                            <Download className="w-3.5 h-3.5" />
                            ទាញយកវិក្កយបត្រ 4K (Download 4K PNG)
                          </button>
                        )}
                      </div>

                      {/* Edit and Delete Actions on Hover */}
                      <div className="absolute right-2 top-1/2 -translate-y-1/2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleStartEditTenant(tenant);
                          }}
                          className="p-1 text-stone-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-all"
                          title="កែសម្រួលគណនី (Edit Profile)"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`តើអ្នកប្រាកដជាចង់លុបបន្ទប់ P.${tenant.roomNo} (${tenant.tenantName}) នេះឬទេ? / Are you sure you want to delete room P.${tenant.roomNo} (${tenant.tenantName})?`)) {
                              handleDeleteTenant(tenant.tenantName);
                            }
                          }}
                          className="p-1 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded transition-all"
                          title="លុบบន្ទប់ (Delete Room)"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* 3. Splits Guidelines Card: Shown on Manual Form tab */}
          {activeTab === 'manualForm' && (
            <div className="bg-white rounded-lg border border-stone-200 p-5 shadow-sm space-y-4 font-sans">
              <h2 className="text-sm font-bold text-stone-800 flex items-center gap-2 border-b border-stone-100 pb-2 font-sans">
                <Info className="w-4 h-4 text-amber-500" />
                ច្បាប់បែងចែកលុយ (Commission Split Rules)
              </h2>
              <div className="space-y-3.5 text-xs text-stone-600 font-sans">
                <div className="p-3 bg-amber-50/50 rounded-lg border border-amber-100/60 font-sans">
                  <p className="font-bold text-amber-800">1. SOVANNA (20% + Utilities)</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-amber-900/90 font-sans">
                    ទទួលបាន <strong>20%</strong> នៃតម្លៃបន្ទប់សរុប រួមជាមួយ <strong>100%</strong> នៃថ្លៃអគ្គិសនី ទឹកស្អាត និងប្រព័ន្ធអ៊ីនធឺណិត។
                  </p>
                </div>
                <div className="p-3 bg-sky-50/50 rounded-lg border border-sky-100/60 font-sans">
                  <p className="font-bold text-sky-800">2. PHEAK ($10-$15 / room)</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-sky-900/90 font-sans">
                    ទទួលបាន <strong>$15/បន្ទប់</strong> សម្រាប់ខែ ១-៩ និង <strong>$10/បន្ទប់</strong> ចាប់ពីខែ ១០ ឡើងទៅ។
                  </p>
                </div>
                <div className="p-3 bg-emerald-50/50 rounded-lg border border-emerald-100/60 font-sans">
                  <p className="font-bold text-emerald-800">3. LANDLORD (Remaining 80%)</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-emerald-900/90 font-sans">
                    ទទួលបានចំណូលថ្លៃបន្ទប់សរុប ដកប្រាក់ខែរបស់ Sovanna និង Pheak (គ្មានការកាត់ទឹកភ្លើងផ្សេងៗ)។
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 4. Room Earnings Ledger: Shown on Reports tab */}
          {activeTab === 'reports' && (
            <div className="bg-white rounded-lg border border-stone-200 p-5 shadow-sm space-y-4 font-sans">
              <h2 className="text-sm font-bold text-stone-800 flex items-center gap-2 border-b border-stone-100 pb-2 font-sans">
                <BarChart3 className="w-4 h-4 text-violet-500" />
                លទ្ធផលបន្ទប់ជួល (Room Income Ledger)
              </h2>
              <p className="text-[11px] text-stone-500 leading-normal font-sans">
                តារាងខាងក្រោមបង្ហាញពីចំណូលសរុបដែលប្រមូលបានពីបន្ទប់នីមួយៗក្នុងឆ្នាំ ២០២៦ នេះ។
              </p>
              
              <div className="space-y-2.5 max-h-[400px] overflow-y-auto pr-1 font-sans">
                {sortedSavedTenants.map((tenant) => {
                  const tenantRecords = history.filter(h => h.tenantName.toLowerCase().trim() === tenant.tenantName.toLowerCase().trim() || h.roomNo === tenant.roomNo);
                  const totalPaid = tenantRecords.reduce((sum, r) => sum + r.totalUsd, 0);
                  return (
                    <div key={tenant.roomNo} className="p-2.5 bg-stone-50 rounded-lg border border-stone-100 flex justify-between items-center text-xs">
                      <div>
                        <span className="font-bold text-stone-800 font-mono bg-stone-200/50 px-1.5 py-0.5 rounded text-[10px]">
                          P.{tenant.roomNo}
                        </span>
                        <span className="font-moul text-[10px] text-blue-900 ml-1.5">{tenant.tenantName}</span>
                      </div>
                      <span className="font-mono font-bold text-emerald-600">${totalPaid.toFixed(2)}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

      </div>

      {/* Hidden / Offscreen printable Summary Invoice for html-to-image capture - Globally rendered so it never unmounts */}
      <div className="fixed top-[-9999px] left-[-9999px] print:hidden pointer-events-none select-none opacity-100 z-[-9999] overflow-hidden">
        <div 
          ref={customerSummaryInvoiceRef}
          className="w-[600px] bg-white p-8 border-4 border-emerald-600/60 shadow-none relative rounded-sm text-stone-800 opacity-100"
        >
          {/* Decorative corner ornaments */}
          <div className="absolute top-2 left-2 text-[10px] text-emerald-600/30">✦</div>
          <div className="absolute top-2 right-2 text-[10px] text-emerald-600/30">✦</div>
          <div className="absolute bottom-2 left-2 text-[10px] text-emerald-600/30">✦</div>
          <div className="absolute bottom-2 right-2 text-[10px] text-emerald-600/30">✦</div>

          {/* Document Header */}
          <div className="text-center border-b-2 border-stone-200 pb-4 mb-4">
            <h2 className="font-moul text-emerald-800 text-base">វិក្កយបត្រសង្ខេបរបស់ភ្ញៀវ</h2>
            <h3 className="font-sans font-bold text-stone-800 text-xs tracking-widest uppercase mt-0.5">CUSTOMER SUMMARY STATEMENT ({statementDate ? statementDate.split('-')[0] : new Date().getFullYear()})</h3>
            <p className="text-xs text-stone-500 font-sans mt-1">បន្ទប់ជួលផ្ទះបឹងកេងកង / Boeng Keng Kang Room Rental</p>
          </div>

          {/* Tenant and Room Information */}
          <div className="grid grid-cols-2 gap-4 text-xs font-sans mb-4 border-b border-stone-100 pb-4">
            <div>
              <p className="text-stone-500">បន្ទប់ស្នាក់នៅ (Room No): <span className="font-bold text-emerald-800">P.{inputRoomNo}</span></p>
              <p className="text-stone-500 mt-1">ឈ្មោះអ្នកជួល (Tenant Name): <span className="font-moul text-[11px] text-blue-900 leading-tight">{inputTenantName}</span></p>
            </div>
            <div className="text-right">
              <p className="text-stone-500">ម្ចាស់ផ្ទះ (Landlord): <span className="font-bold text-stone-800">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</span></p>
              <p className="text-stone-500 mt-1">កាលបរិច្ឆេទរបាយការណ៍ (Date): <span className="font-bold text-stone-800">{statementDate ? statementDate.split('-').reverse().join('-') : ''}</span></p>
            </div>
          </div>

          {/* 12-Month Detailed Table */}
          <table className="w-full text-left border-collapse border border-stone-300 text-[10px] font-sans mb-6">
            <thead>
              <tr className="bg-stone-50 border-b border-stone-300 text-stone-600 font-bold uppercase">
                <th className="p-2 border border-stone-300">ខែ (Month)</th>
                <th className="p-2 border border-stone-300 text-right">ថ្លៃបន្ទប់ (Room Rent)</th>
                <th className="p-2 border border-stone-300 text-right">ថ្លៃភ្លើង (Electricity)</th>
                <th className="p-2 border border-stone-300 text-right">ថ្លៃទឹក (Water)</th>
                <th className="p-2 border border-stone-300 text-right">Wifi / ផ្សេងៗ (Wifi/Other)</th>
                <th className="p-2 border border-stone-300 text-right">សរុបបង់ (Total Collected)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200 text-stone-700">
              {["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].map((mIndex) => {
                const mRecord = history.find(h => 
                  (h.roomNo === inputRoomNo || h.tenantName.toLowerCase().trim() === inputTenantName.toLowerCase().trim()) && 
                  h.paymentDate.split('-')[1] === mIndex
                );

                return (
                  <tr key={mIndex} className="hover:bg-stone-50/50">
                    <td className="p-2 border border-stone-300 font-bold">ខែ {parseInt(mIndex)} / Month {parseInt(mIndex)}</td>
                    <td className="p-2 border border-stone-300 text-right font-mono text-stone-500">
                      {mRecord ? `$${mRecord.roomPrice.toFixed(2)}` : '—'}
                    </td>
                    <td className="p-2 border border-stone-300 text-right font-mono text-stone-500">
                      {mRecord ? `$${mRecord.elecPrice.toFixed(2)}` : '—'}
                    </td>
                    <td className="p-2 border border-stone-300 text-right font-mono text-stone-500">
                      {mRecord ? `$${mRecord.waterPrice.toFixed(2)}` : '—'}
                    </td>
                    <td className="p-2 border border-stone-300 text-right font-mono text-stone-500">
                      {mRecord ? `$${(mRecord.wifiPrice + mRecord.otherPrice).toFixed(2)}` : '—'}
                    </td>
                    <td className="p-2 border border-stone-300 text-right font-mono font-bold text-emerald-600">
                      {mRecord ? `$${mRecord.totalUsd.toFixed(2)}` : '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Year Total Box */}
          <div className="flex justify-between items-center border-t-2 border-stone-800 pt-4 mb-8">
            <span className="text-xs font-black text-stone-800 uppercase">សរុបប្រមូលបានទាំងអស់ (GRAND TOTAL COLLECTED)</span>
            <span className="text-lg font-black text-emerald-600 font-mono">
              ${history.filter(h => 
                h.roomNo === inputRoomNo || 
                h.tenantName.toLowerCase().trim() === inputTenantName.toLowerCase().trim()
              ).reduce((sum, r) => sum + r.totalUsd, 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>

          {/* Stamp & Signatures */}
          <div className="grid grid-cols-2 gap-8 text-center text-[10px] font-sans mt-8 pt-8 border-t border-dashed border-stone-200 relative">
            
            {/* Landlord Stamp */}
            <div className="absolute left-[40%] top-[-25px] pointer-events-none select-none flex items-center justify-center">
              <div className="w-[80px] h-[80px] rounded-full border-[3px] border-red-500/80 flex items-center justify-center p-1 relative rotate-[-12deg] bg-white/40">
                <div className="w-[66px] h-[66px] rounded-full border border-dashed border-red-500/80 flex items-center justify-center relative">
                  <span className="absolute text-[6px] font-black text-red-500/80 uppercase tracking-widest text-center leading-none">
                    បន្ទប់ជួលផ្ទះបឹងកេងកង
                  </span>
                  <span className="absolute bottom-1 text-[5px] font-bold text-red-500/80 tracking-widest uppercase">
                    * ម្ចាស់ផ្ទះ *
                  </span>
                  <div className="text-sm text-red-500/80 select-none">💮</div>
                </div>
              </div>
            </div>

            <div>
              <p className="text-stone-400">ហត្ថលេខាអ្នកជួល (Tenant's Signature)</p>
              <div className="h-10"></div>
              <p className="font-bold text-stone-700">{inputTenantName}</p>
            </div>
            <div>
              <p className="text-stone-400">ហត្ថលេខាម្ចាស់ផ្ទះ (Owner's Signature)</p>
              <div className="h-10"></div>
              <p className="font-bold text-stone-700">{data.landlordName || 'សាង សុវណ្ណារតនៈ'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Page Footer Info - Hidden on print */}
      <div className="max-w-7xl mx-auto mt-8 text-center text-stone-400 text-xs print:hidden">
        <p>© 2024 Room Rent Manager. All rights reserved.</p>
        <p className="mt-1">Designed for professional property management.</p>
      </div>
    </div>
  );
}
